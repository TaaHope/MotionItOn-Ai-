'use client';
import React, { useEffect, useState } from 'react';
import { ArrowLeft, Trash2, Activity, Download } from 'lucide-react';
import { deleteRenderOutput, getRenderOutput } from '../services/renderJobStore';

type Job = { id: string; title: string; status: 'Completed' | 'Failed' | 'Rendering' | 'Queued'; progress: number; timestamp: string; source?: 'editor' | 'ai'; error?: string; downloadUrl?: string | null };
type AiJobRecord = { id?: string; title?: string; prompt?: string; status?: string; progress?: number | string; createdAt?: string; error?: string; downloadUrl?: string | null };
export function QueueView({ onBack }: { onBack: () => void }) {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [available, setAvailable] = useState<Record<string, boolean>>({});
  const [busy, setBusy] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const refresh = async () => {
    let stored: Job[] = [];
    try { stored = JSON.parse(localStorage.getItem('motioniton_render_jobs') || '[]') as Job[]; } catch { stored = []; }
    const checks = await Promise.all(stored.filter(j => j.status === 'Completed').map(async j => {
      try { return [j.id, Boolean(await getRenderOutput(j.id))] as const; } catch { return [j.id, false] as const; }
    }));
    let aiJobs: Job[] = [];
    try {
      const base = (localStorage.getItem('motioniton_ai_backend_url') || '').replace(/\/+$/, '');
      const token = localStorage.getItem('motioniton_session') || '';
      if (base && token) {
        const response = await fetch(`${base}/api/ai/jobs`, { headers: { Authorization: `Bearer ${token}` } });
        if (response.ok) {
          const data: { jobs?: AiJobRecord[] } = await response.json();
          aiJobs = (Array.isArray(data.jobs) ? data.jobs : []).flatMap((job: AiJobRecord): Job[] => {
            // A backend record without an ID cannot be safely retried, removed, or keyed in React.
            if (typeof job.id !== 'string' || job.id.trim() === '') return [];
            const status: Job['status'] = job.status === 'completed'
              ? 'Completed'
              : job.status === 'failed'
                ? 'Failed'
                : job.status === 'running' || job.status === 'downloading'
                  ? 'Rendering'
                  : 'Queued';
            return [{
              id: job.id,
              title: job.title || job.prompt || 'AI production',
              status,
              progress: Number(job.progress) || 0,
              timestamp: job.createdAt || new Date().toISOString(),
              source: 'ai',
              error: job.error || undefined,
              downloadUrl: job.downloadUrl || null,
            }];
          });
        }
      }
    } catch { /* keep locally saved editor jobs visible if the engine is offline */ }
    setJobs([...aiJobs, ...stored.map(j => ({ ...j, source: 'editor' as const }))].sort((a,b)=>new Date(b.timestamp).getTime()-new Date(a.timestamp).getTime()));
    setAvailable(Object.fromEntries(checks));
  };
  useEffect(() => { void refresh(); const timer = window.setInterval(() => { void refresh(); }, 10000); return () => window.clearInterval(timer); }, []);
  const remove = async (id: string) => {
    const target = jobs.find(j => j.id === id);
    if (target?.source === 'ai') {
      const base=(localStorage.getItem('motioniton_ai_backend_url')||'').replace(/\/+$/,'');
      const token=localStorage.getItem('motioniton_session')||'';
      if(!base||!token){setMessage('Sign in and connect the backend to remove this queued job.');return;}
      try { const response=await fetch(`${base}/api/ai/jobs/${encodeURIComponent(id)}`,{method:'DELETE',headers:{Authorization:`Bearer ${token}`}}); const data=await response.json().catch(()=>({})); if(!response.ok) throw new Error(data.error||'Could not remove job.'); }
      catch(error){setMessage(error instanceof Error?error.message:String(error));return;}
      setJobs(prev => prev.filter(j => j.id !== id)); return;
    }
    try { await deleteRenderOutput(id); } catch { /* output may already be absent */ }
    setJobs(prev => {
      const next = prev.filter(j => j.id !== id);
      localStorage.setItem('motioniton_render_jobs', JSON.stringify(next.filter(j => j.source !== 'ai')));
      return next;
    });
    setAvailable(prev => { const next = { ...prev }; delete next[id]; return next; });
  };
  const retry = async (job: Job) => {
    const base=(localStorage.getItem('motioniton_ai_backend_url')||'').replace(/\/+$/,'');
    const token=localStorage.getItem('motioniton_session')||'';
    if(!base||!token){setMessage('Sign in and connect the backend to retry this job.');return;}
    setBusy(job.id); setMessage('');
    try { const response=await fetch(`${base}/api/ai/jobs/${encodeURIComponent(job.id)}/retry`,{method:'POST',headers:{Authorization:`Bearer ${token}`}}); const data=await response.json().catch(()=>({})); if(!response.ok) throw new Error(data.error||'Could not retry job.'); await refresh(); }
    catch(error){setMessage(error instanceof Error?error.message:String(error));}
    finally{setBusy(null);}
  };
  const download = async (job: Job) => {
    setBusy(job.id); setMessage('');
    try {
      let blob: Blob | null;
      if (job.source === 'ai') {
        const base = (localStorage.getItem('motioniton_ai_backend_url') || '').replace(/\/+$/, '');
        const token = localStorage.getItem('motioniton_session') || '';
        if (!base || !token || !job.downloadUrl) throw new Error('This AI video is not ready to download.');
        const response = await fetch(`${base}${job.downloadUrl}`, { headers: { Authorization: `Bearer ${token}` } });
        if (!response.ok) throw new Error('Could not download the generated video.');
        blob = await response.blob();
      } else { blob = await getRenderOutput(job.id); }
      if (!blob) throw new Error('The saved video is no longer available. Render it again.');
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a'); anchor.href = url; anchor.download = `${job.title.replace(/[^a-z0-9-_]+/gi, '_').slice(0, 80) || 'MotionItOn-export'}.mp4`;
      document.body.appendChild(anchor); anchor.click(); anchor.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
    } catch (e) { setMessage(e instanceof Error ? e.message : String(e)); }
    finally { setBusy(null); }
  };
  return <section className="settings-panel"><header className="panel-head"><button className="secondary-button" onClick={onBack}><ArrowLeft size={15}/> Back</button><div><h2>Render Queue</h2><p>Your production jobs and video renders.</p></div><span>{jobs.length} jobs</span></header>
    {message && <p role="alert" className="field-hint">{message}</p>}
    {jobs.length === 0 ? <div className="queue-empty"><Activity size={28}/><h3>No production jobs yet</h3><p>Your queued scripts and video productions will appear here.</p></div> : <div className="queue-list">{jobs.map(j => <article className="panel-card queue-row" key={j.id}><div><b>{j.title}</b><p>{new Date(j.timestamp).toLocaleString()}</p><span>{j.source === 'ai' ? 'AI production · ' : 'Editor render · '}{j.status} · {j.progress}%</span>{j.error && <p className="field-hint">{j.error}</p>}{j.status === 'Rendering' && <progress max="100" value={j.progress} />}{j.status === 'Completed' && !available[j.id] && <p className="field-hint">Output file unavailable in local storage.</p>}</div><div className="queue-actions">{j.status === 'Failed' && j.source === 'ai' && <button className="secondary-button" disabled={busy===j.id} onClick={()=>void retry(j)}>Retry</button>}{j.status === 'Completed' && ((j.source === 'ai' && Boolean(j.downloadUrl)) || (j.source !== 'ai' && available[j.id])) && <button className="secondary-button" disabled={busy === j.id} onClick={() => void download(j)}><Download size={15}/>{busy === j.id ? 'Preparing…' : 'Download'}</button>}{(j.source !== 'ai' || j.status === 'Queued' || j.status === 'Failed') && <button className="secondary-button" onClick={() => void remove(j.id)} aria-label="Remove job"><Trash2 size={15}/></button>}</div></article>)}</div>}
  </section>;
}
