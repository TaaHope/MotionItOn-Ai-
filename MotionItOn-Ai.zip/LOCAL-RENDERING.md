# Local rendering notes

MotionItOn's editor uses FFmpeg WebAssembly in the browser to encode imported video clips and still images into MP4 slideshows. The FFmpeg core is downloaded on first use from the configured CDN; after it loads, media processing runs locally. A first render therefore requires internet access and sufficient browser memory.

- **Resolution / orientation:** `Match source` uses the first clip's actual dimensions. `Keep original` preserves the first clip's aspect ratio while applying the selected output resolution. Explicit frame orientations use the selected target ratio; other clips are fitted and padded to the same output frame.
- **Frame rate:** Select 24, 25, 30, or 60 fps. Source frame-rate matching is not offered because the browser metadata API does not expose a reliable source frame rate.
- **Pictures:** Import image files alongside videos. Each still image defaults to five seconds and can be adjusted from 1–30 seconds in the clip settings. Still images are encoded as video segments and joined in timeline order.
- **Audio:** A separate music track can be selected from the device, trimmed and mixed over the complete export. Original audio is retained for a single video clip when enabled; multi-clip exports use a separate music track or remain silent.
- **Transitions and titles:** The current editor still uses hard cuts. Animated transitions, title overlays and multiple independent audio tracks are not implemented yet.
- **Queue persistence:** Render history is kept in local storage and output MP4 blobs are stored in IndexedDB when the browser grants enough space. If storage refuses a large output, the direct download still proceeds, but that queue entry will not have a persistent download copy.
- **Hardware acceleration / offline mode:** These are not exposed as functional settings because FFmpeg WebAssembly does not guarantee GPU encoding and the first engine load requires a network connection.

The source ZIP integrity can be checked with `unzip -t MotionItOn-Ai.zip`. A successful archive check does not replace a full dependency install, platform build, or real-device render test.
