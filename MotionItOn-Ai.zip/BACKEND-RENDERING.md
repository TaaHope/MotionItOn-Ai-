# MotionItOn-Ai: FFmpeg MP4 rendering backend

This archive wires the existing editor's selected video clips to a separate Express rendering service. The service uses FFmpeg to trim, normalize, concatenate, and encode uploaded clips into a downloadable MP4. It does **not** generate new AI footage.

## Backend API

- `GET /health` or `GET /api/health` — health check; returns service/storage details.
- `POST /api/render` — multipart form fields `clips` (one or more video files), optional `trims` JSON array (`[{"start":0,"end":5}]`), `resolution` (`720p` or `1080p`), `orientation` (`Landscape 16:9`, `Vertical 9:16`, or `Square 1:1`), and `fps`.
- `GET /api/jobs/:id` — job status and progress.
- `GET /api/jobs/:id/download` — download completed MP4.
- `GET /api/jobs` — recent jobs.

When `MOTIONITON_API_KEY` is set, send `Authorization: Bearer <key>` or `x-api-key: <key>` on every API request except health checks. The frontend's API-key field sends the bearer header.

## Run locally

Requirements: Node.js 22+, FFmpeg installed and on `PATH`.

```sh
cp .env.example .env
# Edit .env and set a long random MOTIONITON_API_KEY.
npm install
npm run backend
```

The backend listens on port 8787 by default. Check `http://localhost:8787/health`. A phone cannot reach a backend at its own `localhost` unless the server is running on the phone; for phone testing, deploy the backend to a reachable HTTPS host and configure its exact origin in `ALLOWED_ORIGINS`.

## Docker

```sh
docker build -f Dockerfile.backend -t motioniton-renderer .
docker run --rm -p 8787:8787 \
  -e MOTIONITON_API_KEY='replace-with-a-long-random-secret' \
  -e ALLOWED_ORIGINS='https://your-web-app.example' \
  -v motioniton-data:/data motioniton-renderer
```

The image installs FFmpeg and the native build tools needed for `better-sqlite3`. `/data` is a persistent volume containing the SQLite database, uploads during processing, and rendered files. Put the service behind HTTPS before using it over a network.

## Persistence and recovery

Job metadata is stored in SQLite (`jobs.sqlite`) using transactions/WAL mode rather than a flat JSON file. Queued jobs are reloaded on startup. A job that was actively rendering when the process stopped is marked failed with a clear recovery message; an FFmpeg child process cannot be resumed after a restart. The queue is single-worker/in-memory, so this is a small single-instance renderer, not a horizontally scaled production queue.

## Security and operational limits

- Exact-origin CORS allowlist; requests without an `Origin` header are permitted for CLI/mobile clients.
- Optional bearer API-key protection; set it in production. Health endpoints are intentionally unauthenticated.
- Helmet headers, upload size and file-count limits, and a basic video MIME-type filter.
- MIME type is not a full media or malware validation strategy. Use HTTPS, private persistent storage, rate limiting, authentication, authorization, and monitoring before public launch.
- The renderer supports basic trims, scaling/padding, frame-rate normalization, and concatenation. Advanced transitions, separate music/narration tracks, subtitles, accounts, billing, cloud project sync, and AI text-to-video generation are not implemented here.

## Verification status

The backend JavaScript syntax, Electron entrypoint syntax, package JSON, and installed FFmpeg binary were checked in the build environment. Dependency installation timed out in this environment, so the full Next.js build, Docker image build, API startup, and real end-to-end MP4 render could not be executed here. Run the GitHub Actions build and test the deployed backend before treating the release as verified.


## Self-hosted AI video generation

The Runway adapter has been removed. See `RUNPOD-DEPLOYMENT.md` for the Wan 2.2 TI2V-5B RunPod worker, backend connection, persistent backend storage, and end-to-end verification plan. This uses your own model runtime rather than a commercial video-generation API. A compatible GPU host is currently required; no claim is made that the model runs inside the Android APK.


## Long-form AI video generation (2–300 seconds)

The AI generation endpoint accepts durations up to 300 seconds. The GPU worker loads the LTX pipeline once, divides the requested runtime into consecutive scenes of no more than 20 seconds, generates each scene while reusing the loaded model, normalizes each scene to MP4, and stitches the scenes into one MP4 with FFmpeg. The final output is trimmed to the exact requested duration. Generation time and GPU cost increase with scene count; five-minute jobs can take substantially longer than short clips.

The browser-based editor also accepts an optional user audio track with a selected start/end trim range. During MP4 export the renderer trims the selected source audio, applies its volume, pads it if it is shorter than the video, and muxes it into the final MP4. Selecting a separate audio track replaces the source clip audio in the export.


## MotionItOn remote GPU mode

For production, set `MOTIONITON_GENERATION_MODE=remote`. This is the default. If the RunPod worker URL or token is missing or the worker is offline, AI jobs remain queued and the backend retries; it does not silently attempt local CPU generation. The worker URL and shared worker token are server-side backend secrets. The completed MP4 is downloaded into the backend's `/data/renders` directory, which must be on a persistent volume. See `RUNPOD-DEPLOYMENT.md`.
