import test from 'node:test';
import assert from 'node:assert/strict';
import { runRemoteVideoGeneration, remoteWorkerHealth } from './remote-worker-client.mjs';
import { RunPodProvider, GpuIdleShutdown } from './runpod-provider.mjs';
import { normalizeGenerateRequest } from './ai-video-engine.mjs';

const env = { MOTIONITON_REMOTE_WORKER_URL: 'https://gpu.example.test', MOTIONITON_WORKER_TOKEN: 'x'.repeat(48), MOTIONITON_REMOTE_POLL_MS: '500', MOTIONITON_REMOTE_TIMEOUT_MS: '60000' };
test('generation request accepts validated character continuity references', () => {
  const value = normalizeGenerateRequest({ prompt: 'A family walking', characters: [{ name: 'Tariro', appearance: 'Young woman with short dark hair', wardrobe: 'Blue jacket' }] });
  assert.equal(value.characters[0].name, 'Tariro');
  assert.throws(() => normalizeGenerateRequest({ prompt: 'x', characters: [{ name: 'A', appearance: 'x' }, { name: 'a', appearance: 'y' }] }), /Duplicate/);
  assert.throws(() => normalizeGenerateRequest({ prompt: 'x', characters: Array(9).fill({ name: 'x', appearance: 'y' }) }), /eight/);
});
test('remote worker client submits, polls and downloads a generated MP4', async () => {
  const calls = []; let poll = 0;
  const fetchImpl = async (url, options = {}) => {
    calls.push([url, options]);
    if (url.endsWith('/jobs')) return new Response(JSON.stringify({ id: '123e4567-e89b-12d3-a456-426614174000' }), { status: 202 });
    if (url.endsWith('/download')) return new Response(new Uint8Array(2048), { status: 200, headers: { 'content-type': 'video/mp4' } });
    poll++; return new Response(JSON.stringify({ status: 'completed', progress: 100, message: 'ready' }), { status: 200 });
  };
  const progress = [];
  const result = await runRemoteVideoGeneration({ prompt: 'Test scene', ratio: '1280:720', duration: 3, characters: [], outputPath: '/tmp/motioniton-remote-test.mp4', env, fetchImpl, onProgress: value => progress.push(value) });
  assert.equal(result.remoteJobId, '123e4567-e89b-12d3-a456-426614174000');
  assert.equal(poll, 1); assert.ok(progress.length); assert.equal(calls[0][1].headers.Authorization, `Bearer ${env.MOTIONITON_WORKER_TOKEN}`);
  const { stat, unlink } = await import('node:fs/promises'); assert.equal((await stat(result.outputPath)).size, 2048); await unlink(result.outputPath);
});
test('remote worker rejects insecure non-local URLs and short tokens', async () => {
  await assert.rejects(remoteWorkerHealth({ env: { ...env, MOTIONITON_REMOTE_WORKER_URL: 'http://gpu.example.test' } }), /HTTPS/);
  await assert.rejects(remoteWorkerHealth({ env: { ...env, MOTIONITON_WORKER_TOKEN: 'short' } }), /32 characters/);
});
test('RunPod provider keeps API key in server-side authorization header', async () => {
  let captured;
  const provider = new RunPodProvider({ apiKey: 'r'.repeat(32), fetchImpl: async (url, options) => { captured = { url, options }; return new Response(JSON.stringify({ id: 'pod-12345' }), { status: 200 }); } });
  const result = await provider.createGpuPod({ templateId: 'template-1', gpuTypeId: 'NVIDIA RTX 3090', env: { MOTIONITON_WORKER_TOKEN: 'w'.repeat(48) } });
  assert.equal(result.id, 'pod-12345'); assert.equal(captured.options.headers.Authorization, `Bearer ${'r'.repeat(32)}`);
  assert.equal(provider.workerProxyUrl('pod-12345'), 'https://pod-12345-8790.proxy.runpod.net');
  const ready = await provider.waitForWorker('https://pod-12345-8790.proxy.runpod.net', 'w'.repeat(48), { timeoutMs: 1000, pollMs: 1, fetchImpl: async () => new Response(JSON.stringify({ ok: true }), { status: 200 }) });
  assert.equal(ready.ok, true);
  const body = JSON.parse(captured.options.body); assert.deepEqual(body.gpuTypeIds, ['NVIDIA RTX 3090']); assert.equal(body.volumeInGb, undefined);
});
test('GPU idle shutdown terminates only after configured idle interval', async () => {
  let terminated = 0;
  const manager = new GpuIdleShutdown({ terminatePod: async () => { terminated++; } }, { idleSeconds: 60 });
  manager.attach('pod-12345'); manager.markBusy(); manager.markIdle(); manager.cancel(); assert.equal(terminated, 0);
});

test('private storage helpers reject non-HTTPS public URLs', async () => {
  const { uploadToPresignedUrl } = await import('./private-storage.mjs');
  await assert.rejects(uploadToPresignedUrl('/does/not/exist', 'http://storage.example.test/object'), /HTTPS/);
});
