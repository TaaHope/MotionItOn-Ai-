import type { MetadataRoute } from "next";

export const dynamic = "force-static";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "MotionItOn-Ai",
    short_name: "MotionItOn",
    description: "Create AI videos across multiple genres.",
    start_url: "/",
    display: "standalone",
    background_color: "#101014",
    theme_color: "#101014",
    orientation: "any",
    icons: []
  };
}
