# MotionItOn container publishing and RunPod deployment

## What GitHub Actions now does

When a `MotionItOn*.zip` archive is pushed to the repository root on `main`, the existing platform workflow continues to build the Web, Android and Windows outputs. It also extracts that same ZIP and builds/publishes two images using the Dockerfiles inside it:

- `ghcr.io/taahope/motioniton-gpu-worker:wan22`
- `ghcr.io/taahope/motioniton-backend:latest`

Each image also receives a commit-specific `sha-...` tag. The workflow uses the repository-scoped `GITHUB_TOKEN`; do not add a Docker Hub account or a registry password.

The first successful run creates the GHCR packages. GitHub may keep packages private by default. For RunPod to pull them without registry credentials, open each package under the GitHub account's Packages section and change its package visibility to Public. This exposes the container image contents, so only do this knowing the source repository is already public. Alternatively, keep packages private and configure RunPod with a registry pull secret that has read:packages access.

## RunPod GPU worker

After the GPU image is published, create a RunPod GPU Pod from the custom image:

`ghcr.io/taahope/motioniton-gpu-worker:wan22`

Configure:
- GPU: RTX 3090 24 GB or another compatible GPU
- Expose HTTP port: `8790`
- Persistent volume mounted at `/workspace` for model cache
- `MOTIONITON_WORKER_TOKEN`: random secret of at least 32 characters
- `MOTIONITON_WORKER_PORT=8790`
- `MOTIONITON_REMOTE_DATA=/workspace/jobs`
- `HF_HOME=/workspace/.cache/huggingface`
- `MOTIONITON_WAN_CPU_OFFLOAD=true`
- `MOTIONITON_SELECTED_MODEL=wan-2.2-ti2v-5b`

Copy the pod's HTTPS proxy URL for port 8790. It will resemble `https://POD_ID-8790.proxy.runpod.net`.

## RunPod backend

Create a separate CPU Pod using:

`ghcr.io/taahope/motioniton-backend:latest`

Expose HTTP port `8787` and attach a persistent RunPod network volume mounted at `/data`. This volume must remain attached when the pod is stopped/recreated. Do not store the SQLite database or finished MP4s on the container's temporary disk.

Set these backend environment variables:
- `PORT=8787`
- `NODE_ENV=production`
- `MOTIONITON_DATA_DIR=/data`
- `MOTIONITON_WORKERS_FILE=/data/workers.json`
- `MOTIONITON_GENERATION_MODE=remote`
- `MOTIONITON_REMOTE_WORKER_URL=https://POD_ID-8790.proxy.runpod.net`
- `MOTIONITON_WORKER_TOKEN`: exactly the same secret as the GPU worker
- `MOTIONITON_API_KEY`: a separate random secret of at least 32 characters
- `MOTIONITON_REMOTE_TIMEOUT_MS=21600000`
- `MOTIONITON_REMOTE_POLL_MS=2000`

Preserve any other existing authentication/account environment variables required by the current application. Do not add Supabase Storage for video retention. Existing Supabase Auth settings, if used by the app, are a separate concern.

After deployment, configure the backend URL and its existing engine/API key in MotionItOn Settings. Verify `/api/health`, then use the authenticated remote-worker health check. Finally generate a short test clip and confirm the MP4 is saved under `/data/renders`. Stop/recreate the backend pod and confirm the same video remains available.

## Important deployment boundary

The workflow builds and publishes the images; it does not create RunPod Pods or purchase GPU time. RunPod Pod creation, volume attachment, secrets and public endpoint configuration still happen in the RunPod account. The application does not need to be re-downloaded or rebuilt for every worker image update.
