# MotionItOn-Ai — Phase 4 & 5 dependency-free implementation

## Remote GPU worker

The control backend can use either the local Python worker (default) or the private remote worker. To select remote mode, configure these server-only environment variables:

- `MOTIONITON_REMOTE_WORKER_URL=https://<pod-id>-8790.proxy.runpod.net`
- `MOTIONITON_WORKER_TOKEN=<random secret of at least 32 characters>`

The GPU image starts `engine/remote_worker.py` on port 8790. The worker exposes `/health`, `POST /jobs`, `GET /jobs/:id`, `DELETE /jobs/:id` and `GET /jobs/:id/download`. All job routes require the bearer worker token. Only prompt, settings and explicitly supplied character text references are sent to the pod. Account credentials and the RunPod API key remain on the control backend.

## RunPod provisioning

Configure server-side secrets and identifiers:

- `RUNPOD_API_KEY`
- `RUNPOD_TEMPLATE_ID`
- `RUNPOD_GPU_TYPE_ID`
- `MOTIONITON_WORKER_TOKEN`

Then use:

```bash
node scripts/runpod-control.mjs create
node scripts/runpod-control.mjs wait <pod-id>
node scripts/runpod-control.mjs status <pod-id>
node scripts/runpod-control.mjs terminate <pod-id>
```

The create command does not silently rent a GPU during normal app use. Provisioning is an explicit operator action. Verify the selected GPU price and availability in RunPod before creating the pod. `RUNPOD_API_KEY` must never be passed to the GPU worker.

## Private object storage

`backend/private-storage.mjs` provides streaming transfer functions for provider-issued presigned HTTPS URLs. The application still needs a trusted storage service to issue per-user upload/download URLs and enforce object ownership. No public bucket or permanent worker-side media storage is configured by this patch.

## Generation/production planning improvements

`engine/production_planner.py` adds deterministic prompt enhancement, scene-level continuity instructions, character appearance/wardrobe bibles and exact scene-duration allocation. The existing generation endpoint accepts an optional `characters` array. These are text references; the legacy LTX adapter does not accept reference images.

## Validation commands

```bash
python -m compileall -q engine
python -m unittest engine.test_model_registry engine.test_worker_registry engine.test_production_planner engine.test_remote_worker -v
npm run test:phase45
```

A passing mock-worker test verifies the HTTP protocol and private authentication, not a real GPU render. Live RunPod provisioning, model download and video quality must be checked on the selected GPU before paying for production rendering.
