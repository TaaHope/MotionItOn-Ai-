"""Model catalogue, capability selection and conservative GPU checks.

Only implemented adapters can be selected. Unknown GPU memory is not treated
as unlimited. Total VRAM is checked with a safety margin; adapters may impose
additional free-memory checks during load.
"""
from __future__ import annotations
import importlib
from dataclasses import dataclass, asdict
from typing import Optional

@dataclass(frozen=True)
class ModelSpec:
    model_id: str
    display_name: str
    adapter_module: str
    adapter_class: str
    supported_tasks: tuple[str, ...]
    supported_styles: tuple[str, ...]
    minimum_vram_gb: float
    recommended_vram_gb: float
    supports_text_to_video: bool
    supports_image_to_video: bool
    supports_audio: bool
    implemented: bool
    enabled: bool = True

MODEL_REGISTRY: dict[str, ModelSpec] = {
    "ltx-legacy": ModelSpec(
        "ltx-legacy", "LTX-Video (Self-Hosted)",
        "engine.adapters.ltx_legacy", "LTXLegacyAdapter",
        ("text_to_video",),
        ("general", "cinematic", "documentary", "realistic", "cartoon", "cooking", "nature"),
        16.0, 24.0, True, False, False, True, True,
    ),
    "ltx-2": ModelSpec(
        "ltx-2", "LTX-2", "engine.adapters.ltx2", "LTX2Adapter",
        ("text_to_video", "image_to_video"), ("realistic", "cinematic", "documentary"),
        24.0, 48.0, True, True, True, False, False,
    ),
    "wan-2.2-ti2v-5b": ModelSpec(
        "wan-2.2-ti2v-5b", "Wan 2.2 TI2V 5B", "engine.adapters.wan22", "Wan22Adapter",
        ("text_to_video", "image_to_video"), ("realistic", "cinematic", "cartoon"),
        22.0, 24.0, True, True, False, True, True,
    ),
    "hunyuan-video-1.5": ModelSpec(
        "hunyuan-video-1.5", "HunyuanVideo 1.5", "engine.adapters.hunyuan15", "Hunyuan15Adapter",
        ("text_to_video", "image_to_video"), ("realistic", "cinematic"),
        16.0, 24.0, True, True, False, False, False,
    ),
}

# Wan 2.2 is the sole automatic/default model. LTX remains selectable only
# when explicitly requested; automatic selection never silently changes models.
STYLE_MODEL_PREFERENCES = {
    "realistic": ("wan-2.2-ti2v-5b",),
    "cinematic": ("wan-2.2-ti2v-5b",),
    "cartoon": ("wan-2.2-ti2v-5b",),
    "documentary": ("wan-2.2-ti2v-5b",),
    "cooking": ("wan-2.2-ti2v-5b",),
    "nature": ("wan-2.2-ti2v-5b",),
    "general": ("wan-2.2-ti2v-5b",),
}

VRAM_SAFETY_GB = 2.0

def get_gpu_memory_gb() -> float:
    try:
        import torch
        if not torch.cuda.is_available():
            return 0.0
        return float(torch.cuda.get_device_properties(0).total_memory) / (1024 ** 3)
    except Exception:
        return 0.0

def get_registry_status() -> list[dict]:
    rows = []
    for spec in MODEL_REGISTRY.values():
        row = asdict(spec)
        row.pop("adapter_module", None)
        row.pop("adapter_class", None)
        rows.append(row)
    return rows

def get_model(model_id: str) -> ModelSpec:
    spec = MODEL_REGISTRY.get(model_id)
    if spec is None:
        raise ValueError(f"Unknown generation model: {model_id}")
    if not spec.enabled or not spec.implemented:
        raise RuntimeError(f"{spec.display_name} is registered but its adapter is not implemented and validated.")
    return spec

def _compatible(spec: ModelSpec, task: str, available_vram: float, safety_gb: float) -> bool:
    if not spec.enabled or not spec.implemented or task not in spec.supported_tasks:
        return False
    capability = spec.supports_text_to_video if task == "text_to_video" else spec.supports_image_to_video
    if not capability or available_vram <= 0:
        return False
    return available_vram >= spec.minimum_vram_gb + safety_gb

def select_model(style: str = "general", task: str = "text_to_video", requested_model: Optional[str] = None,
                 vram_gb: Optional[float] = None, safety_gb: float = VRAM_SAFETY_GB) -> ModelSpec:
    if task not in ("text_to_video", "image_to_video"):
        raise ValueError(f"Unsupported generation task: {task}")
    available = get_gpu_memory_gb() if vram_gb is None else float(vram_gb)
    if available <= 0:
        raise RuntimeError("GPU memory could not be detected. Refusing to select a model without a verified CUDA device.")
    if requested_model and requested_model not in ("motioniton-auto", "ltx-video-local"):
        candidates = [get_model(requested_model)]
    else:
        candidates = [MODEL_REGISTRY[mid] for mid in STYLE_MODEL_PREFERENCES.get(style.lower().strip(), STYLE_MODEL_PREFERENCES["general"]) if mid in MODEL_REGISTRY]
    for spec in candidates:
        if _compatible(spec, task, available, safety_gb):
            return spec
    raise RuntimeError(f"No implemented model meets task={task}, style={style}, VRAM={available:.1f} GB and {safety_gb:.1f} GB safety margin. No incompatible fallback was selected.")

def load_adapter(spec: ModelSpec):
    if not spec.enabled or not spec.implemented:
        raise RuntimeError(f"Model {spec.model_id} is not available for production.")
    module = importlib.import_module(spec.adapter_module)
    cls = getattr(module, spec.adapter_class)
    return cls()
