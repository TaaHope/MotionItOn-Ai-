/** Verify Supabase Auth access tokens using the project's Auth user endpoint. */
export async function verifySupabaseAccessToken(token, { env = process.env, fetchImpl = fetch } = {}) {
  const baseUrl = String(env.SUPABASE_URL || env.NEXT_PUBLIC_SUPABASE_URL || '').replace(/\/+$/, '');
  const anonKey = String(env.SUPABASE_ANON_KEY || env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '');
  if (!baseUrl || !anonKey || !token) return null;
  if (!/^https:\/\//i.test(baseUrl)) throw new Error('Supabase Auth verification requires an HTTPS project URL.');
  const response = await fetchImpl(`${baseUrl}/auth/v1/user`, {
    method: 'GET',
    headers: { apikey: anonKey, Authorization: `Bearer ${token}` },
    cache: 'no-store',
    signal: AbortSignal.timeout(10000),
  });
  if (response.status === 401 || response.status === 403) return null;
  if (!response.ok) throw new Error(`Supabase Auth verification failed (${response.status}).`);
  const user = await response.json().catch(() => null);
  if (!user || typeof user.id !== 'string' || !user.id || user.id.length > 100) return null;
  const metadata = user.user_metadata && typeof user.user_metadata === 'object' ? user.user_metadata : {};
  const displayName = String(metadata.display_name || metadata.full_name || metadata.name || user.email || 'MotionItOn User').trim().slice(0, 70) || 'MotionItOn User';
  return { id: user.id, email: typeof user.email === 'string' ? user.email : `${user.id}@supabase.invalid`, displayName };
}
