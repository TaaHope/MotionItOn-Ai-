'use client';
import { FormEvent, useCallback, useEffect, useRef, useState } from 'react';
import { ArrowLeft, CheckCircle2, CircleAlert, Download, ExternalLink, Film, LoaderCircle, RefreshCw, Settings2, Sparkles, Share2 } from 'lucide-react';

type AiWorker = { id: string; name: string; model_id: string; enabled: boolean; is_default: boolean };

type AiJob = {
  id: string; status: 'queued' | 'running' | 'downloading' | 'completed' | 'failed'; progress: number;
  prompt: string; model: string; ratio: string; duration: number; category?: string; title?: string | null; error?: string | null;
  createdAt: string; finishedAt?: string | null; downloadUrl?: string | null;
};

const BACKEND_KEY = 'motioniton_ai_backend_url';
const ACCESS_KEY = 'motioniton_ai_backend_key';

export function AiVideoView({ onBack, initialPrompt = '', category = 'General', onProjectCreated, onChooseWorker, autoGenerate = false }: { onBack: () => void; initialPrompt?: string; category?: string; onChooseWorker?: () => void; autoGenerate?: boolean; onProjectCreated?: (title: string, durationSeconds: number, category: string, jobId: string, downloadUrl: string) => void }) {
  const formRef = useRef<HTMLFormElement>(null);
  const autoSubmitStarted = useRef(false);
  const [backendUrl, setBackendUrl] = useState('');
  const [accessKey, setAccessKey] = useState('');
  const [prompt, setPrompt] = useState(initialPrompt);
  const [model] = useState('motioniton-auto');
  const [ratio, setRatio] = useState('1280:720');
  const [duration, setDuration] = useState('5');
  const [customDuration, setCustomDuration] = useState('8');
  const [jobs, setJobs] = useState<AiJob[]>([]);
  const [workers, setWorkers] = useState<AiWorker[]>([]);
  const [selectedWorker, setSelectedWorker] = useState('');
  const [newWorkerName, setNewWorkerName] = useState('');
  const [workerBusy, setWorkerBusy] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [downloading, setDownloading] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [previewUrls, setPreviewUrls] = useState<Record<string, string>>({});
  const previewRequests = useRef(new Set<string>());
  const projectNotified = useRef(new Set<string>());

  const baseUrl = backendUrl.trim().replace(/\/+$/, '');
  const sessionToken = () => { try { return localStorage.getItem('motioniton_session') || ''; } catch { return ''; } };
  const requestHeaders = (includeEngineKey = false) => ({ Authorization: `Bearer ${sessionToken()}`, ...(includeEngineKey ? { 'X-API-Key': accessKey.trim() } : {}), 'Content-Type': 'application/json' });

  useEffect(() => {
    try {
      setBackendUrl(localStorage.getItem(BACKEND_KEY) || '');
      setSelectedWorker(localStorage.getItem('motioniton_selected_worker') || '');
      setAccessKey(localStorage.getItem(ACCESS_KEY) || '');
    } catch { /* storage may be disabled */ }
  }, []);

  const refreshWorkers = useCallback(async () => {
    if (!baseUrl || !accessKey.trim()) return;
    try {
      const response = await fetch(`${baseUrl}/api/ai/workers`, { headers: requestHeaders(true) });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `Worker registry returned HTTP ${response.status}.`);
      const list = Array.isArray(data.workers) ? data.workers as AiWorker[] : [];
      setWorkers(list);
      setSelectedWorker(current => { const saved = current || localStorage.getItem('motioniton_selected_worker') || ''; const next = list.some(item => item.id === saved && item.enabled) ? saved : ''; if (next) localStorage.setItem('motioniton_selected_worker', next); return next; });
    } catch (e) { setError(e instanceof Error ? e.message : String(e)); }
  }, [baseUrl, accessKey]);

  async function createWorker() {
    if (!newWorkerName.trim() || !baseUrl || !accessKey.trim()) return;
    setWorkerBusy(true); setError('');
    try {
      const response = await fetch(`${baseUrl}/api/ai/workers`, { method: 'POST', headers: requestHeaders(true), body: JSON.stringify({ name: newWorkerName.trim(), modelId: 'wan-2.2-ti2v-5b' }) });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `Worker creation failed (HTTP ${response.status}).`);
      setNewWorkerName(''); setMessage(`AI worker ${data.worker?.name || 'created'} added to the engine.`);
      await refreshWorkers();
    } catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { setWorkerBusy(false); }
  }

  async function deleteWorker(worker: AiWorker) {
    if (worker.is_default || !window.confirm(`Delete AI worker ${worker.name}?`)) return;
    setWorkerBusy(true); setError('');
    try {
      const response = await fetch(`${baseUrl}/api/ai/workers/${encodeURIComponent(worker.id)}`, { method: 'DELETE', headers: requestHeaders(true) });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `Worker deletion failed (HTTP ${response.status}).`);
      await refreshWorkers();
    } catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { setWorkerBusy(false); }
  }

  useEffect(() => { void refreshWorkers(); }, [refreshWorkers]);

  const refreshJobs = useCallback(async (showBusy = false) => {
    if (!baseUrl || !sessionToken()) return;
    if (showBusy) setRefreshing(true);
    try {
      const response = await fetch(`${baseUrl}/api/ai/jobs`, { headers: requestHeaders() });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `Backend returned HTTP ${response.status}.`);
      setJobs(Array.isArray(data.jobs) ? data.jobs as AiJob[] : []);
      setError('');
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally { if (showBusy) setRefreshing(false); }
  }, [baseUrl, accessKey]);

  useEffect(() => {
    if (!baseUrl || !sessionToken()) return;
    void refreshJobs();
    const timer = window.setInterval(() => { void refreshJobs(); }, 5000);
    return () => window.clearInterval(timer);
  }, [baseUrl, accessKey, refreshJobs]);

  // Keep a transferred production script in sync when the creator view receives a new plan.
  useEffect(() => { if (initialPrompt.trim()) setPrompt(initialPrompt); }, [initialPrompt]);
  useEffect(() => {
    if (!autoGenerate || autoSubmitStarted.current || !initialPrompt.trim() || !baseUrl || !accessKey.trim() || !sessionToken()) return;
    autoSubmitStarted.current = true;
    const timer = window.setTimeout(() => formRef.current?.requestSubmit(), 0);
    return () => window.clearTimeout(timer);
  }, [autoGenerate, initialPrompt, baseUrl, accessKey]);

  // Fetch completed MP4s with the authenticated download endpoint for inline previews.
  useEffect(() => {
    for (const job of jobs) {
      if (job.status !== 'completed' || !job.downloadUrl || projectNotified.current.has(job.id)) continue;
      projectNotified.current.add(job.id);
      onProjectCreated?.(job.title || job.prompt.slice(0, 80) || 'AI video', job.duration, job.category || category, job.id, job.downloadUrl);
    }
  }, [jobs, onProjectCreated, category]);

  useEffect(() => {
    const completed = jobs.filter(job => job.status === 'completed' && job.downloadUrl && !previewRequests.current.has(job.id));
    for (const job of completed) {
      previewRequests.current.add(job.id);
      void fetch(`${baseUrl}${job.downloadUrl}`, { headers: requestHeaders() })
        .then(response => { if (!response.ok) throw new Error('Preview unavailable'); return response.blob(); })
        .then(blob => setPreviewUrls(current => current[job.id] ? current : ({ ...current, [job.id]: URL.createObjectURL(blob) })))
        .catch(() => { previewRequests.current.delete(job.id); });
    }
  }, [jobs, baseUrl]);


  async function testConnection() {
    setRefreshing(true); setError(''); setMessage('');
    if (!baseUrl) { setError('Enter your MotionItOn engine URL first.'); setRefreshing(false); return; }
    try {
      const healthResponse = await fetch(`${baseUrl}/api/health`, { headers: requestHeaders(true) });
      if (!healthResponse.ok) throw new Error(`Backend health check failed (HTTP ${healthResponse.status}).`);
      const engineResponse = await fetch(`${baseUrl}/api/ai/engine`, { headers: requestHeaders(true) });
      const engine = await engineResponse.json().catch(() => ({}));
      if (!engineResponse.ok) throw new Error(engine.error || `Engine check failed (HTTP ${engineResponse.status}).`);
      const missing = Array.isArray(engine.checks) ? engine.checks.filter((item: {ok?:boolean;name?:string}) => !item.ok).map((item: {name?:string}) => item.name).filter(Boolean) : [];
      setMessage(engine.ready ? 'Backend connected and GPU engine is ready.' : `Backend connected. GPU readiness is pending${missing.length ? `: ${missing.join(', ')}` : '.'}`);
      await refreshJobs();
      await refreshWorkers();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally { setRefreshing(false); }
  }

  function saveConnection() {
    try {
      localStorage.setItem(BACKEND_KEY, baseUrl);
      localStorage.setItem(ACCESS_KEY, accessKey.trim());
      setMessage('Connection settings saved.');
      setError('');
      void refreshJobs(true);
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not save connection settings.'); }
  }

  async function downloadVideo(job: AiJob) {
    if (!job.downloadUrl) return;
    setDownloading(job.id); setError('');
    try {
      const response = await fetch(`${baseUrl}${job.downloadUrl}`, { headers: requestHeaders() });
      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.error || `Download failed (HTTP ${response.status}).`);
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a'); anchor.href = url; anchor.download = `MotionItOn-AI-${job.id}.mp4`;
      document.body.appendChild(anchor); anchor.click(); anchor.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
    } catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { setDownloading(null); }
  }

  async function shareVideo(job: AiJob) {
    if (!job.downloadUrl) return;
    setDownloading(job.id); setError('');
    try {
      const response = await fetch(`${baseUrl}${job.downloadUrl}`, { headers: requestHeaders() });
      if (!response.ok) throw new Error(`Could not prepare video for sharing (HTTP ${response.status}).`);
      const blob = await response.blob();
      const file = new File([blob], `MotionItOn-${job.id}.mp4`, { type: 'video/mp4' });
      if (navigator.canShare?.({ files: [file] }) && navigator.share) {
        await navigator.share({ title: 'Created with MotionItOn', text: 'My video created with MotionItOn.', files: [file] });
      } else {
        const url = URL.createObjectURL(blob);
        const anchor = document.createElement('a'); anchor.href = url; anchor.download = file.name;
        document.body.appendChild(anchor); anchor.click(); anchor.remove();
        window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
        setMessage('Video downloaded. Choose TikTok, Instagram, Facebook, YouTube or another installed app from your device share/upload screen.');
      }
    } catch (e) {
      if (e instanceof Error && e.name === 'AbortError') return;
      setError(e instanceof Error ? e.message : String(e));
    } finally { setDownloading(null); }
  }

  async function generate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(''); setMessage('');
    if (!baseUrl) return setError('Video generation is not connected.');
    if (!sessionToken()) return setError('Your session has expired. Please sign in again.');
    if (!accessKey.trim()) return setError('Video generation is not connected.');
    if (!prompt.trim()) return setError('Enter a prompt describing the video you want.');
    const requestedDuration = Number(duration === 'custom' ? customDuration : duration);
    if (!Number.isInteger(requestedDuration) || requestedDuration < 2 || requestedDuration > 300) return setError('Choose a duration between 2 seconds and 5 minutes.');
    setSubmitting(true);
    try {
      localStorage.setItem(BACKEND_KEY, baseUrl); localStorage.setItem(ACCESS_KEY, accessKey.trim());
      const categoryDirection: Record<string, string> = {
        General: '',
        Cooking: 'Create a realistic live-action cooking film with continuous visible hand actions, ingredients being handled, cutting, stirring, pouring or cooking, appetising close-ups and a finished dish. Use smooth camera movement and physically believable motion; avoid still-image pans and frozen hands. ',
        'Drama series': 'Create a live-action cinematic drama scene with realistic actors, natural body movement, expressive facial acting, believable interaction, consistent wardrobe and location, controlled camera movement and clear story progression. Avoid frozen or sliding characters and visual morphing. ',
        Nature: 'Create a real-world wildlife documentary shot. Show a clearly identifiable living animal performing natural continuous movement such as walking, feeding, flying, swimming or interacting with its habitat. Use realistic anatomy, natural light, believable physics and smooth camera movement. Do not use still-image pans, frozen subjects, morphing or sliding motion. ',
        Cartoons: 'Create a polished fully animated cartoon scene with clearly readable character actions, natural walk cycles, expressive faces, fluid body movement, stable character design and consistent backgrounds. Use smooth frame-to-frame animation, believable weight and timing; no frozen poses, sliding/dragging characters, morphing or abrupt jitter. ',
        Documentary: 'Create a factual live-action documentary sequence with real-world subject matter, continuous observable action, natural environments, realistic movement, smooth camera operation and a clear visual narrative. Avoid static still-image motion. '
      };
      const generationPrompt = `${categoryDirection[category] || ''}${prompt.trim()}`;
      const response = await fetch(`${baseUrl}/api/ai/generate`, {
        method: 'POST', headers: requestHeaders(true),
        body: JSON.stringify({ prompt: generationPrompt, model, ratio, duration: Number(duration === 'custom' ? customDuration : duration), workerId: selectedWorker || undefined, category, style: ({ General: 'general', Cooking: 'cooking', 'Drama series': 'cinematic', Nature: 'nature', Cartoons: 'cartoon', Documentary: 'documentary' } as Record<string,string>)[category] || 'realistic' })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `Generation request failed (HTTP ${response.status}).`);
      setMessage('Your video request has been added to the production queue.');
      await refreshJobs();
    } catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { setSubmitting(false); }
  }

  return <section className="settings-panel ai-video-panel">
    <header className="panel-head"><button className="secondary-button" onClick={onBack}><ArrowLeft size={15}/> Back</button><div><h2>{category === 'General' ? 'Text to Video' : `Create ${category} video`}</h2></div></header>

    <details className="ai-advanced-connection"><summary>Advanced connection</summary><article className="panel-card ai-connection-card"><div className="ai-connection-fields">
      <label>Service URL<input value={backendUrl} onChange={e => setBackendUrl(e.target.value)} placeholder="https://your-engine.example.com" autoComplete="url" /></label>
      <label>Access key<input value={accessKey} onChange={e => setAccessKey(e.target.value)} placeholder="Your engine access key" type="password" autoComplete="off" /></label>
    </div><div className="ai-form-actions"><button className="secondary-button" onClick={saveConnection}><CheckCircle2 size={15}/> Save</button><button className="secondary-button" onClick={() => void testConnection()} disabled={refreshing}><RefreshCw size={15} className={refreshing ? 'spin-icon' : ''}/> Test</button></div></article></details>

    <div className="ai-worker-choice"><button className="secondary-button" type="button" onClick={onChooseWorker}>Choose AI worker</button><span>{selectedWorker ? workers.find(w => w.id === selectedWorker)?.name || 'Selected worker' : 'Automatic worker selection'}</span></div>

    <form ref={formRef} className="panel-card ai-prompt-card" onSubmit={generate}><h3><Film size={17}/> {category === 'General' ? 'Create any video' : `Create your ${category} video`}</h3><label className="ai-prompt-label">Describe the scene<textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows={5} maxLength={1000} placeholder={category === 'General' ? 'Describe any video you want to create…' : `Describe your ${category.toLowerCase()} idea, scene, characters or story…`} required /></label><div className="ai-option-grid">
      
      <label>Aspect ratio<select value={ratio} onChange={e => setRatio(e.target.value)}><option value="1280:720">Landscape 16:9</option><option value="720:1280">Portrait 9:16</option></select></label>
      <label>Duration<select value={duration} onChange={e => setDuration(e.target.value)}>{[['5','5 seconds'],['20','20 seconds'],['60','1 minute'],['120','2 minutes'],['300','5 minutes']].map(([seconds,label]) => <option key={seconds} value={seconds}>{label}</option>)}<option value="custom">Custom duration</option></select></label>
      {duration === 'custom' && <label>Custom duration (2–300 seconds)<input type="number" min="2" max="300" step="1" value={customDuration} onChange={e => setCustomDuration(e.target.value)} required /></label>}
    </div><button className="ai-generate-button" type="submit" disabled={submitting || !prompt.trim()}>{submitting ? <LoaderCircle size={17} className="spin-icon"/> : <Sparkles size={17}/>} {submitting ? 'Submitting…' : 'Generate video'}</button></form>

    {message && <p className="ai-feedback ai-success" role="status"><CheckCircle2 size={16}/>{message}</p>}
    {error && <p className="ai-feedback ai-error" role="alert"><CircleAlert size={16}/>{error}</p>}

    <div className="ai-jobs-heading"><div><h3>Generated videos</h3></div><button className="secondary-button" onClick={() => void refreshJobs(true)} disabled={refreshing}><RefreshCw size={15}/> Refresh</button></div>
    {jobs.length === 0 ? <div className="queue-empty"><Film size={28}/><h3>No AI videos yet</h3><p>Your videos will appear here.</p></div> : <div className="queue-list">{jobs.map(job => <article className="panel-card ai-job-card" key={job.id}><div className="ai-job-top"><div><b>{job.prompt}</b><p>{new Date(job.createdAt).toLocaleString()} · {job.duration}s · {job.ratio === '720:1280' ? 'Portrait' : 'Landscape'}</p></div><span className={`ai-status ai-status-${job.status}`}>{job.status}</span></div>{['queued','running','downloading'].includes(job.status) && <div className="ai-progress-wrap"><progress max="100" value={job.progress}/><small>{job.status === 'downloading' ? 'Saving generated MP4…' : 'Your video is being created.'}</small></div>}{job.error && <p className="field-hint ai-error-text">{job.error}</p>}{job.status === 'completed' && <>{previewUrls[job.id] && <video src={previewUrls[job.id]} controls playsInline preload="metadata" aria-label={`Preview of ${job.prompt}`} />}<div className="ai-job-actions"><button className="secondary-button ai-download-link" disabled={downloading === job.id} onClick={() => void downloadVideo(job)}><Download size={15}/> {downloading === job.id ? 'Preparing…' : 'Download MP4'}</button><button className="secondary-button ai-download-link" disabled={downloading === job.id} onClick={() => void shareVideo(job)}><Share2 size={15}/> Share to apps</button></div></>}</article>)}</div>}
  </section>;
}
