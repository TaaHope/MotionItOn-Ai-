"""Model-specific MotionItOn generation adapters."""
