import test from 'node:test';
import assert from 'node:assert/strict';
import { runRemoteVideoGeneration, remoteWorkerHealth } from './remote-worker-client.mjs';

const env = { MOTIONITON_REMOTE_WORKER_URL: 'https://gpu.example.test', MOTIONITON_WORKER_TOKEN: 'x'.repeat(48), MOTIONITON_REMOTE_POLL_MS: '500', MOTIONITON_REMOTE_TIMEOUT_MS: '60000' };
test('remote worker submits, polls and downloads an MP4', async () => {
  const calls = []; let polls = 0;
  const fetchImpl = async (url, options = {}) => {
    calls.push([url, options]);
    if (url.endsWith('/jobs')) return new Response(JSON.stringify({ id: '123e4567-e89b-12d3-a456-426614174000' }), { status: 202 });
    if (url.endsWith('/download')) return new Response(new Uint8Array(2048), { status: 200 });
    polls++; return new Response(JSON.stringify({ status: 'completed', progress: 100, message: 'ready' }), { status: 200 });
  };
  const { outputPath, remoteJobId } = await runRemoteVideoGeneration({ prompt: 'Test', ratio: '1280:720', duration: 3, outputPath: '/tmp/motioniton-remote-client-test.mp4', env, fetchImpl });
  assert.equal(remoteJobId, '123e4567-e89b-12d3-a456-426614174000'); assert.equal(polls, 1);
  assert.equal(calls[0][1].headers.Authorization, `Bearer ${env.MOTIONITON_WORKER_TOKEN}`);
  const fs = await import('node:fs/promises'); assert.equal((await fs.stat(outputPath)).size, 2048); await fs.unlink(outputPath);
});
test('remote worker requires HTTPS and a long token', async () => {
  await assert.rejects(remoteWorkerHealth({ env: { ...env, MOTIONITON_REMOTE_WORKER_URL: 'http://gpu.example.test' } }), /HTTPS/);
  await assert.rejects(remoteWorkerHealth({ env: { ...env, MOTIONITON_WORKER_TOKEN: 'short' } }), /32 characters/);
});
