# MotionItOn on RunPod — privacy and isolation

## What is installed on the GPU

The RunPod machine is intended to run the **MotionItOn GPU rendering worker** (the Wan 2.2 TI2V-5B runtime, model weights, FFmpeg, and the worker service). It is not a shared public installation of the MotionItOn consumer app. The normal web/Android app remains the user's interface; it sends a generation job to the private control backend, which dispatches only the inputs needed for that job to the GPU worker.

## Who can see what

- **Other RunPod customers / other pod renters:** they do not get access to this pod's container, mounted volume, files, or network service merely because they use RunPod. Use a dedicated pod, private credentials, and do not publish an unauthenticated worker port.
- **The RunPod platform and the underlying host operator:** the provider necessarily operates the compute infrastructure. Do not treat a rented GPU as a place for information that must be hidden from the infrastructure provider. A provider with privileged host access may be technically capable of inspecting workloads or data while they are running. Review RunPod's current terms and security documentation before sending sensitive material.
- **People who use the MotionItOn app:** they must authenticate to MotionItOn. The backend must enforce per-user ownership on project, job, upload, and download operations. One user's job IDs must never authorize another user's downloads.

## Data boundary (required deployment design)

1. Keep account records, passwords, session tokens, billing data, and the main project database on the secured control-plane backend, not on the GPU worker.
2. Send the worker only the prompt, generation settings, and source assets required for the current job. Do not send account passwords, session tokens, or the RunPod API key.
3. Use a dedicated worker pod and private worker authentication. Do not expose the worker's generation port publicly without authentication and TLS.
4. Store final videos in the user's private application storage. Remove temporary source assets and intermediate frames from the worker after the job; do not rely on the worker disk as the user's permanent library.
5. Keep the RunPod API key only in the control-plane server's secret environment. Never put it in the Android app, browser bundle, Git repository, Docker image, or a worker environment variable.
6. Restrict persistent volumes and object storage to the control-plane service identity. Encrypt persistent storage where supported, and use HTTPS/TLS for all service-to-service traffic.
7. Configure job timeouts, maximum spend, upload limits, retention, and cleanup. Stop the pod after the queue is empty and the configured idle grace period expires.

## Important limitation

A dedicated pod isolates the workload from other customers; it does **not** make the workload invisible to the cloud provider or underlying host operator. Do not promise end-to-end confidentiality from the infrastructure provider. For highly sensitive material, use a provider and deployment model whose confidentiality guarantees meet the required threat model.

This document describes the intended security boundary. It is not proof that cloud provisioning, worker authentication, private networking, encryption, or automatic cleanup has been deployed. Verify those controls in the live deployment before using real customer data.
