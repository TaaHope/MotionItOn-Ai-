import { AccountService } from "./accountService";

export interface SessionResult { authenticated: boolean; userId?: string; error?: string }

export class AuthGuardService {
  static async checkActiveSession(): Promise<SessionResult> {
    try {
      const user = await AccountService.currentUser();
      return user?.id ? { authenticated: true, userId: user.id } : { authenticated: false };
    } catch (error) {
      return { authenticated: false, error: error instanceof Error ? error.message : "Session validation failed." };
    }
  }
}
