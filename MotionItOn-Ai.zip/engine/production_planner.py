"""Dependency-free production planning and visual-continuity prompt compiler."""
from __future__ import annotations
import re

STYLE_GUIDANCE = {
    "realistic": "Photorealistic live-action visual language, believable human anatomy, natural skin texture, physically plausible movement and real-world lighting.",
    "cinematic": "Cinematic composition, motivated camera movement, controlled depth of field, coherent screen direction and filmic lighting.",
    "cartoon": "Polished 3D animated family-film visual language, expressive but consistent character design, appealing shapes and smooth readable motion.",
    "documentary": "Observational documentary cinematography, naturalistic lighting, credible environments and restrained camera movement.",
    "cooking": "Clear food cinematography, appetising but realistic textures, hygienic preparation, accurate utensil handling and readable close-up action.",
    "nature": "Natural-history cinematography, realistic environments, coherent animal and plant anatomy, natural movement and environmental lighting.",
    "general": "Coherent cinematic visual storytelling, consistent lighting, believable movement and deliberate composition.",
}


def validate_character_bible(characters):
    if characters is None: return []
    if not isinstance(characters, list) or len(characters) > 8: raise ValueError("Character references must be a list of no more than eight characters.")
    result, seen = [], set()
    for index, character in enumerate(characters):
        if not isinstance(character, dict): raise ValueError(f"Character {index + 1} must be an object.")
        name = str(character.get("name", "")).strip()
        appearance = str(character.get("appearance", "")).strip()
        wardrobe = str(character.get("wardrobe", "")).strip()
        if not name or len(name) > 80 or not appearance or len(appearance) > 600 or len(wardrobe) > 300:
            raise ValueError(f"Character {index + 1} needs a name and appearance; field limits were exceeded.")
        key = name.casefold()
        if key in seen: raise ValueError(f"Duplicate character name: {name}.")
        seen.add(key)
        result.append({"name": name, "appearance": appearance, "wardrobe": wardrobe})
    return result


def compile_character_bible(characters):
    entries = validate_character_bible(characters)
    if not entries: return ""
    lines = ["CHARACTER CONTINUITY BIBLE — preserve these exact designs in every scene:"]
    for item in entries:
        line = f"{item['name']}: {item['appearance']}"
        if item["wardrobe"]: line += f" Wardrobe: {item['wardrobe']}"
        lines.append(line)
    lines.append("Do not change character identity, facial features, age, body proportions, hairstyle or wardrobe between shots unless the story explicitly describes a change.")
    return "\n".join(lines)


def build_scene_prompt(prompt, scene_number, total_scenes, style="general", character_bible="", ratio="1280:720"):
    base = str(prompt).strip()
    if not base or len(base) > 1000: raise ValueError("Scene prompt must contain 1–1000 characters.")
    if not isinstance(scene_number, int) or not isinstance(total_scenes, int) or not 1 <= scene_number <= total_scenes <= 60:
        raise ValueError("Scene number must be within the production sequence (maximum 60 scenes).")
    if ratio not in ("1280:720", "720:1280"): raise ValueError("Unsupported production aspect ratio.")
    style_key = str(style).strip().lower()
    guidance = STYLE_GUIDANCE.get(style_key, STYLE_GUIDANCE["general"])
    orientation = "wide landscape 16:9 composition" if ratio == "1280:720" else "vertical portrait 9:16 composition"
    continuity = "Maintain the same world, lighting logic, visual palette, geography and screen direction as the previous scene. Continue the action naturally; do not restart the story." if scene_number > 1 else "Establish the location, visual palette, lighting direction and screen geography so later scenes can continue consistently."
    parts = [base, f"Production scene {scene_number} of {total_scenes}.", guidance, orientation + ".", continuity]
    if character_bible.strip(): parts.append(character_bible.strip())
    parts.append("Avoid flicker, morphing faces, duplicate limbs, unstable objects, abrupt camera jumps, unreadable text and unintended scene changes.")
    return "\n".join(parts)


def build_production_manifest(title, prompt, duration, ratio="1280:720", style="general", characters=None, scene_seconds=10):
    if not isinstance(duration, int) or not 2 <= duration <= 300: raise ValueError("Duration must be between 2 and 300 seconds.")
    if not isinstance(scene_seconds, int) or not 2 <= scene_seconds <= 20: raise ValueError("Scene chunks must be 2–20 seconds.")
    bible = compile_character_bible(characters)
    count = (duration + scene_seconds - 1) // scene_seconds
    scenes, remaining = [], duration
    for index in range(1, count + 1):
        length = min(scene_seconds, remaining); remaining -= length
        scenes.append({"sceneNumber": index, "durationSeconds": length, "prompt": build_scene_prompt(prompt, index, count, style, bible, ratio)})
    return {"title": str(title or "Untitled production")[:120], "durationSeconds": duration, "ratio": ratio, "style": style, "characterBible": bible, "scenes": scenes}
