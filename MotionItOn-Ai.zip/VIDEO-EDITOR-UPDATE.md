# Video Editor Update

The local editor now supports:
- Importing images and video clips from the device.
- Configurable still-image duration and clip ordering/trimming.
- Cut, crossfade and fade transitions during MP4 export.
- Burned-in title/caption overlays with start/end time, size and vertical position.
- Multiple independent audio tracks with trim range, volume and start delay; tracks are mixed into the final MP4.
- Local FFmpeg WebAssembly rendering and MP4 download; no GPU or AI video engine is used.

Rendering is performed on the device and may be memory-intensive for long projects or high resolutions. The Android device export path must be verified on the target phone. This update has passed TypeScript/TSX transpilation syntax checks; a complete dependency-backed production build and physical-device render have not yet been run in this environment.
