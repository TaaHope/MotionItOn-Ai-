# Dependency management status

- Node runtime: GitHub Actions uses Node.js 22.
- Package manifest: `package.json` is included and required scripts are checked by the workflow.
- CI install: uses `npm ci` when a lockfile is present; otherwise temporarily falls back to `npm install`.
- Lockfile: `package-lock.json` could not be generated in this environment because npm registry access timed out and the dependency cache was incomplete. Generate it in a network-enabled environment with `npm install --package-lock-only --ignore-scripts`, review it, commit it, and then CI will use deterministic `npm ci`.
- Do not use `npm ci` without a lockfile.

Recommended local commands:

```bash
npm install --package-lock-only --ignore-scripts
npm ci
npm run build
npm run test:all
```
