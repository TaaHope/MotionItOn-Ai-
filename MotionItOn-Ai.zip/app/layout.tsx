import type { Metadata, Viewport } from "next";
import "./globals.css";
import { ErrorBoundary } from "./components/ErrorBoundary";

export const metadata: Metadata = {
  title: "MotionItOn-Ai — AI Video Creation Studio",
  description: "Create drama series, nature films, cartoons, cooking videos and documentaries with AI.",
  applicationName: "MotionItOn-Ai",
  manifest: "/manifest.webmanifest"
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#101014",
  viewportFit: "cover"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body><ErrorBoundary>{children}</ErrorBoundary></body>
    </html>
  );
}
