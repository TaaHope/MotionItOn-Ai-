#!/usr/bin/env python3
"""Manage MotionItOn AI workers without requiring a GPU."""
import argparse
import json
import sys
from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
from engine.worker_registry import list_workers, create_worker, update_worker, delete_worker

p = argparse.ArgumentParser(description="MotionItOn AI worker registry")
sub = p.add_subparsers(dest="command", required=True)
sub.add_parser("list")
add = sub.add_parser("add"); add.add_argument("--name", required=True); add.add_argument("--model-id", required=True); add.add_argument("--id"); add.add_argument("--description", default="")
edit = sub.add_parser("update"); edit.add_argument("--id", required=True); edit.add_argument("--name"); edit.add_argument("--enabled", choices=["true", "false"])
remove = sub.add_parser("delete"); remove.add_argument("--id", required=True)
a = p.parse_args()
try:
    if a.command == "list": result = list_workers()
    elif a.command == "add": result = create_worker(a.name, a.model_id, a.id, a.description)
    elif a.command == "update": result = update_worker(a.id, name=a.name, enabled=None if a.enabled is None else a.enabled == "true")
    else: result = {"deleted": delete_worker(a.id)}
    print(json.dumps(result))
except Exception as exc:
    print(json.dumps({"error": str(exc)}))
    raise SystemExit(2)
