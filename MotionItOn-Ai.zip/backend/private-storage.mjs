/** Private file-transfer helpers using provider-issued presigned HTTPS URLs.
 * The app backend owns authorization and URL issuance; signed URLs are never exposed to other users.
 */
import { createReadStream, createWriteStream } from 'node:fs';
import { mkdir, stat, rm } from 'node:fs/promises';
import path from 'node:path';
import { Readable, Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';

function validateSignedUrl(value) {
  const url = new URL(value);
  if (url.protocol !== 'https:' && url.hostname !== 'localhost' && url.hostname !== '127.0.0.1') throw new Error('Private storage transfers require HTTPS.');
  if (url.username || url.password) throw new Error('Credentials must not be embedded in storage URLs.');
  return url.toString();
}

export async function uploadToPresignedUrl(filePath, signedUrl, { contentType = 'application/octet-stream', fetchImpl = fetch } = {}) {
  const url = validateSignedUrl(signedUrl), fileStat = await stat(filePath);
  if (!fileStat.isFile() || fileStat.size < 1) throw new Error('Storage upload source must be a non-empty file.');
  const response = await fetchImpl(url, { method: 'PUT', headers: { 'Content-Type': contentType, 'Content-Length': String(fileStat.size) }, body: Readable.toWeb(createReadStream(filePath)), duplex: 'half' });
  if (!response.ok) throw new Error(`Private storage upload failed (${response.status}).`);
  return { uploaded: true, bytes: fileStat.size, etag: response.headers.get('etag') };
}

export async function downloadFromPresignedUrl(signedUrl, destination, { maxBytes = 2 * 1024 * 1024 * 1024, fetchImpl = fetch } = {}) {
  const url = validateSignedUrl(signedUrl), target = path.resolve(destination);
  const response = await fetchImpl(url, { method: 'GET', redirect: 'error' });
  if (!response.ok || !response.body) throw new Error(`Private storage download failed (${response.status}).`);
  const declared = Number(response.headers.get('content-length') || 0);
  if (declared > maxBytes) throw new Error('Private storage object exceeds the configured download limit.');
  await mkdir(path.dirname(target), { recursive: true });
  let bytes = 0;
  const limiter = new Transform({ transform(chunk, _encoding, callback) { bytes += chunk.length; if (bytes > maxBytes) callback(new Error('Private storage object exceeds the configured download limit.')); else callback(null, chunk); } });
  try { await pipeline(Readable.fromWeb(response.body), limiter, createWriteStream(target, { flags: 'wx' })); }
  catch (error) { await rm(target, { force: true }); throw error; }
  return { destination: target, bytes };
}
