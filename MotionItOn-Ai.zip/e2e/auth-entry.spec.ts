import { test, expect } from '@playwright/test';

test.describe('MotionItOn account entry', () => {
  test('loads the sign-in screen and exposes account controls', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('heading', { name: 'Welcome back' })).toBeVisible();
    await expect(page.getByLabel('Email address')).toBeVisible();
    await expect(page.getByLabel('Password')).toBeVisible();
    await expect(page.getByRole('button', { name: 'Sign in', exact: true })).toBeVisible();
  });

  test('switches to account creation and validates required fields', async ({ page }) => {
    await page.goto('/');
    await page.getByRole('button', { name: 'Create account', exact: true }).click();
    await expect(page.getByRole('heading', { name: 'Create your account' })).toBeVisible();
    await expect(page.getByLabel('Creator name')).toBeVisible();
    await expect(page.getByLabel('Email address')).toHaveAttribute('required', '');
    await expect(page.getByLabel('Password')).toHaveAttribute('minlength', '10');
    await expect(page.getByRole('button', { name: 'Create account', exact: true })).toBeVisible();
  });

  test('opens the password recovery form', async ({ page }) => {
    await page.goto('/');
    await page.getByRole('button', { name: 'Forgot password?' }).click();
    await expect(page.getByRole('heading', { name: 'Recover your account' })).toBeVisible();
    await expect(page.getByLabel('Email address')).toBeVisible();
    await expect(page.getByRole('button', { name: 'Send recovery link' })).toBeVisible();
  });

  test('returns from recovery to sign in', async ({ page }) => {
    await page.goto('/');
    await page.getByRole('button', { name: 'Forgot password?' }).click();
    await page.getByRole('button', { name: 'Sign in', exact: true }).click();
    await expect(page.getByRole('heading', { name: 'Welcome back' })).toBeVisible();
  });
});
