/** Supabase private Storage integration. Service credentials remain server-side. */
const cleanBase = value => String(value || '').replace(/\/+$/, '');

export function storageConfig(env = process.env) {
  const baseUrl = cleanBase(env.SUPABASE_URL || env.NEXT_PUBLIC_SUPABASE_URL);
  const serviceKey = String(env.SUPABASE_SERVICE_ROLE_KEY || '');
  const bucket = String(env.SUPABASE_STORAGE_BUCKET || 'motioniton-private').trim();
  if (!baseUrl || !/^https:\/\//i.test(baseUrl)) throw new Error('Set SUPABASE_URL to your HTTPS Supabase project URL.');
  if (!serviceKey || serviceKey.length < 20) throw new Error('Set SUPABASE_SERVICE_ROLE_KEY on the backend.');
  if (!/^[a-z0-9][a-z0-9._-]{1,62}$/i.test(bucket)) throw new Error('SUPABASE_STORAGE_BUCKET is invalid.');
  return { baseUrl, serviceKey, bucket };
}

function headers(key, extra = {}) { return { apikey: key, Authorization: `Bearer ${key}`, ...extra }; }
function encodeObjectPath(value) { return String(value).split('/').map(encodeURIComponent).join('/'); }
function resolveSignedUrl(value, baseUrl) {
  if (typeof value !== 'string' || !value) throw new Error('Supabase did not return a signed URL.');
  if (/^https:\/\//i.test(value)) return value;
  if (value.startsWith('/storage/v1/')) return new URL(value, baseUrl).toString();
  if (value.startsWith('/object/')) return `${baseUrl}/storage/v1${value}`;
  return new URL(value, `${baseUrl}/storage/v1/`).toString();
}
async function parseResponse(response, operation) {
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(`Supabase ${operation} failed (${response.status}): ${String(body.message || body.error || body.error_description || 'Storage request failed').slice(0, 400)}`);
  return body;
}

export async function createSignedUpload({ objectPath, contentType, env = process.env, fetchImpl = fetch, expiresIn = 600 }) {
  const config = storageConfig(env);
  const url = `${config.baseUrl}/storage/v1/object/upload/sign/${encodeURIComponent(config.bucket)}/${encodeObjectPath(objectPath)}`;
  const data = await parseResponse(await fetchImpl(url, {
    method: 'POST', headers: headers(config.serviceKey, { 'Content-Type': 'application/json' }),
    body: JSON.stringify({ expiresIn, upsert: false }), signal: AbortSignal.timeout(15000),
  }), 'signed upload URL creation');
  const signed = data.signedURL || data.url;
  return { signedUrl: resolveSignedUrl(signed, config.baseUrl), token: data.token || null, bucket: config.bucket, objectPath };
}

export async function createSignedDownload({ objectPath, env = process.env, fetchImpl = fetch, expiresIn = 300 }) {
  const config = storageConfig(env);
  const url = `${config.baseUrl}/storage/v1/object/sign/${encodeURIComponent(config.bucket)}/${encodeObjectPath(objectPath)}`;
  const data = await parseResponse(await fetchImpl(url, {
    method: 'POST', headers: headers(config.serviceKey, { 'Content-Type': 'application/json' }),
    body: JSON.stringify({ expiresIn }), signal: AbortSignal.timeout(15000),
  }), 'signed download URL creation');
  const signed = data.signedURL || data.signedUrl;
  return { signedUrl: resolveSignedUrl(signed, config.baseUrl), expiresIn };
}

export async function verifyObjectExists({ objectPath, env = process.env, fetchImpl = fetch }) {
  const config = storageConfig(env);
  const url = `${config.baseUrl}/storage/v1/object/${encodeURIComponent(config.bucket)}/${encodeObjectPath(objectPath)}`;
  const response = await fetchImpl(url, { method: 'HEAD', headers: headers(config.serviceKey), signal: AbortSignal.timeout(15000) });
  if (response.status === 404) return false;
  if (!response.ok) throw new Error(`Supabase object verification failed (${response.status}).`);
  return true;
}

export async function deleteObject({ objectPath, env = process.env, fetchImpl = fetch }) {
  const config = storageConfig(env);
  const url = `${config.baseUrl}/storage/v1/object/${encodeURIComponent(config.bucket)}/${encodeObjectPath(objectPath)}`;
  const response = await fetchImpl(url, { method: 'DELETE', headers: headers(config.serviceKey), signal: AbortSignal.timeout(15000) });
  if (!response.ok && response.status !== 404) throw new Error(`Supabase object deletion failed (${response.status}).`);
  return true;
}
