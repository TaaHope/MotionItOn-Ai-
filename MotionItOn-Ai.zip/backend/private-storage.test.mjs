import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { uploadToPresignedUrl, downloadFromPresignedUrl } from './private-storage.mjs';

test('private storage transfers use presigned URLs without embedding credentials', async () => {
  const dir = await mkdtemp(path.join(tmpdir(), 'motioniton-storage-'));
  try {
    const source = path.join(dir, 'source.mp4'), destination = path.join(dir, 'download', 'copy.mp4');
    await writeFile(source, Buffer.alloc(2048, 7));
    let uploadBytes = 0;
    const put = await uploadToPresignedUrl(source, 'http://127.0.0.1:9999/upload?signature=test', { fetchImpl: async (_url, options) => { const data = await new Response(options.body).arrayBuffer(); uploadBytes = data.byteLength; return new Response(null, { status: 200, headers: { etag: 'test-etag' } }); } });
    assert.equal(put.bytes, 2048); assert.equal(uploadBytes, 2048);
    const downloaded = await downloadFromPresignedUrl('http://127.0.0.1:9999/download?signature=test', destination, { fetchImpl: async () => new Response(Buffer.alloc(1024, 9), { status: 200, headers: { 'content-length': '1024' } }) });
    assert.equal(downloaded.bytes, 1024); assert.equal((await readFile(destination)).length, 1024);
    await assert.rejects(downloadFromPresignedUrl('http://127.0.0.1:9999/large', path.join(dir, 'too-large'), { maxBytes: 10, fetchImpl: async () => new Response(Buffer.alloc(20), { status: 200 }) }), /limit/);
  } finally { await rm(dir, { recursive: true, force: true }); }
});
