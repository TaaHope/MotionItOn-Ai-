#!/usr/bin/env python3
"""Non-invasive runtime diagnostics for the MotionItOn local video engine."""
import importlib.util
import json
import os
import shutil
import sys
from pathlib import Path


def main():
    checks = []
    def add(name, ok, detail):
        checks.append({"name": name, "ok": bool(ok), "detail": str(detail)})

    add("python", sys.version_info >= (3, 10), sys.version.split()[0])
    ffmpeg = os.environ.get("FFMPEG_PATH", "ffmpeg")
    ffmpeg_path = shutil.which(ffmpeg)
    add("ffmpeg", bool(ffmpeg_path), ffmpeg_path or f"'{ffmpeg}' was not found on PATH")

    torch_ok = False
    try:
        import torch
        torch_ok = True
        cuda = bool(torch.cuda.is_available())
        device = torch.cuda.get_device_name(0) if cuda else "No CUDA device detected"
        add("pytorch", True, f"{torch.__version__}; CUDA {'available' if cuda else 'unavailable'}")
        add("cuda_gpu", cuda, device)
    except Exception as exc:
        add("pytorch", False, f"PyTorch import failed: {exc}")
        add("cuda_gpu", False, "Cannot check CUDA without a working PyTorch installation")

    for package in ("diffusers", "transformers", "accelerate", "safetensors"):
        spec = importlib.util.find_spec(package)
        add(package, spec is not None, "installed" if spec else "not installed in this Python environment")

    model_id = os.environ.get("MOTIONITON_VIDEO_MODEL", "Wan-AI/Wan2.2-TI2V-5B-Diffusers")
    cache_root = Path(os.environ.get("HF_HUB_CACHE", Path.home() / ".cache" / "huggingface" / "hub"))
    cached = False
    if Path(model_id).is_dir():
        cached = True
    elif "/" in model_id and not model_id.startswith("/"):
        cached = (cache_root / ("models--" + model_id.replace("/", "--"))).exists()
    add("model_cache", cached, "model directory/cache detected" if cached else f"{model_id} is not detected in the default Hugging Face cache; first run may need internet access to download weights")

    required = {c["name"] for c in checks if c["ok"]}
    ready = all(item["ok"] for item in checks if item["name"] in {"python", "ffmpeg", "pytorch", "cuda_gpu", "diffusers", "transformers", "accelerate", "safetensors"})
    print(json.dumps({"ready": ready, "model": model_id, "checks": checks}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
