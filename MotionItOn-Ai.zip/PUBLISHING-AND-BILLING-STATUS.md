# MotionItOn publishing and billing integration status

## Included in this update

- Completed AI video jobs now offer **Download MP4** and **Share to apps**.
- On supported Android/mobile browsers, Share to apps uses the native operating-system share sheet and passes the actual MP4 file (not a URL). Installed apps appear only when the OS reports that they accept the video file. This can include TikTok, Instagram, Facebook, YouTube, WhatsApp and other compatible apps.
- If file sharing is unavailable, MotionItOn downloads the MP4 so the user can upload it in the destination app.
- Dashboard account icon opens Settings. Profile settings support a local profile picture, display name, email-change request and password change.
- Settings now includes a Subscription & Credits section that clearly reports payment status.

## Not yet connected; do not advertise as live

### Direct platform publishing

The native share sheet transfers the actual video file to a compatible installed app. It is not server-side auto-publishing. Direct one-tap publishing from MotionItOn to TikTok, Instagram, Facebook, YouTube and other platforms requires separate developer applications, OAuth consent, review/approval where required, per-user account linking, upload APIs, and token storage/refresh. Those platform credentials and approvals are not present in this project. Do not claim that remote auto-publishing is enabled.

### PayPal payments and credits

The supplied merchant email is recorded as `PAYPAL_MERCHANT_EMAIL` in `.env.example`. An email address alone cannot charge a customer or confirm a payment. Live billing requires a PayPal Business account with REST app Client ID and Secret, webhook configuration, HTTPS deployment, server-side order creation/capture, webhook signature verification, refund/dispute handling, and a durable server-side credit ledger. These secrets must be configured only on the backend. The subscription screen intentionally reports that checkout is not active; it does not collect card details or pretend to take payment.

### Video previews

Category preview videos are externally hosted stock footage and need internet access. The category previews are muted and loop in the dashboard. Drama retains its existing preview and spotlight clips. Review each source's license and attribution details before a production release.
