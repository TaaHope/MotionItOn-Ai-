export type SceneTransition = "cut" | "fade" | "dissolve" | "slide";
export interface StitchClip { path: string; durationSeconds: number; transition?: SceneTransition; hasAudio?: boolean }
export interface StitchOptions { width?: number; height?: number; fps?: number; crf?: number; preset?: string; transitionSeconds?: number }

/** Build a shell-free FFmpeg argv for normalized clips, optional audio and rendered transitions. */
export function buildFfmpegStitchCommand(clips: StitchClip[], outputPath: string, options: StitchOptions = {}) {
  if (!Array.isArray(clips) || clips.length === 0) throw new Error("At least one clip is required.");
  if (typeof outputPath !== "string" || !outputPath.trim()) throw new Error("An output path is required.");
  for (const [i, clip] of clips.entries()) {
    if (!clip || typeof clip.path !== "string" || !clip.path.trim() || !Number.isFinite(clip.durationSeconds) || clip.durationSeconds <= 0) throw new Error(`Clip ${i + 1} needs a path and positive duration.`);
    if (clip.transition && !["cut", "fade", "dissolve", "slide"].includes(clip.transition)) throw new Error(`Clip ${i + 1} has an unsupported transition.`);
    if (clip.hasAudio !== undefined && typeof clip.hasAudio !== "boolean") throw new Error(`Clip ${i + 1} has an invalid hasAudio flag.`);
  }
  const width = options.width ?? 1280, height = options.height ?? 720, fps = options.fps ?? 30;
  const crf = options.crf ?? 20, preset = options.preset ?? "medium", transitionSeconds = options.transitionSeconds ?? 0.75;
  if (![width, height].every(v => Number.isInteger(v) && v >= 160 && v <= 3840 && v % 2 === 0)) throw new Error("Output dimensions must be even integers between 160 and 3840.");
  if (!Number.isInteger(fps) || fps < 1 || fps > 60) throw new Error("FPS must be between 1 and 60.");
  if (!Number.isInteger(crf) || crf < 0 || crf > 51) throw new Error("CRF must be between 0 and 51.");
  if (!Number.isFinite(transitionSeconds) || transitionSeconds < 0 || transitionSeconds > 10) throw new Error("Transition duration must be between 0 and 10 seconds.");

  const args: string[] = [];
  clips.forEach(clip => args.push("-i", clip.path));
  const audioIndexes: number[] = []; let nextInput = clips.length;
  clips.forEach((clip, index) => {
    if (clip.hasAudio === false) { audioIndexes[index] = nextInput++; args.push("-f", "lavfi", "-t", String(clip.durationSeconds), "-i", "anullsrc=channel_layout=stereo:sample_rate=48000"); }
    else audioIndexes[index] = index;
  });

  const filters: string[] = [];
  clips.forEach((clip, index) => {
    filters.push(`[${index}:v:0]trim=duration=${clip.durationSeconds},setpts=PTS-STARTPTS,scale=${width}:${height}:force_original_aspect_ratio=decrease,pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=${fps},format=yuv420p,settb=AVTB[v${index}]`);
    filters.push(`[${audioIndexes[index]}:a:0]atrim=duration=${clip.durationSeconds},asetpts=PTS-STARTPTS,aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo[a${index}]`);
  });
  let videoLabel = "v0", audioLabel = "a0", timelineDuration = clips[0].durationSeconds;
  for (let index = 1; index < clips.length; index++) {
    const transition = clips[index].transition ?? "cut";
    const requested = transition === "cut" ? 0.001 : transitionSeconds;
    const duration = Math.min(requested, clips[index - 1].durationSeconds / 2, clips[index].durationSeconds / 2);
    const offset = Math.max(0, timelineDuration - duration);
    const nextVideo = `vx${index}`, nextAudio = `ax${index}`;
    const transitionName = transition === "slide" ? "slideleft" : transition === "dissolve" ? "dissolve" : "fade";
    filters.push(`[${videoLabel}][v${index}]xfade=transition=${transitionName}:duration=${duration.toFixed(3)}:offset=${offset.toFixed(3)}[${nextVideo}]`);
    filters.push(`[${audioLabel}][a${index}]acrossfade=d=${duration.toFixed(3)}:c1=tri:c2=tri[${nextAudio}]`);
    videoLabel = nextVideo; audioLabel = nextAudio; timelineDuration += clips[index].durationSeconds - duration;
  }
  args.push("-filter_complex", filters.join(";"), "-map", `[${videoLabel}]`, "-map", `[${audioLabel}]`, "-c:v", "libx264", "-preset", preset, "-crf", String(crf), "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2", "-pix_fmt", "yuv420p", "-movflags", "+faststart", "-y", outputPath);
  return { command: "ffmpeg", args };
}

export interface ProductionScene { sceneNumber: number; title: string; visualPrompt: string; narrationText: string; durationSeconds: number }
/** Creates an animated storyboard video from a production plan, not AI-generated footage. */
export async function generateFinishedVideoFromPlan(scenes: ProductionScene[], onProgress?: (progress: number) => void): Promise<Blob> {
  if (typeof window === "undefined" || !("MediaRecorder" in window)) throw new Error("Video recording is not supported in this browser.");
  if (!scenes.length) throw new Error("Add at least one scene to generate a storyboard video.");
  if (scenes.some(scene => !Number.isFinite(scene.durationSeconds) || scene.durationSeconds <= 0)) throw new Error("Every scene needs a positive duration.");
  const canvas = document.createElement("canvas"); canvas.width = 1280; canvas.height = 720;
  const ctx = canvas.getContext("2d"); if (!ctx) throw new Error("Canvas rendering is unavailable.");
  const stream = canvas.captureStream(30);
  const mimeType = ["video/webm;codecs=vp9", "video/webm;codecs=vp8", "video/webm"].find(type => MediaRecorder.isTypeSupported(type));
  if (!mimeType) throw new Error("This browser does not support WebM recording.");
  const recorder = new MediaRecorder(stream, { mimeType }), chunks: BlobPart[] = [];
  const durationTotal = scenes.reduce((sum, scene) => sum + scene.durationSeconds, 0);
  return new Promise((resolve, reject) => {
    let sceneIndex = 0, sceneElapsed = 0, last = performance.now(), totalElapsed = 0, stopped = false;
    const cleanup = () => stream.getTracks().forEach(track => track.stop());
    recorder.ondataavailable = event => { if (event.data.size) chunks.push(event.data); };
    recorder.onerror = () => { if (!stopped) { stopped = true; cleanup(); reject(new Error("Browser video recorder failed.")); } };
    recorder.onstop = () => { cleanup(); resolve(new Blob(chunks, { type: mimeType.split(";")[0] })); };
    const wrapText = (text: string, x: number, y: number, maxWidth: number, lineHeight: number) => {
      const words = (text || "").split(/\s+/); let line = "", lineY = y;
      for (const word of words) { const next = line ? `${line} ${word}` : word; if (ctx.measureText(next).width > maxWidth && line) { ctx.fillText(line, x, lineY); line = word; lineY += lineHeight; if (lineY > y + lineHeight * 4) break; } else line = next; }
      if (line && lineY <= y + lineHeight * 4) ctx.fillText(line, x, lineY);
    };
    const draw = () => {
      if (stopped) return;
      const now = performance.now(), delta = Math.min(0.1, (now - last) / 1000); last = now; sceneElapsed += delta; totalElapsed += delta;
      const scene = scenes[sceneIndex];
      ctx.fillStyle = "#09090b"; ctx.fillRect(0, 0, canvas.width, canvas.height);
      const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height); gradient.addColorStop(0, "#12141a"); gradient.addColorStop(1, "#1e2318"); ctx.fillStyle = gradient; ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = "#cbfe01"; ctx.font = "bold 30px sans-serif"; ctx.fillText(`SCENE ${scene.sceneNumber}: ${scene.title}`.slice(0, 64), 56, 90);
      ctx.fillStyle = "#fff"; ctx.font = "24px sans-serif"; wrapText(scene.visualPrompt, 56, 160, 1120, 36);
      ctx.fillStyle = "#a1a1aa"; ctx.font = "italic 21px sans-serif"; wrapText(scene.narrationText, 56, 420, 1120, 32);
      ctx.fillStyle = "#cbfe01"; ctx.fillRect(56, 650, 1168 * Math.min(1, totalElapsed / durationTotal), 6);
      onProgress?.(Math.min(99, Math.round(totalElapsed / durationTotal * 100)));
      if (sceneElapsed >= scene.durationSeconds) { sceneIndex++; sceneElapsed = 0; }
      if (sceneIndex >= scenes.length) { stopped = true; onProgress?.(100); recorder.stop(); return; }
      requestAnimationFrame(draw);
    };
    recorder.start(250); requestAnimationFrame(draw);
  });
}
