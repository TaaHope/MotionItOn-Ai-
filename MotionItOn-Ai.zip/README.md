# MotionItOn-Ai

Android-first, cross-platform video creation studio. The project keeps the existing Next.js interface, Capacitor Android packaging, Electron Windows packaging, FFmpeg editing/export, and the self-hosted Wan 2.2 GPU worker (LTX is retained only as an optional legacy adapter).

## RunPod GPU and privacy

The first cloud GPU test targets the NVIDIA RTX 3090 (24 GB VRAM), subject to live availability. Read [RUNPOD-DEPLOYMENT.md](RUNPOD-DEPLOYMENT.md) for the intended provisioning lifecycle and [RUNPOD-PRIVACY.md](RUNPOD-PRIVACY.md) for exactly what the GPU host and other RunPod customers can access. The GPU worker is a dedicated rendering service, not a shared public copy of the MotionItOn app. The cloud provider/underlying host operator must still be treated as a privileged infrastructure party. Automatic RunPod provisioning and worker deployment are not yet live in this ZIP.

## Current architecture and cost model

- **Story writing:** Use ChatGPT in the normal ChatGPT app/site to write an episode, dialogue, and scene descriptions. Copy/paste the material into MotionItOn-Ai. This project does not call the ChatGPT API, Claude API, or any paid LLM API.
- **Application:** Android is the primary client. The Web build is retained. Windows packaging is retained for a future release.
- **Video generation:** The included Python worker runs open-weight LTX-Video locally on the machine hosting the worker. It does not run the video model inside the Android phone.
- **GPU:** A compatible NVIDIA/CUDA GPU is required for practical LTX inference. The current code does not yet provision, start, stop, or pay for an hourly cloud GPU automatically. A GPU worker/backend must be deployed separately and made reachable over HTTPS.
- **Editing/export:** FFmpeg backend and browser-side FFmpeg/WASM editing/export components are included.

## Build

```bash
npm install
npm run build
```

The Next.js configuration uses static export (`out/`) for the Web and Capacitor builds.

## Android

```bash
npm install
npm run build
npx cap add android   # only if android/ does not exist
npx cap sync android
cd android && ./gradlew assembleDebug
```

## AI video engine

See [ENGINE-ANDROID-FIRST.md](ENGINE-ANDROID-FIRST.md). The current generation endpoint accepts a single visual prompt and produces a short 2–20 second clip. It is not yet a complete script-to-movie pipeline: episode parsing, automatic shot planning, persistent character identity, voice generation/lip-sync, and automatic multi-shot episode assembly remain future work. Do not advertise those as available until implemented and tested.

The generation worker and Node backend must run on a compatible GPU host for LTX inference. Android and static Web hosting alone cannot execute the Python/CUDA model. See [MOTIONITON-ARCHITECTURE.md](MOTIONITON-ARCHITECTURE.md) for the VPS-independent target architecture and current gaps.

## Tests

```bash
npm run test:backend
node --check backend/server.mjs
python -m py_compile engine/generate_video.py engine/doctor.py
```

Unit tests and CI validate application/build logic, not real GPU inference. A real generation test requires model weights and a compatible GPU.

## Accounts, projects and job security (Phase 3)
The backend exposes account registration, login, session validation, logout, profile updates and authenticated password changes. Passwords are hashed with Node.js scrypt; session tokens are stored as SHA-256 hashes and expire after 30 days. Password changes revoke other active sessions and issue a new session to the current device.

Projects can be listed, saved, deleted and synchronized per account. The app keeps a separate local project cache per signed-in account and synchronizes it with the account backend when reachable. Render jobs and AI generation jobs are associated with the creating account; listing, status and download endpoints only return jobs belonging to that account. The AI engine key is sent separately in `X-API-Key`; it is not an account session token.

Configure the backend using `.env.example`. Set `MOTIONITON_DATA_DIR` to persistent storage and `ALLOWED_ORIGINS` to the exact app origins. Keep `MOTIONITON_API_KEY` secret. Old jobs created before ownership fields were added are intentionally hidden because they have no verified owner.

Email verification and password-reset email delivery are not simulated. They require an SMTP or transactional email provider. Social publishing labels are configurable, but direct publishing still requires each platform's OAuth credentials, scopes and any required approval. Cloud storage requires an external storage account and credentials. GPU generation requires installed Python/PyTorch/Diffusers/FFmpeg dependencies, model weights and a compatible GPU host.

## Tests and readiness

```bash
npm run test:backend
node --check backend/server.mjs
python -m py_compile engine/generate_video.py engine/doctor.py
```

The backend unit tests validate request normalization and worker progress handling, not a production deployment or real GPU inference. See `PRE-GPU-CHECKLIST.md` and `backend/API-CONTRACT.md` for completed work and remaining external requirements.

## Consolidated development progress

See [`DEVELOPMENT-CHECKLIST.md`](./DEVELOPMENT-CHECKLIST.md) for the 12-work-package checklist and deferred external dependencies. The checklist is maintained across development sessions; do not mark work complete until implementation and available tests/build checks pass.


## Project backups

The Projects screen supports exporting an individual project backup or exporting all projects in one `.motioniton.json` file. Use **Import backup** to restore a single-project or multi-project backup. Import checks the MotionItOn-Ai backup marker and schema version, ignores malformed project entries, preserves existing projects, and gives restored duplicates new IDs. Backups are portable JSON files; keep a copy outside the device. Local project storage is scoped by the signed-in account on the current device. Cloud synchronisation requires a configured backend and is not a substitute for independent backups.

## Corrected implementation modules

The archive includes the account-aware project/category/series/scene/character services, local generation queue, subtitle and audio-track services, settings and authentication guards, a production workspace component, a local-FFmpeg video editor component, and a root error boundary. Run `npm run test:regression` to execute the service regression tests (Node.js 22+). The video editor exports using the browser FFmpeg pipeline; source media must be available to the browser. Cloud project saves require a valid signed-in session and the configured backend URL.


## Supabase account setup (required for online accounts)

The app's registration and sign-in screens do not ask users for a server URL. The Supabase project URL and public anon/publishable key are injected at build time by GitHub Actions.

1. Create a Supabase project.
2. In Supabase Dashboard, open **Project Settings → API** and copy the Project URL and public anon/publishable key. Never use the `service_role` secret key in the app.
3. In GitHub, open **Settings → Secrets and variables → Actions → Variables** and create:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
4. If you are using the existing Supabase sign-in integration, run [`supabase/user_projects.sql`](./supabase/user_projects.sql) for account/project synchronization. This is not required for RunPod video generation or backend MP4 storage; generated videos are stored on the MotionItOn backend persistent disk at `/data/renders`.
5. In Supabase **Authentication → URL Configuration**, add the production app URL and any web preview URL to the allowed redirect/site URL list.
6. In Supabase **Authentication → Providers → Email**, choose whether email confirmation is required. If enabled, users must verify their email before signing in.
7. Run the GitHub Actions build again. All newly built Web/Android/Windows clients will have the account service configured automatically.

The anon/publishable key is designed for client use; security comes from Supabase Auth and the row-level security policies in the SQL file. Do not add a Supabase service-role key to GitHub Variables or the application.

The Node backend in `backend/server.mjs` remains a separate optional service for AI generation/render jobs. Supabase handles account authentication and cloud project records. GitHub Actions builds the application but does not host a continuously running API or database.


### Long-form generation and audio export
MotionItOn accepts AI video durations up to five minutes. Longer productions are generated as consecutive scenes (maximum 20 seconds per scene) on the same loaded GPU pipeline, then stitched into one MP4. The editor can also trim an imported audio track and include that selected audio in the exported MP4.

## AI worker profiles

The Engine now supports named AI worker profiles. Open **Create with AI → AI workers** after configuring the backend URL and engine access key to create, select, refresh and remove profiles. Worker profiles are persisted in `engine/workers.json` (runtime-created and git-ignored). The default worker is protected. The management CLI is also available:

```bash
python engine/manage_workers.py list
python engine/manage_workers.py add --name "My Wan 2.2 Worker" --model-id wan-2.2-ti2v-5b
python engine/manage_workers.py update --id WORKER_ID --enabled false
python engine/manage_workers.py delete --id WORKER_ID
```

Only implemented model adapters can be registered as runnable workers. At this stage, profiles bind to the existing LTX legacy adapter; they are not independent parallel GPU processes. Adding a profile does not install model weights or guarantee that the model can fit on a particular GPU.

### Phase 1 full verification

Run `npm install`, then `npm run build`, then `npx playwright install chromium` and `npm run test:e2e`. The `Phase 1 Full Verification` GitHub Actions workflow performs the production web build, Chromium smoke tests, Android debug APK build, and Windows installer build, then publishes the resulting artifacts. It can be started from GitHub Actions using **Run workflow**. Set the repository Actions variables `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, and `NEXT_PUBLIC_APP_URL` for configured account-service builds. Browser tests currently cover the public account-entry screens; authenticated project/editor workflows still require a configured test Supabase project and test credentials.

## Phase 4/5 implementation

The project now includes a private remote GPU worker service, RunPod control-plane adapter/CLI, HTTPS worker communication, presigned object-storage transfer helpers, FFmpeg cinematic transitions including silent clips, and dependency-free character continuity/prompt planning. See `PHASE4-5-IMPLEMENTATION.md` for configuration and verification commands. These additions do not provision a paid GPU automatically; RunPod provisioning is an explicit operator action.


### ChatGPT script queue connection
See `CHATGPT-INTEGRATION-SETUP.md` and import `openapi/chatgpt-script-bridge.yaml` into a configured ChatGPT GPT Action.


### Default video model
MotionItOn uses Wan 2.2 TI2V-5B as its default generation model. The default worker is bound to `wan-2.2-ti2v-5b`; automatic requests do not silently fall back to LTX. LTX legacy remains an optional explicitly selected adapter. Wan 2.2 TI2V-5B is configured for the official 24 GB offload profile; CPU offloading is enabled by default for the RTX 3090. A real GPU generation smoke test is still required before production readiness can be confirmed.


## RunPod generation architecture

MotionItOn-Ai is the user-facing application. Its backend queues jobs, communicates with the authenticated RunPod Wan 2.2 worker, downloads completed MP4s and retains them on a persistent backend volume mounted at `/data`. RunPod provides GPU compute only. Generated videos are served by MotionItOn and remain available after the GPU pod is stopped. See `RUNPOD-DEPLOYMENT.md` and `STORAGE-AND-WAN-SETUP.md`. The production backend must use `MOTIONITON_GENERATION_MODE=remote` and a persistent `/data` volume.
