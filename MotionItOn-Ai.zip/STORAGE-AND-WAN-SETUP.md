# MotionItOn-Ai — Wan 2.2 and video retention

## Architecture and storage ownership

MotionItOn-Ai's backend is the permanent home of generated videos. RunPod is only the temporary GPU compute worker. The backend downloads each completed MP4 from the worker and stores it beneath `MOTIONITON_DATA_DIR/renders` (production default `/data/renders`). The SQLite job/project database is also stored under `/data`. Attach a persistent backend disk/volume at `/data`; otherwise videos and records can be lost when the backend container is replaced.

Generated-video retention does not require Supabase Storage, a storage bucket, or a service-role key. Existing Supabase Auth settings, if already used for account sign-in, are independent and may remain.

The GPU pod's persistent `/workspace` volume is only for the Wan model cache and temporary worker files. It is not the permanent My Projects storage. The worker transfers completed MP4 files back to the backend before the job is marked completed.

## Wan 2.2 default

The default model is `wan-2.2-ti2v-5b` (Wan 2.2 TI2V-5B). The RTX 3090 has 24 GB VRAM. The adapter uses CPU model offloading and VAE memory-saving features where supported. Start with a short 2–5 second test clip. The actual checkpoint load and inference must be tested on the deployed GPU; source-level configuration is not proof of successful generation.

## Backend environment

```dotenv
MOTIONITON_DATA_DIR=/data
MOTIONITON_GENERATION_MODE=remote
MOTIONITON_REMOTE_WORKER_URL=https://POD_ID-8790.proxy.runpod.net
MOTIONITON_WORKER_TOKEN=THE_SAME_RANDOM_SECRET_AS_THE_GPU_POD
MOTIONITON_REMOTE_TIMEOUT_MS=21600000
MOTIONITON_REMOTE_POLL_MS=2000
```

The backend also needs its normal `MOTIONITON_API_KEY`, public HTTPS URL and correct `ALLOWED_ORIGINS`. Configure the backend URL and engine key in MotionItOn-Ai Settings. Never expose the RunPod worker token or RunPod API key in the browser/mobile app.

## GPU pod environment

```dotenv
MOTIONITON_WORKER_TOKEN=THE_SAME_RANDOM_SECRET_AS_THE_BACKEND
MOTIONITON_WORKER_PORT=8790
MOTIONITON_REMOTE_DATA=/workspace/jobs
HF_HOME=/workspace/.cache/huggingface
MOTIONITON_WAN_CPU_OFFLOAD=true
MOTIONITON_SELECTED_MODEL=wan-2.2-ti2v-5b
```

Build and deploy the custom `Dockerfile.gpu-worker` image. A generic PyTorch template without the MotionItOn worker code is not enough. Expose `8790/http` and attach a persistent GPU volume at `/workspace` for model caching.

## End-to-end verification

1. Backend `/api/health` reports `generationMode: remote` and `remoteWorkerConfigured: true`.
2. Authenticated `/api/ai/remote-worker-health` returns healthy.
3. Submit a short test through the MotionItOn Generate button.
4. Confirm progress updates in the app.
5. Confirm the backend downloads the completed MP4 into `/data/renders`.
6. Confirm the job/project is marked completed and appears in My Projects.
7. Stop the RunPod GPU pod and verify that the MP4 still plays from MotionItOn.

The last test proves that video retention is independent of GPU availability.
