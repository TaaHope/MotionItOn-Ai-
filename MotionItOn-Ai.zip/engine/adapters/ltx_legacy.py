"""Compatibility adapter for the existing Diffusers LTX-Video pipeline.

This is the legacy text-to-video adapter, not LTX-2. It deliberately does not
claim image conditioning or native audio support.
"""
from __future__ import annotations
import gc
import os
from pathlib import Path
import torch
from diffusers import LTXPipeline
from diffusers.utils import export_to_video
from .base import VideoGenerationAdapter, GenerationRequest

class LTXLegacyAdapter(VideoGenerationAdapter):
    def __init__(self):
        self.pipe = None

    def load(self, device: str = "cuda") -> None:
        if device != "cuda" or not torch.cuda.is_available():
            raise RuntimeError("A CUDA-compatible NVIDIA GPU is required for LTX inference.")
        props = torch.cuda.get_device_properties(0)
        total_gb = props.total_memory / (1024 ** 3)
        free_gb = torch.cuda.mem_get_info()[0] / (1024 ** 3)
        if total_gb < 18 or free_gb < 14:
            raise RuntimeError(f"Insufficient safe GPU memory for LTX-Video: {free_gb:.1f} GB free of {total_gb:.1f} GB.")
        dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        model_id = os.environ.get("MOTIONITON_VIDEO_MODEL", "Lightricks/LTX-Video")
        self.pipe = LTXPipeline.from_pretrained(
            model_id, torch_dtype=dtype,
            local_files_only=os.environ.get("MOTIONITON_LOCAL_FILES_ONLY", "false").lower() == "true",
        )
        self.pipe.to(device)
        if hasattr(self.pipe, "enable_vae_tiling"):
            self.pipe.enable_vae_tiling()
        if hasattr(self.pipe, "enable_attention_slicing"):
            self.pipe.enable_attention_slicing()

    def generate(self, request: GenerationRequest, progress=None) -> Path:
        if self.pipe is None:
            raise RuntimeError("LTX legacy adapter has not been loaded.")
        if request.input_image is not None:
            raise RuntimeError("The installed LTX legacy adapter supports text-to-video only; image-to-video is not enabled.")
        # Preserve the existing worker's 1:1 frame-to-output-FPS behavior.
        frames = request.duration * request.fps + 1
        def callback(_pipe, step, _timestep, callback_kwargs):
            if progress:
                progress(min(94, 5 + int(88 * (step + 1) / max(1, request.steps))), "Generating LTX video frames.")
            return callback_kwargs
        generator = None
        if request.seed is not None:
            generator = torch.Generator(device="cuda").manual_seed(int(request.seed))
        with torch.inference_mode():
            result = self.pipe(
                prompt=request.prompt,
                negative_prompt=request.negative_prompt or "blurry, low quality, flicker, jitter, distorted anatomy, watermark",
                width=request.width, height=request.height, num_frames=frames,
                num_inference_steps=request.steps, guidance_scale=3.0,
                callback_on_step_end=callback, generator=generator,
            )
        request.output_path.parent.mkdir(parents=True, exist_ok=True)
        export_to_video(result.frames[0], str(request.output_path), fps=request.fps)
        del result
        return request.output_path

    def unload(self):
        if self.pipe is not None:
            del self.pipe
            self.pipe = None
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
