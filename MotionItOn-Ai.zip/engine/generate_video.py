#!/usr/bin/env python3
"""MotionItOn self-hosted video worker with model-registry integration.

Preserves the existing CLI contract and 2-300 second scene-based workflow.
Wan 2.2 TI2V-5B is the default generation adapter. LTX remains available as an optional legacy adapter.
"""
from __future__ import annotations
import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


def emit(kind: str, **fields):
    print(json.dumps({"type": kind, **fields}), flush=True)


def run_command(command: list[str], timeout: int = 3600):
    proc = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
    if proc.returncode != 0:
        raise RuntimeError((proc.stderr or proc.stdout or "Command failed.")[-3000:])
    return proc


def validate_video(ffprobe: str, output: Path, expected_duration: int):
    if not output.is_file() or output.stat().st_size < 1024:
        raise RuntimeError("The encoder did not create a valid MP4 file.")
    probe = run_command([
        ffprobe, "-v", "error", "-show_entries", "format=duration",
        "-show_entries", "stream=codec_type,codec_name,width,height,r_frame_rate",
        "-of", "json", str(output),
    ], timeout=45)
    import json as _json
    metadata = _json.loads(probe.stdout)
    streams = metadata.get("streams", [])
    if not any(s.get("codec_type") == "video" for s in streams):
        raise RuntimeError("Generated MP4 contains no video stream.")
    duration = float(metadata.get("format", {}).get("duration", 0))
    if duration <= 0 or abs(duration - expected_duration) > max(1.0, expected_duration * 0.02):
        raise RuntimeError(f"Generated video duration {duration:.2f}s does not match requested {expected_duration}s.")
    return metadata


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--prompt", required=True)
    parser.add_argument("--ratio", choices=["1280:720", "720:1280"], default="1280:720")
    parser.add_argument("--duration", type=int, choices=range(2, 301), default=5)
    parser.add_argument("--quality", choices=["standard", "high"], default=os.environ.get("MOTIONITON_QUALITY", "high"))
    parser.add_argument("--output", required=True)
    parser.add_argument("--style", default=os.environ.get("MOTIONITON_STYLE", "general"))
    parser.add_argument("--model", default=os.environ.get("MOTIONITON_SELECTED_MODEL", "motioniton-auto"))
    parser.add_argument("--worker-id", default=os.environ.get("MOTIONITON_WORKER_ID"))
    parser.add_argument("--negative-prompt", default=os.environ.get("MOTIONITON_NEGATIVE_PROMPT", ""))
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--character-bible", default="", help="JSON character continuity references (text only).")
    args = parser.parse_args()

    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    ffmpeg = os.environ.get("FFMPEG_PATH", "ffmpeg")
    ffprobe = os.environ.get("FFPROBE_PATH", "ffprobe")
    if not shutil.which(ffmpeg) or not shutil.which(ffprobe):
        emit("error", message="FFmpeg and FFprobe are required for MP4 encoding and validation.")
        return 2

    adapter = None
    try:
        import torch
        from engine.production_planner import compile_character_bible, build_scene_prompt
        from engine.model_registry import load_adapter
        from engine.worker_registry import select_worker
        from engine.adapters.base import GenerationRequest
        if not torch.cuda.is_available():
            raise RuntimeError("No CUDA-compatible NVIDIA GPU was detected.")

        worker_profile, selected = select_worker(
            worker_id=args.worker_id, style=args.style, task="text_to_video", requested_model=args.model
        )
        try:
            import json as _json
            character_bible = compile_character_bible(_json.loads(args.character_bible) if args.character_bible else [])
        except Exception as exc:
            raise ValueError(f"Invalid character continuity references: {exc}") from exc
        emit("progress", progress=2, message=f"Selected AI worker {worker_profile['name']} using {selected.display_name}.")
        adapter = load_adapter(selected)
        adapter.load("cuda")

        fps = int(os.environ.get("MOTIONITON_VIDEO_FPS", "24" if args.quality == "high" else "16"))
        if fps not in (16, 20, 24, 25, 30):
            raise ValueError("MOTIONITON_VIDEO_FPS must be 16, 20, 24, 25 or 30.")
        width, height = (768, 432) if args.ratio == "1280:720" else (432, 768)
        steps = int(os.environ.get("MOTIONITON_VIDEO_STEPS", "30" if args.quality == "high" else "22"))
        if not 10 <= steps <= 60:
            raise ValueError("MOTIONITON_VIDEO_STEPS must be between 10 and 60.")

        scene_lengths = []
        remaining = args.duration
        while remaining:
            length = min(5 if selected.model_id == "wan-2.2-ti2v-5b" else 20, remaining)
            scene_lengths.append(length)
            remaining -= length

        emit("progress", progress=4, message=f"{args.quality.title()} profile: {width}x{height}, {fps} FPS, {steps} steps.")
        with tempfile.TemporaryDirectory(prefix="motioniton-scenes-") as temp_dir:
            temp = Path(temp_dir)
            scene_files = []
            for index, scene_duration in enumerate(scene_lengths):
                scene_number = index + 1
                scene_prompt = build_scene_prompt(args.prompt, scene_number, len(scene_lengths), args.style, character_bible, args.ratio)
                request = GenerationRequest(
                    prompt=scene_prompt,
                    output_path=temp / f"scene-{scene_number:03d}-raw.mp4",
                    duration=scene_duration,
                    width=width,
                    height=height,
                    fps=fps,
                    steps=steps,
                    negative_prompt=args.negative_prompt,
                    seed=(args.seed + index) if args.seed is not None else None,
                    style=args.style,
                )
                def on_progress(value, message):
                    overall = 5 + int(87 * (index + max(0, min(100, value)) / 100) / len(scene_lengths))
                    emit("progress", progress=min(93, overall), message=f"Scene {scene_number}/{len(scene_lengths)}: {message}")
                raw = adapter.generate(request, progress=on_progress)
                normalized = temp / f"scene-{scene_number:03d}.mp4"
                run_command([
                    ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", str(raw),
                    "-t", str(scene_duration), "-an", "-c:v", "libx264", "-preset",
                    os.environ.get("MOTIONITON_ENCODE_PRESET", "medium"), "-crf",
                    os.environ.get("MOTIONITON_EXPORT_CRF", "18"), "-pix_fmt", "yuv420p",
                    "-r", str(fps), "-movflags", "+faststart", str(normalized),
                ])
                scene_files.append(normalized)
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()

            emit("progress", progress=94, message="Joining scenes into the final MP4.")
            concat = temp / "scenes.txt"
            concat.write_text("".join(f"file '{p.as_posix()}'\n" for p in scene_files), encoding="utf-8")
            run_command([
                ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0",
                "-i", str(concat), "-t", str(args.duration), "-c:v", "libx264", "-preset",
                os.environ.get("MOTIONITON_ENCODE_PRESET", "medium"), "-crf",
                os.environ.get("MOTIONITON_EXPORT_CRF", "18"), "-pix_fmt", "yuv420p",
                "-movflags", "+faststart", str(output),
            ])

        validate_video(ffprobe, output, args.duration)
        emit("progress", progress=100, message="Your complete MP4 is ready.")
        return 0
    except Exception as exc:
        emit("error", message=f"Video generation failed: {str(exc)[:2500]}")
        return 5
    finally:
        if adapter is not None:
            try:
                adapter.unload()
            except Exception as cleanup_error:
                emit("warning", message=f"GPU cleanup warning: {str(cleanup_error)[:500]}")

if __name__ == "__main__":
    sys.exit(main())
