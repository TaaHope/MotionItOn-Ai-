import test from 'node:test';
import assert from 'node:assert/strict';
import { createSignedUpload, createSignedDownload, verifyObjectExists, storageConfig } from './supabase-storage.mjs';

const env = { SUPABASE_URL: 'https://example.supabase.co', SUPABASE_SERVICE_ROLE_KEY: 's'.repeat(40), SUPABASE_STORAGE_BUCKET: 'motioniton-private' };
test('storage config refuses missing service credentials and non-HTTPS project URLs', () => {
  assert.throws(() => storageConfig({}), /SUPABASE_URL/);
  assert.throws(() => storageConfig({ ...env, SUPABASE_URL: 'http://example.supabase.co' }), /HTTPS/);
  assert.throws(() => storageConfig({ ...env, SUPABASE_SERVICE_ROLE_KEY: '' }), /SERVICE_ROLE_KEY/);
});
test('creates private signed upload and download URLs without exposing service key', async () => {
  const calls = [];
  const fetchImpl = async (url, options) => {
    calls.push({ url, options });
    return new Response(JSON.stringify({ signedURL: '/storage/v1/object/sign/motioniton-private/u1/p1/video.mp4?token=abc', token: 'upload-token' }), { status: 200 });
  };
  const upload = await createSignedUpload({ objectPath: 'u1/p1/video.mp4', contentType: 'video/mp4', env, fetchImpl });
  const download = await createSignedDownload({ objectPath: 'u1/p1/video.mp4', env, fetchImpl });
  assert.match(upload.signedUrl, /^https:\/\/example\.supabase\.co\//);
  assert.equal(upload.token, 'upload-token');
  assert.match(download.signedUrl, /token=abc/);
  assert.equal(calls.length, 2);
  assert.equal(calls[0].options.headers.Authorization, `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`);
});
test('object verification distinguishes missing objects', async () => {
  assert.equal(await verifyObjectExists({ objectPath: 'u/p/a.mp4', env, fetchImpl: async () => new Response(null, { status: 404 }) }), false);
  assert.equal(await verifyObjectExists({ objectPath: 'u/p/a.mp4', env, fetchImpl: async () => new Response(null, { status: 200 }) }), true);
});

test('normalizes Supabase storage-relative signed URLs under /storage/v1', async () => {
  const fetchImpl = async () => new Response(JSON.stringify({ signedURL: '/object/upload/sign/motioniton-private/u1/p1/a.mp4?token=abc' }), { status: 200 });
  const result = await createSignedUpload({ objectPath: 'u1/p1/a.mp4', contentType: 'video/mp4', env, fetchImpl });
  assert.match(result.signedUrl, /^https:\/\/example\.supabase\.co\/storage\/v1\/object\/upload\/sign\//);
});
