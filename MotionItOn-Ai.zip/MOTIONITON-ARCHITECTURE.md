# MotionItOn-Ai — Android-first, no-LLM-API architecture

## Agreed product direction

1. Android is the main production client.
2. Web remains available as a secondary client.
3. Windows build remains in the repository for possible future publication.
4. No Claude API or ChatGPT API is required. Story and episode writing happens in ChatGPT separately; the user pastes the resulting material into MotionItOn-Ai.
5. The user's Windows VPS is not a required component of the target deployment.
6. Video inference runs on an on-demand cloud GPU worker, not on the Android phone.

## Current implementation status

- Existing project/editor UI: present.
- Capacitor Android packaging: configured.
- Static Next.js Web export: configured.
- Electron Windows packaging: configured.
- FFmpeg rendering and local export components: present.
- Python LTX-Video inference worker: present.
- Node API job queue, status, diagnostics and MP4 download endpoints: present.
- Direct cloud GPU provisioning/auto-shutdown: **not implemented**.
- Remote worker orchestration and secure job dispatch: **not implemented**.
- Paste-a-whole-episode script parser and shot planner: **not implemented**.
- Character identity/reference management across scenes: **not implemented**.
- Voice generation, lip-sync and episode-level audio mix: **not implemented**.

## Target deployment without the VPS

- Publish the static Web build to a static host, or distribute the Android APK.
- Deploy the Node API and Python worker to an on-demand GPU host, or split the API/control plane from the GPU worker.
- Store job metadata and finished MP4s in persistent storage/object storage.
- The Android/Web app connects to the deployed API over HTTPS.
- GPU start/stop must be handled by a provider-specific adapter with credentials stored server-side only. Never put GPU-provider credentials or the backend secret in the mobile app.

## Cost controls required before public use

- Explicit maximum GPU runtime per job/session.
- Automatic idle shutdown and cleanup of failed instances.
- Per-user generation quotas and upload limits.
- Persistent output storage with retention rules.
- Authentication, authorization, HTTPS, rate limiting and audit logs.
- Show estimated/actual compute cost before generation where provider data permits.

## Current generation limitation

The existing `/api/ai/generate` endpoint accepts one prompt and generates one short 2–20 second clip. A one-minute cinematic episode requires a shot list, multiple generated clips, continuity references, dialogue/audio, retries, and final assembly. The present code must not be described as delivering that full pipeline yet. Build and verify each stage incrementally, beginning with a real short clip on a rented GPU.
