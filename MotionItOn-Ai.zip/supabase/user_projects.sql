-- Run this once in Supabase Dashboard > SQL Editor.
-- Each signed-in user can access only their own saved MotionItOn projects.

create table if not exists public.user_projects (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  payload jsonb not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, id)
);

alter table public.user_projects enable row level security;

drop policy if exists "Users can read their own MotionItOn projects" on public.user_projects;
create policy "Users can read their own MotionItOn projects"
  on public.user_projects for select
  to authenticated
  using (auth.uid() = user_id);

drop policy if exists "Users can create their own MotionItOn projects" on public.user_projects;
create policy "Users can create their own MotionItOn projects"
  on public.user_projects for insert
  to authenticated
  with check (auth.uid() = user_id);

drop policy if exists "Users can update their own MotionItOn projects" on public.user_projects;
create policy "Users can update their own MotionItOn projects"
  on public.user_projects for update
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "Users can delete their own MotionItOn projects" on public.user_projects;
create policy "Users can delete their own MotionItOn projects"
  on public.user_projects for delete
  to authenticated
  using (auth.uid() = user_id);

create index if not exists user_projects_updated_at_idx
  on public.user_projects (user_id, updated_at desc);
