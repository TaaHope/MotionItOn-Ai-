#!/usr/bin/env node
import { RunPodProvider } from '../backend/runpod-provider.mjs';
const [command, podId] = process.argv.slice(2);
const provider = new RunPodProvider();
try {
  if (command === 'create') {
    const result = await provider.createGpuPod({
      name: process.env.RUNPOD_POD_NAME || 'motioniton-gpu-worker',
      containerDiskGb: Number(process.env.RUNPOD_CONTAINER_DISK_GB || 50),
      volumeGb: Number(process.env.RUNPOD_VOLUME_GB || 0),
      volumeMountPath: process.env.RUNPOD_VOLUME_MOUNT_PATH || '/workspace',
      env: { MOTIONITON_WORKER_TOKEN: process.env.MOTIONITON_WORKER_TOKEN || '', MOTIONITON_WORKER_PORT: '8790' },
    });
    const podId = result?.id || result?.podId;
    const workerUrl = podId ? provider.workerProxyUrl(podId, Number(process.env.MOTIONITON_WORKER_PORT || 8790)) : null;
    process.stdout.write(`${JSON.stringify({ pod: result, workerUrl, next: podId ? `node scripts/runpod-control.mjs wait ${podId}` : 'Check the RunPod console for the new pod ID.' }, null, 2)}\n`);
  } else if (command === 'wait' && podId) {
    const workerUrl = provider.workerProxyUrl(podId, Number(process.env.MOTIONITON_WORKER_PORT || 8790));
    const health = await provider.waitForWorker(workerUrl, process.env.MOTIONITON_WORKER_TOKEN || '', { timeoutMs: Number(process.env.RUNPOD_WORKER_START_TIMEOUT_MS || 600000) });
    process.stdout.write(`${JSON.stringify({ podId, workerUrl, health }, null, 2)}\n`);
  } else if (command === 'status' && podId) process.stdout.write(`${JSON.stringify(await provider.getPod(podId), null, 2)}\n`);
  else if (command === 'terminate' && podId) process.stdout.write(`${JSON.stringify(await provider.terminatePod(podId), null, 2)}\n`);
  else throw new Error('Usage: node scripts/runpod-control.mjs create | wait <pod-id> | status <pod-id> | terminate <pod-id>');
} catch (error) { console.error(error.message); process.exitCode = 1; }
