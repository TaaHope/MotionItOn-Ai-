"use client";

import { useEffect, useMemo, useState } from "react";
import { renderVideoLocally } from "./services/localRenderer";
import { saveRenderOutput } from "./services/renderJobStore";
import { AccountService } from "./services/accountService";
import { SettingsView } from "./components/SettingsView";
import { ProjectProductionManager } from "./components/ProjectProductionManager";
import type { CharacterProfile } from "./services/characterEngine";
import type { EpisodeDetail } from "./services/seriesAndSceneEngine";
import { CategoryManager } from "./services/categoryEngine";
import { QueueView } from "./components/QueueView";
import { AiVideoView } from "./components/AiVideoView";
import { AiWorkersView } from "./components/AiWorkersView";
import { SocialMediaStudio } from "./components/SocialMediaStudio";
import { PixVerseHomeNav } from "./components/PixVerseHomeNav";
import { ProductionPlanActionBanner } from "./components/ProductionPlanActionBanner";
import {
  Activity, ArrowLeft, ArrowRight, BookOpen, Clapperboard, Clock3, Film,
  Leaf, Menu, MonitorPlay, Plus, Search, Settings2, Sparkles,
  ChefHat, FileText, WandSparkles, X, Play, Smartphone, CircleUserRound, Folder,
  Upload, Scissors, Trash2, ChevronUp, ChevronDown, Download, Music2, SlidersHorizontal, Video, Pause, RotateCcw, Sun, Moon
} from "lucide-react";

type Category = string;
type Clip = { id: string; name: string; url: string; duration: number; start: number; end: number; type: string; mediaKind: "video" | "image" };

type Project = {
  id: string;
  title: string;
  category: Category;
  format: string;
  duration: string;
  orientation: string;
  createdAt: string;
  status: "Draft" | "Completed" | "In progress";
  generatedVideoUrl?: string;
  aiJobId?: string;
  episodeCount?: number;
  storyPackage?: string;
  updatedAt?: string;
  notes?: string;
  characters?: CharacterProfile[];
  episodes?: EpisodeDetail[];
};

const builtInCategories: { name: Category; detail: string; icon: typeof Film; tag: string }[] = [
  { name: "General", detail: "Any subject, style or creative idea", icon: Video, tag: "GENERAL" },
  { name: "Drama series", detail: "Real actors, dialogue, cliffhangers and episodes", icon: Clapperboard, tag: "SERIES" },
  { name: "Nature", detail: "Wildlife, landscapes, oceans and natural wonders", icon: Leaf, tag: "NATURE" },
  { name: "Cartoons", detail: "Animated characters, stories and kids content", icon: Sparkles, tag: "ANIMATION" },
  { name: "Cooking", detail: "Recipes, food films and step-by-step demonstrations", icon: ChefHat, tag: "FOOD" },
  { name: "Documentary", detail: "Educational films, travel and narrated explainers", icon: FileText, tag: "FACTUAL" }
];



function StudioHome({ onSignOut, userId }: { onSignOut: () => void; userId: string }) {
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  useEffect(() => { const saved = localStorage.getItem("motioniton-theme"); const next = saved === "light" ? "light" : "dark"; setTheme(next); document.documentElement.dataset.theme = next; }, []);
  const toggleTheme = () => { const next = theme === "dark" ? "light" : "dark"; setTheme(next); document.documentElement.dataset.theme = next; localStorage.setItem("motioniton-theme", next); };
  const [projects, setProjects] = useState<Project[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<Category | "All">("All");
  const [customCategories, setCustomCategories] = useState(() => CategoryManager.getCategories().filter(item => item.isCustom));
  const categories = useMemo(() => [...builtInCategories, ...customCategories.map(item => ({ name: item.name, detail: "Custom project category", icon: Folder, tag: item.tag }))], [customCategories]);
  const [showCreate, setShowCreate] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState<Category>("General");
  const [format, setFormat] = useState("Single video");
  const [episodeCount, setEpisodeCount] = useState(3);
  const [duration, setDuration] = useState("30 seconds");
  const [orientation, setOrientation] = useState("Vertical 9:16");
  const [notice, setNotice] = useState("");
  const [importing, setImporting] = useState(false);
  const [showEditor, setShowEditor] = useState(false);
  const [videoPreview, setVideoPreview] = useState<{ url: string; title: string; project: Project } | null>(null);
  const [productionProjectId, setProductionProjectId] = useState<string | null>(null);
  const [editingProjectId, setEditingProjectId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editCategory, setEditCategory] = useState<Category>("Drama series");
  const [editFormat, setEditFormat] = useState("Single video");
  const [editDuration, setEditDuration] = useState("30 seconds");
  const [editOrientation, setEditOrientation] = useState("Vertical 9:16");
  const [editNotes, setEditNotes] = useState("");
  const [editStoryPackage, setEditStoryPackage] = useState("");
  const [activePanel, setActivePanel] = useState<"studio" | "projects" | "settings" | "account" | "queue" | "ai" | "workers" | "social">("studio");
  const [videoPrompt, setVideoPrompt] = useState("");
  const [autoExecuteWorkplan, setAutoExecuteWorkplan] = useState(false);
  const [executingWorkplanId, setExecutingWorkplanId] = useState("");
  const [generationCategory, setGenerationCategory] = useState<Category>("General");
  const [clips, setClips] = useState<Clip[]>([]);
  const [selectedClip, setSelectedClip] = useState<string | null>(null);
  const [transition, setTransition] = useState("Crossfade");
  const [exportResolution, setExportResolution] = useState("1080p");
  const [exportOrientation, setExportOrientation] = useState("Keep original");
  const [exportFps, setExportFps] = useState("30 fps");
  const [audioMode, setAudioMode] = useState("Keep original audio");
  const [audioTrackUrl, setAudioTrackUrl] = useState("");
  const [audioTrackName, setAudioTrackName] = useState("");
  const [audioTrackDuration, setAudioTrackDuration] = useState(0);
  const [audioTracks, setAudioTracks] = useState<Array<{id:string;name:string;url:string;duration:number;start:number;end:number;volume:number;delay:number}>>([]);
  const [titleText, setTitleText] = useState("");
  const [titleStart, setTitleStart] = useState(0);
  const [titleEnd, setTitleEnd] = useState(5);
  const [titleSize, setTitleSize] = useState(56);
  const [titlePosition, setTitlePosition] = useState<"top"|"center"|"bottom">("center");
  const [audioTrimStart, setAudioTrimStart] = useState(0);
  const [audioTrimEnd, setAudioTrimEnd] = useState(0);
  const [isPreviewPlaying, setIsPreviewPlaying] = useState(false);
  const [editorNotice, setEditorNotice] = useState("Import clips, adjust trims, then render an MP4 locally on this device.");
  const [rendering, setRendering] = useState(false);
  const [renderProgress, setRenderProgress] = useState(0);
  const selectedClipData = clips.find((clip) => clip.id === selectedClip) ?? clips[0] ?? null;
  const totalClipDuration = clips.reduce((sum, clip) => sum + Math.max(0, clip.end - clip.start), 0);

  const projectStorageKey = `motioniton-projects-${userId}`;
  useEffect(() => {
    let active = true;
    async function loadProjects() {
      let local: Project[] = [];
      try { local = JSON.parse(localStorage.getItem(projectStorageKey) || '[]') as Project[]; } catch { local = []; }
      const merged = [...local];
      const mergeItems = (items: Project[]) => {
        for (const item of items) {
          const index = merged.findIndex(existing => existing.id === item.id);
          if (index < 0) merged.push(item);
          else if (new Date(item.updatedAt || 0).getTime() > new Date(merged[index].updatedAt || 0).getTime()) merged[index] = item;
        }
      };
      try { mergeItems(await AccountService.listProjects<Project>()); } catch { /* backend/local projects remain available */ }
      try {
        const base = (localStorage.getItem('motioniton_ai_backend_url') || '').replace(/\/+$/, '');
        const token = localStorage.getItem('motioniton_session') || '';
        if (base && token) {
          const response = await fetch(`${base}/api/projects`, { headers: { Authorization: `Bearer ${token}` } });
          if (response.ok) { const data = await response.json(); mergeItems(Array.isArray(data.projects) ? data.projects as Project[] : []); }
        }
      } catch { /* offline projects remain available from local storage */ }
      if (active) setProjects(merged);
      if (active) setLoaded(true);
    }
    void loadProjects();
    return () => { active = false; };
  }, [projectStorageKey]);

  useEffect(() => {
    if (!loaded) return;
    try {
      localStorage.setItem(projectStorageKey, JSON.stringify(projects));
    } catch {
      setNotice("Project changes are in memory, but this device could not save them. Export a backup before leaving this page.");
    }
    AccountService.syncProjects(projects).catch(() => {
      // Offline mode is supported; the local project copy remains the source of truth until sync is available.
    });
  }, [projects, loaded, projectStorageKey]);

  const filteredProjects = useMemo(() => projects.filter((p) => {
    const matchesCategory = activeCategory === "All" || p.category === activeCategory;
    const matchesSearch = p.title.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  }), [projects, activeCategory, search]);

  function openCreate(selected?: Category) {
    if (selected) setCategory(selected);
    setTitle("");
    setNotice("");
    setShowCreate(true);
  }

  function buildStoryPackage(projectTitle: string, projectCategory: Category, count: number, videoDuration: string, frame: string) {
    const categoryGuides: Record<Category, { premise: string; beats: string[]; visual: string }> = {
      General: { premise: "A clear creative idea becomes a visually engaging short film.", beats: ["Open with a strong visual hook.", "Introduce the subject and setting.", "Develop the central action or idea.", "Build to a memorable moment.", "Finish with a clear visual payoff."], visual: "cinematic composition, purposeful camera movement, polished lighting and coherent visual storytelling" },
      "Drama series": { premise: "A hidden truth threatens to change the lives of everyone involved.", beats: ["Introduce the lead character and their ordinary world.", "Reveal a secret that changes the stakes.", "Force the lead to make a difficult choice.", "Introduce a consequence or betrayal.", "End with a revelation that drives the next episode."], visual: "cinematic close-ups, expressive reactions, dramatic practical lighting" },
      Nature: { premise: "Follow a remarkable species through a challenge in its natural habitat.", beats: ["Establish the habitat and the featured species.", "Show a daily survival challenge.", "Reveal an adaptation or surprising behaviour.", "Show the impact of weather, predators or habitat.", "Close with a hopeful conservation fact or natural moment."], visual: "natural light, wide habitat shots, wildlife details, realistic documentary camera" },
      Cartoons: { premise: "A curious little hero learns that courage and kindness solve unexpected problems.", beats: ["Introduce the hero and a colourful world.", "Present a funny problem or mystery.", "Let the first attempt fail in a surprising way.", "Bring friends together to solve the problem.", "Finish with a warm lesson and a playful visual gag."], visual: "expressive 3D animation, readable silhouettes, bright colour, consistent character design" },
      Cooking: { premise: "Teach viewers to prepare a delicious dish with clear, achievable steps.", beats: ["Show the finished dish and explain what makes it special.", "Introduce ingredients and preparation.", "Demonstrate the first essential cooking steps.", "Show timing, texture and the key technique.", "Plate the dish and recap serving tips."], visual: "overhead food shots, close-up textures, clean kitchen lighting, clear ingredient labels" },
      Documentary: { premise: "Explain a real-world subject through evidence, human context and clear narration.", beats: ["Open with a compelling question or striking fact.", "Give essential background and context.", "Present evidence, examples or expert perspectives.", "Explain consequences and competing viewpoints.", "Summarise what viewers should understand or investigate next."], visual: "factual establishing shots, interview framing, maps or labelled explanatory graphics" }
    };
    const guide = categoryGuides[projectCategory] || categoryGuides.General;
    const lines = [
      `MOTIONITON-AI STORY PACKAGE`, `Title: ${projectTitle}`, `Category: ${projectCategory}`, `Format: ${count > 1 ? `${count}-episode series` : "Single video"}`, `Target duration: ${videoDuration}`, `Frame: ${frame}`, "", `CORE PREMISE`, guide.premise, "", "CREATIVE DIRECTION", guide.visual, "", "EPISODE / SCENE PLAN"
    ];
    for (let i = 1; i <= count; i++) {
      const beat = guide.beats[(i - 1) % guide.beats.length];
      const escalation = count > 1 ? (i === count ? "Finale: resolve the main arc while leaving a memorable final image." : `Advance the overall story and plant a question for episode ${i + 1}.`) : "Build to a clear payoff and satisfying ending.";
      lines.push("", `${count > 1 ? "EPISODE" : "VIDEO"} ${i}: ${count > 1 ? `${projectTitle} — Chapter ${i}` : projectTitle}`, `Purpose: ${beat}`, `Opening: Start with a visual hook related to ${projectCategory.toLowerCase()}.`, `Main action: ${beat} Develop the moment with a clear beginning, middle and end.`, `Visual direction: ${guide.visual}.`, `Narration/dialogue: Use concise, natural language that makes the action easy to follow.`, `Ending: ${escalation}`);
    }
    lines.push("", "PRODUCTION CHECKLIST", "[ ] Write final dialogue / narration", "[ ] Create a shot list and character/reference sheets", "[ ] Generate or film each shot", "[ ] Record narration and choose licensed music", "[ ] Assemble clips in the editor", "[ ] Review continuity, captions and audio", "[ ] Render and watch the final export", "");
    return lines.join("\n");
  }

  function createProject(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!title.trim()) return;
    const isSeries = format !== "Single video";
    const count = !isSeries ? 1 : format === "3-episode series" ? 3 : format === "10-episode series" ? 10 : Math.max(1, Math.min(100, Math.floor(episodeCount || 1)));
    const finalFormat = count === 1 ? "Single video" : `${count}-episode series`;
    const storyPackage = buildStoryPackage(title.trim(), category, count, duration, orientation);
    const project: Project = {
      id: typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : String(Date.now()),
      title: title.trim(), category, format: finalFormat, duration, orientation, characters: [], episodes: [],
      createdAt: new Date().toLocaleDateString(), updatedAt: new Date().toISOString(), status: "Draft", episodeCount: count, storyPackage
    };
    setProjects((current) => [project, ...current]);
    setShowCreate(false);
    setActiveCategory("All");
    setSearch("");
    setNotice(`Created ${finalFormat.toLowerCase()} and generated a story/production plan. Open Download plan on the project to save it.`);
  }

  function downloadStoryPackage(project: Project) {
    const content = project.storyPackage || buildStoryPackage(project.title, project.category, project.episodeCount || 1, project.duration, project.orientation);
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${project.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "motioniton-story"}-production-plan.txt`;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  async function downloadGeneratedVideo(project: Project) {
    if (!project.generatedVideoUrl) return;
    const base=(localStorage.getItem('motioniton_ai_backend_url')||'').replace(/\/+$/,'');
    const token=localStorage.getItem('motioniton_session')||'';
    if(!base||!token){setNotice('Sign in and connect the backend to download this video.');return;}
    try {
      const response=await fetch(`${base}${project.generatedVideoUrl}`,{headers:{Authorization:`Bearer ${token}`}});
      if(!response.ok) throw new Error(`Video download failed (HTTP ${response.status}).`);
      const blob=await response.blob(); const url=URL.createObjectURL(blob); const anchor=document.createElement('a');
      anchor.href=url; anchor.download=`${project.title.replace(/[^a-z0-9-_]+/gi,'_').slice(0,80)||'MotionItOn-video'}.mp4`;
      document.body.appendChild(anchor); anchor.click(); anchor.remove(); window.setTimeout(()=>URL.revokeObjectURL(url),60000);
    } catch(error) { setNotice(error instanceof Error?error.message:String(error)); }
  }

  async function previewGeneratedVideo(project: Project) {
    if (!project.generatedVideoUrl) return;
    const base = (localStorage.getItem('motioniton_ai_backend_url') || '').replace(/\/+$/, '');
    const token = localStorage.getItem('motioniton_session') || '';
    if (!base || !token) { setNotice('Sign in and connect the backend to play this generated video.'); return; }
    try {
      const response = await fetch(`${base}${project.generatedVideoUrl}`, { headers: { Authorization: `Bearer ${token}` } });
      if (!response.ok) throw new Error(`Video preview failed (HTTP ${response.status}).`);
      const url = URL.createObjectURL(await response.blob());
      setVideoPreview(current => {
        if (current?.url) URL.revokeObjectURL(current.url);
        return { url, title: project.title, project };
      });
    } catch (error) { setNotice(error instanceof Error ? error.message : String(error)); }
  }

  useEffect(() => () => {
    if (videoPreview?.url) URL.revokeObjectURL(videoPreview.url);
  }, [videoPreview?.url]);

  function openProject(project: Project) {
    setEditingProjectId(project.id);
    setEditTitle(project.title);
    setEditCategory(project.category);
    setEditFormat(project.format);
    setEditDuration(project.duration);
    setEditOrientation(project.orientation);
    setEditNotes(project.notes || "");
    setEditStoryPackage(project.storyPackage || "");
    setNotice("");
  }

  function saveProjectDetails(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const current = projects.find(project => project.id === editingProjectId);
    if (!current) { setEditingProjectId(null); return; }
    const cleanTitle = editTitle.trim();
    if (!cleanTitle) { setNotice("Project title cannot be empty."); return; }
    setProjects(items => items.map(project => project.id === editingProjectId ? {
      ...project,
      title: cleanTitle,
      category: editCategory,
      format: editFormat,
      duration: editDuration,
      orientation: editOrientation,
      episodeCount: editFormat === "Single video" ? 1 : (project.episodeCount || 1),
      notes: editNotes,
      storyPackage: editStoryPackage,
      updatedAt: new Date().toISOString()
    } : project));
    setEditingProjectId(null);
    setNotice(`Saved changes to “${cleanTitle}”.`);
  }

  function renameProject(project: Project) {
    const nextTitle = window.prompt("Enter a new project name", project.title);
    if (nextTitle === null) return;
    const clean = nextTitle.trim();
    if (!clean) { setNotice("Project name cannot be empty."); return; }
    setProjects(current => current.map(p => p.id === project.id ? { ...p, title: clean, updatedAt: new Date().toISOString() } : p));
  }

  function duplicateProject(project: Project) {
    const copy: Project = { ...project, id: typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`, title: `${project.title} (Copy)`, createdAt: new Date().toLocaleDateString(), updatedAt: new Date().toISOString() };
    setProjects(current => [copy, ...current]);
    setNotice(`Created a copy of “${project.title}”.`);
  }

  function exportAllProjects() {
    const payload = { app: "MotionItOn-Ai", schemaVersion: 1, exportedAt: new Date().toISOString(), userId, projects };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a"); anchor.href = url; anchor.download = "motioniton-all-projects.motioniton.json";
    anchor.click(); URL.revokeObjectURL(url);
    setNotice(`Exported ${projects.length} project${projects.length === 1 ? "" : "s"}.`);
  }

  async function importProjects(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    setImporting(true);
    try {
      const parsed: unknown = JSON.parse(await file.text());
      const payload = parsed as { app?: string; schemaVersion?: number; project?: unknown; projects?: unknown[] };
      if (payload.app !== "MotionItOn-Ai" || payload.schemaVersion !== 1) throw new Error("This is not a supported MotionItOn-Ai backup.");
      const candidates = Array.isArray(payload.projects) ? payload.projects : payload.project ? [payload.project] : [];
      if (!candidates.length) throw new Error("The backup does not contain any projects.");
      const valid = candidates.filter((value): value is Project => {
        if (!value || typeof value !== "object") return false;
        const item = value as Partial<Project>;
        return typeof item.id === "string" && typeof item.title === "string" && typeof item.category === "string" && typeof item.format === "string" && typeof item.duration === "string" && typeof item.orientation === "string";
      });
      if (!valid.length) throw new Error("No valid projects were found in this backup.");
      setProjects(current => {
        const existing = new Set(current.map(item => item.id));
        const restored = valid.map(item => existing.has(item.id) ? { ...item, id: typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`, title: `${item.title} (Restored)` } : item);
        return [...restored, ...current];
      });
      setNotice(`Restored ${valid.length} project${valid.length === 1 ? "" : "s"}. Existing projects were preserved.`);
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Could not import this backup.");
    } finally { setImporting(false); }
  }

  function exportProject(project: Project) {
    const blob = new Blob([JSON.stringify({ app: "MotionItOn-Ai", schemaVersion: 1, exportedAt: new Date().toISOString(), project }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a"); anchor.href = url;
    anchor.download = `${project.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "motioniton-project"}.motioniton.json`;
    anchor.click(); URL.revokeObjectURL(url);
  }

  async function deleteProject(id: string) {
    const target = projects.find(p => p.id === id);
    if (!target || !window.confirm(`Delete “${target.title}”? This cannot be undone.`)) return;
    // Remove locally immediately so offline project management remains usable.
    setProjects((current) => current.filter((p) => p.id !== id));
    try {
      const deleted = await AccountService.deleteProject(id);
      setNotice(deleted
        ? `Deleted “${target.title}” from this device and your cloud account.`
        : `Deleted “${target.title}” from this device. Sign in to remove any cloud copy.`);
    } catch (error) {
      setNotice(`Deleted “${target.title}” locally. Cloud deletion could not be confirmed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  function formatTime(seconds: number) {
    if (!Number.isFinite(seconds)) return "00:00";
    const s = Math.max(0, Math.floor(seconds));
    return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
  }

  function importClips(event: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(event.target.files ?? []).filter((file) => file.type.startsWith("video/") || file.type.startsWith("image/"));
    const imported: Clip[] = files.map((file) => {
      const isImage = file.type.startsWith("image/");
      const stillDuration = 5;
      return {
        id: typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`,
        name: file.name,
        url: URL.createObjectURL(file),
        duration: isImage ? stillDuration : 0,
        start: 0,
        end: isImage ? stillDuration : 0,
        type: file.type,
        mediaKind: isImage ? "image" as const : "video" as const
      };
    });
    if (files.length !== imported.length) setEditorNotice("Some files were skipped. Choose image or video files.");
    if (!imported.length) setEditorNotice("Choose one or more pictures or video files from your device.");
    setClips((current) => [...current, ...imported]);
    setSelectedClip(imported[0]?.id ?? selectedClip);
    event.target.value = "";
  }

  function updateClipMetadata(id: string, duration: number) {
    setClips((current) => current.map((clip) => clip.id === id ? { ...clip, duration, end: clip.end > 0 ? Math.min(clip.end, duration) : duration } : clip));
  }

  function updateClipTrim(id: string, field: "start" | "end", value: number) {
    setClips((current) => current.map((clip) => {
      if (clip.id !== id) return clip;
      const effectiveEnd = clip.end > 0 ? clip.end : clip.duration;
      const nextStart = field === "start" ? Math.max(0, Math.min(value, effectiveEnd - 0.1)) : clip.start;
      const nextEnd = field === "end" ? Math.min(clip.duration || value, Math.max(value, clip.start + 0.1)) : effectiveEnd;
      return { ...clip, start: Math.max(0, nextStart), end: Math.min(clip.duration || nextEnd, nextEnd) };
    }));
  }

  function moveClip(id: string, direction: -1 | 1) {
    setClips((current) => {
      const index = current.findIndex((clip) => clip.id === id);
      const nextIndex = index + direction;
      if (index < 0 || nextIndex < 0 || nextIndex >= current.length) return current;
      const copy = [...current];
      [copy[index], copy[nextIndex]] = [copy[nextIndex], copy[index]];
      return copy;
    });
  }

  function removeClip(id: string) {
    setClips((current) => {
      const target = current.find((clip) => clip.id === id);
      if (target) URL.revokeObjectURL(target.url);
      const next = current.filter((clip) => clip.id !== id);
      setSelectedClip(next[0]?.id ?? null);
      return next;
    });
  }

  function updateRenderJob(progress: number, status: "Rendering" | "Completed" | "Failed") {
    try {
      const jobs = JSON.parse(localStorage.getItem("motioniton_render_jobs") || "[]") as Array<{id:string;title:string;status:string;progress:number;timestamp:string;downloadUrl?:string}>;
      const id = (window as Window & {__motionitonJobId?: string}).__motionitonJobId;
      if (!id) return;
      const next = jobs.map(j => j.id === id ? {...j, progress, status} : j);
      localStorage.setItem("motioniton_render_jobs", JSON.stringify(next));
    } catch {}
  }

  async function renderMp4() {
    if (!clips.length || rendering) return;
    setRendering(true);
    setRenderProgress(0);
    const jobId = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : String(Date.now());
    (window as Window & {__motionitonJobId?: string}).__motionitonJobId = jobId;
    try {
      const queue = JSON.parse(localStorage.getItem("motioniton_render_jobs") || "[]");
      queue.unshift({id:jobId,title: clips.map(c=>c.name).join(" + ").slice(0,100),status:"Rendering",progress:0,timestamp:new Date().toISOString()});
      localStorage.setItem("motioniton_render_jobs",JSON.stringify(queue));
      const blob = await renderVideoLocally({
        clips,
        audioTrack: audioTrackUrl ? { url: audioTrackUrl, name: audioTrackName || 'audio-track', start: audioTrimStart, end: audioTrimEnd || audioTrackDuration, volume: 1 } : undefined,
        audioTracks: audioTracks.length ? audioTracks : undefined,
        transition: transition as 'Cut' | 'Crossfade' | 'Fade',
        titleOverlays: titleText.trim() ? [{text:titleText.trim(),start:titleStart,end:Math.max(titleStart+.1,titleEnd),fontSize:titleSize,color:'#ffffff',position:titlePosition}] : [],
        resolution: exportResolution,
        orientation: exportOrientation,
        fps: exportFps,
        audioMode,
        onProgress: (value) => { setRenderProgress(value); updateRenderJob(value, "Rendering"); },
        onStatus: () => setEditorNotice("Preparing your video…")
      });
      try { await saveRenderOutput(jobId, blob); } catch { /* The exported download remains available. */ }
      const url = URL.createObjectURL(blob);
      updateRenderJob(100, "Completed");
      const a = document.createElement("a");
      a.href = url;
      a.download = "MotionItOn-export.mp4";
      document.body.appendChild(a);
      a.click();
      a.remove();
      // Keep the temporary URL alive for the current page session; the queue stores the Blob in IndexedDB.
      setEditorNotice(audioTrackUrl ? "MP4 exported successfully with your trimmed audio track." : "MP4 exported successfully.");
    } catch (error) {
      updateRenderJob(renderProgress, "Failed");
      setEditorNotice(`Could not export your video: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setRendering(false);
    }
  }

  function downloadEditPlan() {
    const plan = {
      product: "MotionItOn-Ai",
      status: "edit-plan-only",
      note: "This JSON is an editable plan. Use the local Render and download MP4 action to render imported clips on this device.",
      transition,
      exportResolution,
      exportOrientation,
      exportFps,
      audioMode,
      clips: clips.map((clip, index) => ({
        order: index + 1, filename: clip.name, sourceStartSeconds: clip.start,
        sourceEndSeconds: clip.end || clip.duration, sourceDurationSeconds: clip.duration
      }))
    };
    const blob = new Blob([JSON.stringify(plan, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "motioniton-edit-plan.json";
    anchor.click();
    URL.revokeObjectURL(url);
    setEditorNotice("Edit plan downloaded. Use Render and download MP4 to export the actual video.");
  }

  return (
    <main className="app-shell">
      <aside className={`sidebar ${mobileMenu ? "sidebar-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark"><Clapperboard size={22} /></div>
          <div><strong>MotionItOn-Ai</strong><span>AI VIDEO STUDIO</span></div>
          <button className="icon-button mobile-close" onClick={() => setMobileMenu(false)} aria-label="Close menu"><X size={20}/></button>
        </div>
        <button className="new-project" onClick={() => { setGenerationCategory("General"); setVideoPrompt(""); setActivePanel("ai"); }}><Plus size={18}/> Create a video</button>
        <div className="nav-label">WORKSPACE</div>
        <button className={`nav-item ${activePanel === "studio" ? "selected" : ""}`} onClick={() => { setActivePanel("studio"); setMobileMenu(false); }}><MonitorPlay size={18}/> Studio</button>
        <button className={`nav-item ${activePanel === "projects" ? "selected" : ""}`} onClick={() => { setActivePanel("projects"); setActiveCategory("All"); setSearch(""); setMobileMenu(false); }}><Film size={18}/> My projects <span className="nav-count">{projects.length}</span></button>
        <button className={`nav-item ${showEditor ? "selected" : ""}`} onClick={() => { setShowEditor(true); setMobileMenu(false); }}><Scissors size={18}/> Video editor</button>
        <button className={`nav-item ${activePanel === "workers" ? "selected" : ""}`} onClick={() => { setActivePanel("workers"); setMobileMenu(false); }}><Sparkles size={18}/> AI workers</button>
        <button className={`nav-item ${activePanel === "social" ? "selected" : ""}`} onClick={() => { setActivePanel("social"); setMobileMenu(false); }}><Upload size={18}/> Social Media Studio</button>
        <div className="nav-label category-label">CREATE WITH AI</div>
        <button className={`nav-item ${activePanel === "settings" ? "selected" : ""}`} onClick={() => { setActivePanel("settings"); setMobileMenu(false); }}><Settings2 size={18}/> General settings</button>
        <button className={`nav-item ${activePanel === "queue" ? "selected" : ""}`} onClick={() => { setActivePanel("queue"); setMobileMenu(false); }}><Activity size={18}/> Generation queue</button>
        <div className="sidebar-bottom">
          <div className="plan-card"><Sparkles size={17}/><div><strong>Creator workspace</strong><span>Your projects and productions</span></div></div>
          <button className={`nav-item ${activePanel === "settings" ? "selected" : ""}`} onClick={() => { setActivePanel("settings"); setMobileMenu(false); }}><Settings2 size={18}/> Settings</button>
          <button className="profile-row profile-row-button" onClick={() => {setActivePanel('account');setMobileMenu(false);}}><div className="avatar"><CircleUserRound size={22}/></div><div><strong>Account & profile</strong><span>Manage your account</span></div></button>
        </div>
      </aside>

      {mobileMenu && <button className="scrim" onClick={() => setMobileMenu(false)} aria-label="Close navigation" />}

      <section className="main-area">
        <header className="topbar">
          {activePanel === "projects" && <button className="secondary-button projects-back-button" onClick={() => { setActivePanel("studio"); setActiveCategory("All"); }}><ArrowLeft size={16}/> Back</button>}<button className="icon-button mobile-menu-button" onClick={() => setMobileMenu(true)} aria-label="Open menu"><Menu size={22}/></button>
          <div className="breadcrumb">Workspace <span>/</span> <strong>{activePanel === "projects" ? "My projects" : activePanel === "account" ? "Account" : activePanel === "settings" ? "Settings" : activePanel === "workers" ? "AI workers" : activePanel === "queue" ? "Generation queue" : activePanel === "ai" ? "Create video" : activePanel === "social" ? "Social Media Studio" : "Studio"}</strong></div>
          <div className="topbar-right"><button className="theme-toggle" onClick={toggleTheme} aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"} title={theme === "dark" ? "Light mode" : "Dark mode"}>{theme === "dark" ? <Sun size={18}/> : <Moon size={18}/>}</button><span className="device-pill"><Smartphone size={14}/> Works across screens</span><button className="avatar small-avatar" aria-label="Open account and profile" title="Account & profile" onClick={() => setActivePanel('account')}><CircleUserRound size={19}/></button></div>
        </header>

        {activePanel !== "studio" && activePanel !== "projects" ? <div className="content">{activePanel === "social" ? <SocialMediaStudio /> : (activePanel === "settings" || activePanel === "account") ? <SettingsView section={activePanel === "account" ? "account" : "settings"} onBack={() => { setCustomCategories(CategoryManager.getCategories().filter(item => item.isCustom)); setActivePanel("studio"); }} onSignOut={onSignOut} /> : activePanel === "queue" ? <QueueView onBack={() => setActivePanel("studio")} /> : activePanel === "workers" ? <AiWorkersView onBack={() => setActivePanel("ai")} onSelectWorker={() => setActivePanel("ai")} /> : <AiVideoView
            onBack={() => { setActivePanel("studio"); setVideoPrompt(""); }}
            initialPrompt={videoPrompt}
            autoGenerate={autoExecuteWorkplan}
            category={generationCategory}
            onChooseWorker={() => setActivePanel("workers")}
            onProjectCreated={(projectTitle, durationSeconds, projectCategory, jobId, downloadUrl) => {
              const safeCategory = (categories.some(item => item.name === projectCategory) ? projectCategory : "General") as Category;
              const project: Project = {
                id: `ai-${jobId}`,
                title: projectTitle,
                category: safeCategory,
                format: "AI video",
                duration: `${durationSeconds} seconds`,
                orientation: "Generated video",
                createdAt: new Date().toLocaleDateString(),
                status: "Completed",
                generatedVideoUrl: downloadUrl,
                aiJobId: jobId,
                updatedAt: new Date().toISOString()
              };
              setProjects(current => { const existing=current.findIndex(item=>item.id===project.id); if(existing<0)return [project,...current]; const next=[...current]; next[existing]={...next[existing],...project}; return next; });
              setExecutingWorkplanId("");
              setAutoExecuteWorkplan(false);
            }}
          />}</div> : <div className="content">
          {activePanel === "studio" && <PixVerseHomeNav
            onSelectTool={(toolId) => {
              if (toolId === "text-to-video") { setGenerationCategory("General"); setActivePanel("ai"); setVideoPrompt(""); }
              else if (toolId === "video-editor" || toolId === "audio-trimmer" || toolId === "transition" || toolId === "sound-effects") {
                setShowEditor(true);
                setEditorNotice(toolId === "audio-trimmer" ? "Audio trimmer: import a soundtrack, set its trim range, then render your MP4." : toolId === "transition" ? "Transitions: import multiple clips and choose a transition between them." : toolId === "sound-effects" ? "Sound FX: import an effects track in the Audio Trimmer and include it in your export." : "Video trimmer: import clips, adjust trim points, then render an MP4.");
              }
              else if (toolId === "home") { setActivePanel("studio"); setActiveCategory("All"); }
              else if (toolId === "projects") { setActivePanel("projects"); setActiveCategory("All"); }
              else if (toolId === "profile") setActivePanel("account");
              else if (toolId === "image-to-video" || toolId === "create-image" || toolId === "vibemvai" || toolId === "lip-sync" || toolId === "edit-image") {
                setNotice(`${toolId.replaceAll("-", " ").replace(/^./, c => c.toUpperCase())} is not yet connected to its own AI engine. Use Text to Video for generation or the Editor for media editing.`);
              }
            }}
            onOpenCategory={(name) => {
              const selected = (categories.some(item => item.name === name) ? name : "General") as Category;
              setGenerationCategory(selected);
              setVideoPrompt("");
              setActivePanel("ai");
            }}
            onProfile={() => setActivePanel("account")}
          />}
          {activePanel === "projects" && <section className="projects-section">
            <div className="section-heading project-heading"><div><h2>My projects</h2><p>View and manage your saved projects and generated videos.</p></div><div className="project-heading-actions"><button className="download-project-button" onClick={exportAllProjects} disabled={!projects.length}><Download size={15}/> Export all</button><label className="download-project-button" htmlFor="project-backup-import" aria-disabled={importing}>{importing ? "Importing…" : "Import backup"}<Upload size={15}/></label><input id="project-backup-import" type="file" accept=".json,.motioniton.json,application/json" onChange={importProjects} disabled={importing} hidden/><button className="text-button" onClick={() => { setGenerationCategory("General"); setVideoPrompt(""); setActivePanel("ai"); }}><Plus size={16}/> New project</button></div></div>
            {notice && <div className="notice"><span>{notice}</span><button onClick={() => setNotice("")} aria-label="Dismiss notice"><X size={16}/></button></div>}
            <div className="project-toolbar">
              <div className="search-box"><Search size={17}/><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search your projects"/></div>
              <div className="filter-wrap"><BookOpen size={15}/><select value={activeCategory} onChange={(e) => setActiveCategory(e.target.value as Category | "All")} aria-label="Filter by category"><option value="All">All projects</option>{categories.map((c) => <option key={c.name} value={c.name}>{c.name}</option>)}</select></div>
            </div>
            <div className="project-category-groups">{categories.filter(group => activeCategory === "All" || group.name === activeCategory).map((group) => {
              const groupProjects = filteredProjects.filter(project => project.category === group.name);
              const GroupIcon = group.icon;
              return <section className="project-category-group" key={group.name}>
                <header className="project-category-group-heading"><div><GroupIcon size={18}/><h3>{group.name}</h3><span>{groupProjects.length}</span></div><button className="text-button" onClick={() => setActiveCategory(group.name)}>View</button></header>
                {groupProjects.length ? <div className="project-list">{groupProjects.map((project) => {
              const item = categories.find((c) => c.name === project.category)!;
              const Icon = item.icon;
              return <article className="project-row" key={project.id}>
                <div className={`project-thumb thumb-${categories.findIndex((c) => c.name === project.category)}`}><Icon size={24}/><span>{item.tag}</span></div>
                <div className="project-info"><h3>{project.title}</h3><div className="project-meta"><span>{project.category}</span><i>·</i><span>{project.format}</span><i>·</i><span><Clock3 size={13}/>{project.duration}</span></div></div>
                <div className="project-status"><span className="draft-dot"/>{project.status}</div>
                <div className="project-actions">
                  <button className="download-project-button" onClick={() => openProject(project)} title="View saved project">View</button>{project.generatedVideoUrl && <>
                    <button className="download-project-button" onClick={() => void previewGeneratedVideo(project)} title="Play generated video"><Play size={15}/> Play</button>
                    <button className="download-project-button" onClick={() => void downloadGeneratedVideo(project)} title="Export generated MP4"><Download size={15}/> Export</button>
                    <button className="download-project-button" onClick={() => window.open("https://studio.youtube.com/", "_blank", "noopener,noreferrer")} title="Open YouTube Studio to upload this video">YouTube</button>
                    <button className="download-project-button" onClick={() => window.open("https://www.tiktok.com/upload", "_blank", "noopener,noreferrer")} title="Open TikTok upload">TikTok</button>
                  </>}
                  <button className="download-project-button" onClick={() => setProductionProjectId(project.id)} title="Manage characters, episodes and scenes">Production</button>
                  <button className="download-project-button" onClick={() => downloadStoryPackage(project)} title="Download story and production plan" aria-label={`Download plan for ${project.title}`}><Download size={16}/><span>Plan</span></button>
                  <button className="download-project-button" onClick={() => renameProject(project)} title="Rename project">Rename</button>
                  <button className="download-project-button" onClick={() => duplicateProject(project)} title="Duplicate project">Duplicate</button>
                  <button className="download-project-button" onClick={() => exportProject(project)} title="Export project backup">Backup</button>
                  <button className="delete-button" onClick={() => deleteProject(project.id)} title="Delete project" aria-label={`Delete ${project.title}`}><X size={17}/></button>
                </div>
              </article>;
                })}</div> : <p className="project-category-empty">No {group.name.toLowerCase()} projects yet.</p>}
              </section>;
            })}</div>

          </section>}
          {activePanel === "studio" && <footer><span>MotionItOn-Ai</span></footer>}
        </div>}
      </section>


      {videoPreview && <div className="modal-backdrop" role="presentation" onMouseDown={e => { if (e.target === e.currentTarget) setVideoPreview(null); }}>
        <section className="video-preview-modal" role="dialog" aria-modal="true" aria-label={`Preview ${videoPreview.title}`}>
          <header className="modal-header"><div><div className="eyebrow">SAVED VIDEO</div><h2>{videoPreview.title}</h2></div><button className="icon-button" onClick={() => setVideoPreview(null)} aria-label="Close video preview"><X size={20}/></button></header>
          <video src={videoPreview.url} controls autoPlay playsInline className="saved-video-player"/>
          <div className="project-actions saved-video-actions">
            <button className="download-project-button" onClick={() => void downloadGeneratedVideo(videoPreview.project)}><Download size={15}/> Export MP4</button>
            <button className="download-project-button" onClick={() => window.open("https://studio.youtube.com/", "_blank", "noopener,noreferrer")}>Upload to YouTube</button>
            <button className="download-project-button" onClick={() => window.open("https://www.tiktok.com/upload", "_blank", "noopener,noreferrer")}>Upload to TikTok</button>
          </div>
        </section>
      </div>}

      {productionProjectId && (() => {
        const project = projects.find(item => item.id === productionProjectId);
        if (!project) return null;
        return <ProjectProductionManager
          projectTitle={project.title}
          initialCharacters={project.characters || []}
          initialEpisodes={project.episodes || []}
          onClose={() => setProductionProjectId(null)}
          onSave={(data) => {
            setProjects(current => current.map(item => item.id === project.id ? { ...item, ...data, updatedAt: new Date().toISOString() } : item));
            setProductionProjectId(null);
            setNotice(`Production details saved for “${project.title}”.`);
          }}
        />;
      })()}

      {showEditor && <div className="editor-backdrop">
        <section className="editor-window" aria-label="Video editor">
          <header className="editor-header">
            <div className="editor-title"><div className="category-icon"><Scissors size={19}/></div><div><h2>Video editor</h2><p>Combine clips, trim sections and prepare a professional edit.</p></div></div>
            <div className="editor-header-actions"><button className="secondary-button" onClick={downloadEditPlan} disabled={clips.length === 0}><Download size={15}/> Export edit plan</button><button className="icon-button" onClick={() => setShowEditor(false)} aria-label="Close video editor"><X size={20}/></button></div>
          </header>
          <div className="editor-body">
            <section className="preview-column">
              <div className="preview-frame">
                {selectedClipData ? (selectedClipData.mediaKind === "image" ? <img key={selectedClipData.id} src={selectedClipData.url} alt={selectedClipData.name} className="editor-image-preview" /> : <video key={selectedClipData.id} src={selectedClipData.url} controls playsInline onLoadedMetadata={(e) => updateClipMetadata(selectedClipData.id, e.currentTarget.duration)} onPlay={() => setIsPreviewPlaying(true)} onPause={() => setIsPreviewPlaying(false)} />) :
                  <div className="preview-placeholder"><div className="preview-play"><Play size={27}/></div><strong>Your movie preview</strong><span>Import clips to see and review them here.</span></div>}
              </div>
              <div className="preview-controls"><span><MonitorPlay size={15}/> Source preview</span><span>{selectedClipData ? `${formatTime(selectedClipData.start)} – ${formatTime(selectedClipData.end || selectedClipData.duration)}` : "No clip selected"}</span></div>
              <div className="editor-notice"><Sparkles size={16}/><span>{editorNotice}</span></div>
              <div className="timeline-heading"><div><h3>Timeline</h3><p>{clips.length} clips · {formatTime(totalClipDuration)} selected duration</p></div><label className="upload-button"><Upload size={16}/> Add media<input type="file" accept="video/*,image/*" multiple onChange={importClips}/></label></div>
              <div className="timeline">
                {clips.length === 0 ? <div className="timeline-empty"><Upload size={21}/><strong>Drop into your workflow</strong><span>Use “Add media” to select pictures and videos from your device.</span></div> :
                  clips.map((clip, index) => <button className={`timeline-clip ${selectedClip === clip.id ? "timeline-clip-selected" : ""}`} key={clip.id} onClick={() => setSelectedClip(clip.id)}>
                    <div className="clip-number">{String(index + 1).padStart(2, "0")}</div><div className="clip-details">{clip.mediaKind === "image" ? <Film size={15}/> : <Video size={15}/>}<span title={clip.name}>{clip.name}</span><small>{clip.duration ? formatTime(clip.duration) : "Reading duration…"}</small></div>
                    <div className="clip-actions"><span role="button" tabIndex={0} aria-label="Move clip up" onClick={(e) => { e.stopPropagation(); moveClip(clip.id, -1); }} onKeyDown={(e) => { if (e.key === "Enter") { e.stopPropagation(); moveClip(clip.id, -1); } }}><ChevronUp size={14}/></span><span role="button" tabIndex={0} aria-label="Move clip down" onClick={(e) => { e.stopPropagation(); moveClip(clip.id, 1); }} onKeyDown={(e) => { if (e.key === "Enter") { e.stopPropagation(); moveClip(clip.id, 1); } }}><ChevronDown size={14}/></span><span role="button" tabIndex={0} aria-label="Remove clip" onClick={(e) => { e.stopPropagation(); removeClip(clip.id); }} onKeyDown={(e) => { if (e.key === "Enter") { e.stopPropagation(); removeClip(clip.id); } }}><Trash2 size={14}/></span></div>
                  </button>)}
              </div>
            </section>
            <aside className="editor-settings">
              <div className="settings-heading"><SlidersHorizontal size={17}/><h3>Clip & export settings</h3></div>
              {selectedClipData ? <>
                <div className="setting-group"><label>Selected {selectedClipData.mediaKind === "image" ? "picture" : "video"}</label><div className="selected-file">{selectedClipData.name}</div></div>
                {selectedClipData.mediaKind === "image" ? <div className="setting-group"><label htmlFor="still-duration">Picture duration · {formatTime(selectedClipData.end - selectedClipData.start)}</label><input id="still-duration" type="range" min="1" max="30" step="1" value={Math.max(1, Math.min(30, selectedClipData.end - selectedClipData.start))} onChange={(e) => { const duration = Number(e.target.value); setClips(current => current.map(c => c.id === selectedClipData.id ? {...c, duration, start: 0, end: duration} : c)); }} /><small>Set how long this picture appears (1–30 seconds).</small></div> : <><div className="setting-group"><label htmlFor="trim-start">Trim start · {formatTime(selectedClipData.start)}</label><input id="trim-start" type="range" min="0" max={Math.max(1, selectedClipData.duration)} step="0.1" value={Math.min(selectedClipData.start, selectedClipData.duration || 1)} onChange={(e) => updateClipTrim(selectedClipData.id, "start", Number(e.target.value))} /></div><div className="setting-group"><label htmlFor="trim-end">Trim end · {formatTime(selectedClipData.end || selectedClipData.duration)}</label><input id="trim-end" type="range" min={Math.min(selectedClipData.start, Math.max(0, selectedClipData.duration))} max={Math.max(1, selectedClipData.duration)} step="0.1" value={Math.min(selectedClipData.end || selectedClipData.duration || 1, Math.max(1, selectedClipData.duration))} onChange={(e) => updateClipTrim(selectedClipData.id, "end", Number(e.target.value))} /></div></>}
                
              </> : <p className="settings-empty">Select or import a clip to access trimming controls.</p>}
              <div className="setting-group"><label htmlFor="transition">Clip transition</label><select id="transition" value={transition} onChange={(e) => setTransition(e.target.value)}><option>Cut</option><option>Crossfade</option><option>Fade</option></select><small>Crossfade and fade are rendered into the exported MP4.</small></div>
              <div className="setting-group title-overlay-panel"><label>Text / title overlay</label><input aria-label="Title text" className="form-input" value={titleText} onChange={e=>setTitleText(e.target.value)} placeholder="Enter title or caption"/><label>Show from · {formatTime(titleStart)}</label><input type="range" min="0" max={Math.max(1,totalClipDuration)} step="0.5" value={Math.min(titleStart,Math.max(1,totalClipDuration))} onChange={e=>setTitleStart(Number(e.target.value))}/><label>Show until · {formatTime(titleEnd)}</label><input type="range" min={Math.min(titleStart,totalClipDuration)} max={Math.max(1,totalClipDuration)} step="0.5" value={Math.min(titleEnd,Math.max(1,totalClipDuration))} onChange={e=>setTitleEnd(Number(e.target.value))}/><label>Text size · {titleSize}px</label><input type="range" min="24" max="120" value={titleSize} onChange={e=>setTitleSize(Number(e.target.value))}/><select value={titlePosition} onChange={e=>setTitlePosition(e.target.value as "top"|"center"|"bottom")}><option value="top">Top</option><option value="center">Center</option><option value="bottom">Bottom</option></select><small>Titles are burned into the exported video.</small></div>
              <div className="setting-group"><label>Independent audio tracks</label><label className="upload-button audio-upload">Add music / sound effect<input type="file" accept="audio/*" multiple onChange={e=>{const files=Array.from(e.target.files||[]);for(const file of files){const url=URL.createObjectURL(file);const audio=new Audio(url);audio.onloadedmetadata=()=>setAudioTracks(current=>[...current,{id:crypto.randomUUID(),name:file.name,url,duration:audio.duration,start:0,end:audio.duration,volume:1,delay:0}]);}e.target.value="";}}/></label>{audioTracks.map(track=><div key={track.id} className="audio-track-row"><b>{track.name}</b><label>Volume {Math.round(track.volume*100)}%</label><input type="range" min="0" max="2" step="0.05" value={track.volume} onChange={e=>setAudioTracks(a=>a.map(t=>t.id===track.id?{...t,volume:Number(e.target.value)}:t))}/><label>Start delay · {track.delay.toFixed(1)}s</label><input type="range" min="0" max="60" step="0.5" value={track.delay} onChange={e=>setAudioTracks(a=>a.map(t=>t.id===track.id?{...t,delay:Number(e.target.value)}:t))}/><label>Trim start</label><input type="range" min="0" max={Math.max(1,track.duration)} step="0.1" value={track.start} onChange={e=>setAudioTracks(a=>a.map(t=>t.id===track.id?{...t,start:Math.min(Number(e.target.value),t.end-.1)}:t))}/><label>Trim end</label><input type="range" min={track.start+.1} max={Math.max(1,track.duration)} step="0.1" value={track.end} onChange={e=>setAudioTracks(a=>a.map(t=>t.id===track.id?{...t,end:Number(e.target.value)}:t))}/><button className="secondary-button" onClick={()=>{URL.revokeObjectURL(track.url);setAudioTracks(a=>a.filter(t=>t.id!==track.id));}}>Remove track</button></div>)}</div>
              <div className="setting-group"><label htmlFor="resolution">Export resolution</label><select id="resolution" value={exportResolution} onChange={(e) => setExportResolution(e.target.value)}><option>720p</option><option>1080p</option><option>1440p</option><option>4K</option><option>Match source</option></select></div>
              <div className="setting-group"><label htmlFor="orientation">Frame orientation</label><select id="orientation" value={exportOrientation} onChange={(e) => setExportOrientation(e.target.value)}><option>Keep original</option><option>Vertical 9:16</option><option>Landscape 16:9</option><option>Square 1:1</option><option>Portrait 4:5</option></select></div>
              <div className="setting-group"><label htmlFor="fps">Frame rate</label><select id="fps" value={exportFps} onChange={(e) => setExportFps(e.target.value)}><option>24 fps</option><option>25 fps</option><option>30 fps</option><option>60 fps</option></select></div>
              <div className="setting-group"><label htmlFor="audio-mode">Audio</label><select id="audio-mode" value={audioMode} onChange={(e) => setAudioMode(e.target.value)}><option>Keep original audio</option><option>Mute original audio</option></select></div>
              <div className="setting-group audio-trimmer-panel"><label>Audio trimmer</label><label className="upload-button audio-upload">{audioTrackName ? "Replace audio" : "Add audio track"}<input type="file" accept="audio/*" onChange={(e) => { const file=e.target.files?.[0]; if(!file)return; if(audioTrackUrl)URL.revokeObjectURL(audioTrackUrl); const url=URL.createObjectURL(file); setAudioTrackUrl(url); setAudioTrackName(file.name); setAudioTrimStart(0); setAudioTrimEnd(0); }} /></label>
                {audioTrackUrl && <><audio className="audio-trimmer-player" src={audioTrackUrl} controls onLoadedMetadata={(e)=>{const d=e.currentTarget.duration;setAudioTrackDuration(d);setAudioTrimEnd(d);}} onTimeUpdate={(e)=>{if(audioTrimEnd>0 && e.currentTarget.currentTime>=audioTrimEnd)e.currentTarget.pause();}}/><small>{audioTrackName}</small><label htmlFor="audio-trim-start">Start · {formatTime(audioTrimStart)}</label><input id="audio-trim-start" type="range" min="0" max={Math.max(1,audioTrackDuration)} step="0.1" value={Math.min(audioTrimStart,audioTrackDuration||1)} onChange={(e)=>{const v=Number(e.target.value);setAudioTrimStart(v);const a=document.querySelector<HTMLAudioElement>(".audio-trimmer-player");if(a)a.currentTime=v;}}/><label htmlFor="audio-trim-end">End · {formatTime(audioTrimEnd)}</label><input id="audio-trim-end" type="range" min={Math.min(audioTrimStart,audioTrackDuration)} max={Math.max(1,audioTrackDuration)} step="0.1" value={Math.min(audioTrimEnd||audioTrackDuration||1,Math.max(1,audioTrackDuration))} onChange={(e)=>setAudioTrimEnd(Number(e.target.value))}/></>}
              </div>
              
              {rendering && <div className="setting-group"><label htmlFor="render-progress">Rendering progress · {renderProgress}%</label><progress id="render-progress" max="100" value={renderProgress} style={{ width: "100%" }} /></div>}
              <button className="primary-button export-plan-button" onClick={renderMp4} disabled={clips.length === 0 || rendering}><Video size={16}/> {rendering ? `Rendering… ${renderProgress}%` : "Render and download MP4"}</button>
              <button className="secondary-button export-plan-button" onClick={downloadEditPlan} disabled={clips.length === 0}><Download size={16}/> Export edit plan</button>
              
            </aside>
          </div>
        </section>
      </div>}

            {editingProjectId && <div className="modal-backdrop" role="presentation" onMouseDown={(e) => { if (e.target === e.currentTarget) setEditingProjectId(null); }}>
        <section className="create-modal project-detail-modal" role="dialog" aria-modal="true" aria-labelledby="edit-project-title">
          <div className="modal-header"><div><div className="eyebrow">PROJECT WORKSPACE</div><h2 id="edit-project-title">Open project</h2><p>Edit project details, production notes and its saved story package.</p></div><button type="button" className="icon-button" onClick={() => setEditingProjectId(null)} aria-label="Close"><X size={20}/></button></div>
          <form onSubmit={saveProjectDetails}>
            <label className="field-label" htmlFor="edit-project-name">Project title</label><input id="edit-project-name" className="form-input" value={editTitle} onChange={e => setEditTitle(e.target.value)} required maxLength={100}/>
            <div className="field-pair"><div><label className="field-label" htmlFor="edit-project-category">Category</label><select id="edit-project-category" className="form-input" value={editCategory} onChange={e => setEditCategory(e.target.value as Category)}>{categories.map(item => <option key={item.name} value={item.name}>{item.name}</option>)}</select></div><div><label className="field-label" htmlFor="edit-project-format">Format</label><select id="edit-project-format" className="form-input" value={editFormat} onChange={e => setEditFormat(e.target.value)}><option>Single video</option><option>3-episode series</option><option>10-episode series</option><option>Episodic series</option><option>Custom series</option></select></div></div>
            <div className="field-pair"><div><label className="field-label" htmlFor="edit-project-duration">Target duration</label><select id="edit-project-duration" className="form-input" value={editDuration} onChange={e => setEditDuration(e.target.value)}>{["15 seconds","30 seconds","45 seconds","60 seconds","2 minutes","5 minutes","10 minutes","Custom duration"].map(value => <option key={value}>{value}</option>)}</select></div><div><label className="field-label" htmlFor="edit-project-orientation">Orientation</label><select id="edit-project-orientation" className="form-input" value={editOrientation} onChange={e => setEditOrientation(e.target.value)}><option>Vertical 9:16</option><option>Landscape 16:9</option><option>Square 1:1</option><option>Portrait 4:5</option></select></div></div>
            <label className="field-label" htmlFor="edit-project-notes">Production notes</label><textarea id="edit-project-notes" className="form-input project-notes-input" value={editNotes} onChange={e => setEditNotes(e.target.value)} rows={4} maxLength={20000} placeholder="Add creative direction, requirements, reminders and continuity notes…"/>
            <label className="field-label" htmlFor="edit-project-story">Story package / script plan</label><textarea id="edit-project-story" className="form-input project-story-input" value={editStoryPackage} onChange={e => setEditStoryPackage(e.target.value)} rows={10} maxLength={200000} placeholder="Your saved story and production plan will appear here…"/>
            <div className="modal-actions"><ProductionPlanActionBanner planPrompt={editStoryPackage.trim() || editTitle} onProceedToVideo={(promptText) => { setVideoPrompt(promptText); setEditingProjectId(null); setActivePanel("ai"); }} /></div>
            <div className="modal-actions"><button type="button" className="secondary-button" onClick={() => setEditingProjectId(null)}>Cancel</button><button type="submit" className="primary-button">Save project</button></div>
          </form>
        </section>
      </div>}

            {showCreate && <div className="modal-backdrop" role="presentation" onMouseDown={(e) => { if (e.target === e.currentTarget) setShowCreate(false); }}>
        <section className="create-modal" role="dialog" aria-modal="true" aria-labelledby="create-title">
          <div className="modal-header"><div><div className="eyebrow">NEW PROJECT</div><h2 id="create-title">Start your video</h2><p>Set the basics and generate a structured production plan.</p></div><button className="icon-button" onClick={() => setShowCreate(false)} aria-label="Close"><X size={20}/></button></div>
          <form onSubmit={createProject}>
            <label className="field-label" htmlFor="project-title">Project title</label>
            <input id="project-title" className="form-input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. The Secret Heir" required maxLength={100}/>
            <label className="field-label" htmlFor="project-category">Video type</label>
            <select id="project-category" className="form-input" value={category} onChange={(e) => { const next = e.target.value as Category; setCategory(next); if (next === "Drama series") setFormat("Episodic series"); else setFormat("Single video"); }}>
              {categories.map((c) => <option key={c.name} value={c.name}>{c.name}</option>)}
            </select>
            <div className="field-pair"><div><label className="field-label" htmlFor="project-format">Project format</label><select id="project-format" className="form-input" value={format} onChange={(e) => setFormat(e.target.value)}><option>Single video</option><option>Episodic series</option><option>3-episode series</option><option>10-episode series</option><option>Custom series</option></select></div>
            <div><label className="field-label" htmlFor="project-duration">Video duration</label><select id="project-duration" className="form-input" value={duration} onChange={(e) => setDuration(e.target.value)}><option>15 seconds</option><option>30 seconds</option><option>45 seconds</option><option>60 seconds</option><option>2 minutes</option><option>5 minutes</option><option>10 minutes</option><option>Custom duration</option></select></div></div>
            {format !== "Single video" && format !== "3-episode series" && format !== "10-episode series" && <div className="custom-episode-field"><label className="field-label" htmlFor="episode-count">Number of episodes (1–100)</label><input id="episode-count" className="form-input" type="number" min="1" max="100" step="1" value={episodeCount} onChange={(e) => setEpisodeCount(Math.max(1, Math.min(100, Number(e.target.value) || 1)))} required/><p className="field-hint">Choose exactly how many episodes to include in your production plan.</p></div>}
            <label className="field-label" htmlFor="project-orientation">Video orientation</label>
            <select id="project-orientation" className="form-input" value={orientation} onChange={(e) => setOrientation(e.target.value)}><option>Vertical 9:16</option><option>Landscape 16:9</option><option>Square 1:1</option><option>Portrait 4:5</option></select>

            <div className="modal-actions"><button type="button" className="secondary-button" onClick={() => setShowCreate(false)}>Cancel</button><button type="submit" className="primary-button">Create project & plan <ArrowRight size={16}/></button></div>
          </form>
        </section>
      </div>}
    </main>
  );
}


function AccountGate() {
  const [mode,setMode]=useState<'login'|'register'|'reset'>('login');
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const [newPassword,setNewPassword]=useState('');
  const [recoveryMode,setRecoveryMode]=useState(false);
  const [displayName,setDisplayName]=useState('');
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState('');
  const [notice,setNotice]=useState('');
  const [token,setToken]=useState('');
  const [userId,setUserId]=useState('');
  const [ready,setReady]=useState(false);

  useEffect(()=>{
    let active=true;
    if (new URLSearchParams(window.location.search).get('password-recovery') === '1') setRecoveryMode(true);
    AccountService.completeEmailVerification()
      .then(async verifiedUser => {
        if (active && verifiedUser) setNotice('Email verified successfully. You can now use your account.');
        return verifiedUser || AccountService.currentUser();
      })
      .then(user=>{
        if(active && user){
          setUserId(user.id);
          setToken(localStorage.getItem('motioniton_session')||'');
        }
      })
      .catch(err=>{if(active)setError(err instanceof Error?err.message:'Could not complete email verification.');})
      .finally(()=>{if(active)setReady(true);});
    return ()=>{active=false;};
  },[]);

  async function submit(e:React.FormEvent){
    e.preventDefault();
    setBusy(true);setError('');setNotice('');
    try{
      if(mode==='reset'){
        await AccountService.requestPasswordReset(email);
        setNotice('If an account exists for that email, a password recovery link has been sent. Check your inbox.');
        setPassword('');
        return;
      }
      if(mode==='register'){
        if(!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) throw new Error('Use a password containing both letters and numbers.');
        const result=await AccountService.register(email,password,displayName);
        if (result.authenticated !== true) {
          setNotice('Account created. Check your email for the verification link, then return here to sign in.');
          setMode('login');
          setPassword('');
          return;
        }
        // The explicit discriminant above guarantees that this branch has a user.
        setUserId(result.user.id);
        setToken(localStorage.getItem('motioniton_session')||'');
      }else{
        const user=await AccountService.login(email,password);
        setUserId(user.id);
        setToken(localStorage.getItem('motioniton_session')||'');
      }
    }catch(err){
      setError(err instanceof Error?err.message:'Could not connect to the MotionItOn account service.');
    }finally{setBusy(false);}
  }

  async function completePasswordRecovery(e:React.FormEvent){
    e.preventDefault(); setBusy(true); setError(''); setNotice('');
    try {
      AccountService.validatePassword(newPassword);
      const user = await AccountService.updateUser({ password: newPassword });
      setUserId(user.id); setNewPassword(''); setRecoveryMode(false);
      window.history.replaceState({}, document.title, window.location.pathname);
      setNotice('Your password has been reset successfully.');
    } catch(err) { setError(err instanceof Error ? err.message : 'Password reset could not be completed.'); }
    finally { setBusy(false); }
  }

  async function signOut(){
    await AccountService.logout();
    setToken('');
    setUserId('');
    setPassword('');
  }

  if(!ready)return <div className="auth-loading">Loading MotionItOn…</div>;
  if(token && userId && recoveryMode)return <main className="auth-screen"><section className="auth-card"><div className="auth-brand"><span className="auth-logo">▣</span><div><strong>MotionItOn-Ai</strong><small>ACCOUNT RECOVERY</small></div></div><h1>Choose a new password</h1><p className="auth-intro">Your recovery link has been verified. Set a new password to secure your account.</p><form onSubmit={completePasswordRecovery}><label className="auth-label">New password<input type="password" value={newPassword} onChange={e=>setNewPassword(e.target.value)} minLength={10} autoComplete="new-password" required placeholder="At least 10 characters"/></label><p className="auth-hint">Use at least 10 characters, including letters and numbers.</p>{error&&<p className="auth-error" role="alert">{error}</p>}<button className="auth-submit" disabled={busy}>{busy?'Updating…':'Reset password'}</button></form></section></main>;
  if(token && userId)return <StudioHome userId={userId} onSignOut={signOut}/>;

  return <main className="auth-screen">
    <section className="auth-card">
      <div className="auth-brand"><span className="auth-logo">▣</span><div><strong>MotionItOn-Ai</strong><small>AI VIDEO STUDIO</small></div></div>
      <p className="auth-eyebrow">YOUR CREATIVE WORKSPACE</p>
      <h1>{mode==='register'?'Create your account':mode==='reset'?'Recover your account':'Welcome back'}</h1>
      <p className="auth-intro">{mode==='register'?'Create an account to keep your projects and production workspace together.':mode==='reset'?'Enter your account email and we will send a secure recovery link.':'Sign in to continue to your video studio.'}</p>
      <form onSubmit={submit}>
        {mode==='register'&&<label className="auth-label">Creator name<input value={displayName} onChange={e=>setDisplayName(e.target.value)} minLength={2} maxLength={70} autoComplete="name" required placeholder="Your name"/></label>}
        <label className="auth-label">Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} autoComplete="email" required placeholder="you@example.com"/></label>
        {mode!=='reset'&&<label className="auth-label">Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} minLength={mode==='register'?10:1} autoComplete={mode==='register'?'new-password':'current-password'} required placeholder={mode==='register'?'At least 10 characters':'Your password'}/></label>}
        {mode==='register'&&<p className="auth-hint">Use at least 10 characters, including letters and numbers.</p>}
        {notice&&<p className="auth-notice" role="status">{notice}</p>}
        {error&&<p className="auth-error" role="alert">{error}</p>}
        <button className="auth-submit" disabled={busy}>{busy?'Please wait…':mode==='register'?'Create account':mode==='reset'?'Send recovery link':'Sign in'}</button>
      </form>
      <p className="auth-switch">{mode==='register'?'Already have an account?':mode==='reset'?'Remembered your password?':'New to MotionItOn?'} <button type="button" onClick={()=>{setMode(mode==='register'||mode==='reset'?'login':'register');setError('');setNotice('');}}>{mode==='register'||mode==='reset'?'Sign in':'Create account'}</button></p>
      {mode==='login'&&<p className="auth-switch"><button type="button" onClick={()=>{setMode('reset');setError('');setNotice('');}}>Forgot password?</button></p>}

    </section>
  </main>;
}
export default function Home(){return <AccountGate/>;}
