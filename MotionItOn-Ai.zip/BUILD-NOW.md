# MotionItOn — next development build

## Changes in this iteration

- Added `engine/doctor.py`, a no-download runtime preflight for Python, FFmpeg, PyTorch, CUDA, required model libraries, and the local Hugging Face model cache.
- Updated `GET /api/ai/engine` to return live diagnostics instead of relying on the manually set `MOTIONITON_ENGINE_READY` environment variable.
- Updated the AI Video screen's **Test engine** action to show individual readiness checks and clear failed-check details.
- Kept the self-hosted LTX inference path and Android/web/Windows project structure.

## Validate

```bash
npm run test:backend
node --check backend/server.mjs
python3 -m py_compile engine/doctor.py engine/generate_video.py
python3 engine/doctor.py
npm run build
```

The first three commands were run successfully in the development environment. The runtime diagnostic was also run; this environment does not include the complete CUDA video model stack, so it correctly reports the engine as not ready. The Next.js production build was not run because npm dependencies are not installed in this workspace.

## Important

This does not make video diffusion run on an ordinary Android phone. Real AI inference still runs on the machine hosting the self-hosted model and needs a compatible CUDA GPU. The APK is a client for that engine.
