/** Server-side FFmpeg transition builder. Paths are argv values; no shell interpolation. */
export function buildFfmpegStitchArgs(clips, outputPath, options = {}) {
  if (!Array.isArray(clips) || !clips.length || clips.length > 20) throw new Error('Provide 1–20 normalized clips.');
  if (typeof outputPath !== 'string' || !outputPath.trim()) throw new Error('Output path is required.');
  for (const [index, clip] of clips.entries()) {
    if (!clip?.path || !Number.isFinite(clip.durationSeconds) || clip.durationSeconds <= 0) throw new Error(`Clip ${index + 1} has an invalid path or duration.`);
    if (clip.hasAudio === false) throw new Error('Backend normalized clips must include an audio stream.');
  }
  const width = options.width ?? 1920, height = options.height ?? 1080, fps = options.fps ?? 30;
  const transitionSeconds = options.transitionSeconds ?? 0.75;
  if (![width, height].every(value => Number.isInteger(value) && value >= 160 && value <= 3840 && value % 2 === 0)) throw new Error('Invalid output dimensions.');
  if (!Number.isInteger(fps) || fps < 1 || fps > 60) throw new Error('Invalid output FPS.');
  if (!Number.isFinite(transitionSeconds) || transitionSeconds < 0 || transitionSeconds > 5) throw new Error('Transition duration must be between 0 and 5 seconds.');
  const args = [];
  clips.forEach(clip => args.push('-i', clip.path));
  const filters = [];
  clips.forEach((clip, index) => {
    filters.push(`[${index}:v:0]setpts=PTS-STARTPTS,fps=${fps},format=yuv420p,settb=AVTB[v${index}]`);
    filters.push(`[${index}:a:0]asetpts=PTS-STARTPTS,aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo[a${index}]`);
  });
  let video = 'v0', audio = 'a0', timeline = clips[0].durationSeconds;
  for (let index = 1; index < clips.length; index++) {
    const transition = clips[index].transition ?? 'cut';
    if (!['cut', 'fade', 'dissolve', 'slide'].includes(transition)) throw new Error(`Unsupported transition at clip ${index + 1}.`);
    const duration = Math.min(transition === 'cut' ? 0.001 : transitionSeconds, clips[index - 1].durationSeconds / 2, clips[index].durationSeconds / 2);
    const offset = Math.max(0, timeline - duration), nextVideo = `vx${index}`, nextAudio = `ax${index}`;
    const effect = transition === 'slide' ? 'slideleft' : transition === 'dissolve' ? 'dissolve' : 'fade';
    filters.push(`[${video}][v${index}]xfade=transition=${effect}:duration=${duration.toFixed(3)}:offset=${offset.toFixed(3)}[${nextVideo}]`);
    filters.push(`[${audio}][a${index}]acrossfade=d=${duration.toFixed(3)}:c1=tri:c2=tri[${nextAudio}]`);
    video = nextVideo; audio = nextAudio; timeline += clips[index].durationSeconds - duration;
  }
  args.push('-filter_complex', filters.join(';'), '-map', `[${video}]`, '-map', `[${audio}]`, '-c:v', 'libx264', '-preset', options.preset ?? 'veryfast', '-crf', String(options.crf ?? 21), '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-ac', '2', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', '-y', outputPath);
  return args;
}
