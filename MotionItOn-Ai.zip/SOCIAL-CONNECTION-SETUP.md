# Social and model-provider settings

The Settings screen now provides editable YouTube, TikTok and generic model-provider configuration fields. These are configuration forms, not a claim that account authorization or publishing is already live.

## YouTube
- Create OAuth credentials in Google Cloud Console.
- Configure the application callback URL in the OAuth client.
- Request the minimum YouTube Data API scope required for uploads (`https://www.googleapis.com/auth/youtube.upload`).
- Store the OAuth client secret and per-user refresh tokens on the backend only. Do not put them in browser storage.
- Complete the server OAuth callback, encrypted token storage, refresh and disconnect/revoke routes before enabling Connect or Publish.

Official references:
- https://developers.google.com/identity/protocols/oauth2
- https://developers.google.com/youtube/v3/guides/auth/server-side-web-apps

## TikTok
- Register the app in TikTok for Developers and add Login Kit and Content Posting API products as required.
- Register the exact web/mobile redirect URI.
- Request only the scopes the product needs. Direct posting requires approval for `video.publish` and explicit user authorization.
- Store client secret and user access/refresh tokens on the backend. Refresh tokens rotate; persist the replacement token each time.
- TikTok states unaudited clients' direct posts are restricted to private viewing. Complete TikTok's audit before promising public direct publishing.

Official references:
- https://developers.tiktok.com/docs/en/getting-started-create-an-app
- https://developers.tiktok.com/docs/en/scopes-overview
- https://developers.tiktok.com/docs/en/oauth-user-access-token-management
- https://developers.tiktok.com/docs/en/content-posting-api-get-started

## Generic model/API provider
The Settings form captures an HTTPS base URL, model identifier and optional organization/project. The API key is kept only in the current page session and is not persisted. A backend proxy with encrypted secret storage and provider-specific request/response handling must be implemented before a real model connection can be tested. Never send provider secrets directly from browser code to an arbitrary API endpoint.

## Current behavior
- Theme choice, output defaults, category preferences, social client IDs/keys and redirect URIs are saved in the user's local app preferences.
- OAuth client secrets and generic model API key are not saved in localStorage.
- “Validate” buttons validate required fields and clearly state that live authorization/provider testing is not active until backend OAuth/proxy routes are deployed.
- Developer-portal links open the official configuration consoles.
