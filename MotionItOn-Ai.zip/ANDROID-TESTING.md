# MotionItOn Android build and testing

## Build the APK without a computer

1. Push this project to the GitHub repository you already use. The workflow file is `.github/workflows/android-apk.yml`.
2. Open the repository in GitHub on your phone, choose **Actions**, then **Build MotionItOn Android APK**.
3. Tap **Run workflow** if it has not started automatically. Wait until the run shows a green check.
4. Open the successful run, scroll to **Artifacts**, and download `MotionItOn-Android-APK`.
5. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install. Android may ask you to allow installation from that source.

## Current limits

This build packages the web interface as an Android app. The rendering backend in `backend/server.mjs` is a Node.js service and FFmpeg executable; it is not automatically running inside the Android APK. The editor's render action currently requires a reachable rendering API configured in the app. A truly offline Android renderer needs a separate Android-native FFmpeg integration and device testing; this workflow does not claim to provide that yet.

The workflow builds an unsigned debug APK for personal testing, not a Play Store release.

## Build all platforms from the same project archive

The unified workflow `.github/workflows/build-all-platforms.yml` builds three artifacts from this same source tree: `MotionItOn-Web-Export`, `MotionItOn-Android-APK`, and `MotionItOn-Windows-Installer`. Run it from GitHub Actions after the source files and workflow have been committed to the repository. A green workflow confirms packaging completed, not that every feature has been device-tested.
