# MotionItOn-Ai Consolidated Development Checklist

This checklist is the source of truth across work sessions. Tick an item only after its implementation and available checks have been completed. Items requiring external services, credentials, hosting or a GPU are intentionally deferred.

## Dependency-free work (12 work packages)

- [ ] 01. Project management — create, save, reopen, rename, duplicate, delete, search, filter, account separation, local persistence and project backup/restore.
- [ ] 02. Categories — built-in categories, custom categories, category editing and filtering.
- [ ] 03. Series management — seasons, episode creation, ordering, metadata and series overview.
- [ ] 04. Scene management — create/edit/delete/reorder scenes, scene metadata and shot lists.
- [ ] 05. Character management — character profiles, descriptions, reference-image organisation and continuity notes.
- [ ] 06. Production workspace — script editor, story breakdown, production notes and shot planning.
- [ ] 07. Video editor — timeline, clip import, trim, split, reorder, preview and edit-plan persistence.
- [ ] 08. Audio and subtitles — audio track organisation, voiceover notes, subtitle editing and timing controls.
- [ ] 09. Queue management — job history, progress display, cancellation/retry where supported, cleanup and error reporting.
- [ ] 10. Settings — project defaults, export preferences, storage preferences and creator workflow settings.
- [ ] 11. Account security — session lifecycle, logout, account-scoped local data and backend ownership checks; email verification/recovery excluded for now.
- [ ] 12. Application stability — responsive layouts, navigation, validation, accessibility, tests and build checks.

## External dependency work (deferred)

- [ ] RunPod/GPU deployment and actual AI generation verification.
- [ ] Production cloud storage and retention policy.
- [ ] Email provider, email verification and account recovery.
- [ ] YouTube/TikTok/social OAuth and publishing integrations.
- [ ] Public backend/frontend hosting and production URL configuration.

## Session log

- 2026-11-03: Started consolidated pass using the latest supplied MotionItOn-Ai archive. Earlier work added rename, duplicate, confirmed delete and individual JSON backup export. These are not sufficient to sign off package 01.
- 2026-11-03: Added full-library JSON backup export and validated backup import for both single-project and multi-project backup files. Import validates app/schema and minimum project fields, preserves existing projects, and assigns a new ID/title when an imported ID already exists. Added responsive controls and user feedback. Backend ownership-scoped project endpoints were present in the supplied archive and syntax-checked.
- 2026-11-03: Added an Open action for every project and a project workspace form to edit/save title, category, format, duration, orientation, production notes and the saved story/script package. Changes update the existing project record and flow through the existing account-scoped local persistence/cloud-sync mechanism. Package 01 remains IN PROGRESS: conflict-safe cloud sync, restore validation tests, editor-to-project linkage, and complete package-level testing remain outstanding.

## Latest session verification

- `node --check backend/server.mjs`: PASS.
- `node --check backend/ai-video-engine.mjs`: PASS.
- ZIP integrity: PASS.
- Project workspace implementation: source inspection PASS; interactive browser testing NOT RUN.
- Web/TypeScript build: NOT RUN; `node_modules` is absent.
- Android/Windows builds: NOT RUN.

Do not mark a work package complete until its listed functionality and package-level checks pass.

## Patch integration — 2026-11-03

The corrected patch package has now been copied into the main application archive:

- Added category, series/scene, character, project sync, subtitle, audio-track, queue, settings and authentication services under `app/services/`.
- Added Production Workspace, Video Editor and Error Boundary components under `app/components/`.
- Wrapped the root application in the Error Boundary.
- Added `test/regression.test.mjs` and the `test:regression` package script.
- The Video Editor calls the existing browser FFmpeg `renderVideoLocally` implementation; it does not use the incompatible JSON `/api/render` request from the supplied draft.
- Project sync uses the existing account-owned `PUT /api/projects/:id` route.

Verification: six regression tests PASS; backend JavaScript syntax checks PASS; ZIP integrity checked after packaging. The Next.js production build and Android/Windows builds were not run because dependencies are not installed in this workspace. The new workspace/editor components are included as reusable components; full navigation and project-schema wiring into every existing screen still requires UI integration and browser testing. Do not treat all 12 work packages as production-signed-off.


## Engine quality upgrade — 2026-11-05
- [x] Add configurable standard/high generation profiles.
- [x] Set high profile default to 24 fps / 30 inference steps / 768x432 landscape or 432x768 portrait.
- [x] Make export encoding quality configurable.
- [x] Preserve current API routes and legacy request compatibility.
- [x] Validate backend engine request and worker execution with unit tests.
- [ ] Implement and benchmark modern model adapters (LTX-2.5, Wan 2.2, HunyuanVideo) on the selected RTX 3090.
- [ ] Add real character-reference conditioning and cross-scene identity controls.
- [ ] Add production voice/dialogue/music generation and audio synchronization.
- [ ] Add authenticated RunPod worker service, pod provisioning/idle shutdown, private object-storage upload and temporary-file cleanup.
- [ ] Run real RTX 3090 quality, VRAM, disk, runtime and cost benchmarks before claiming production readiness.

Do not mark deferred items complete based on documentation or configuration alone.


## 2026-11-05 — Model registry integration update

- Added `engine.model_registry` with explicit model capability and conservative VRAM checks.
- Added adapter interface and LTX legacy compatibility adapter.
- Integrated registry selection into `engine/generate_video.py`; retained 2–300 second scene-based jobs and existing FFmpeg output workflow.
- Passed existing model/style selection fields from the Node job runner to the Python worker.
- Added registry unit tests.
- LTX-2, Wan 2.2 and Hunyuan adapters remain registered but disabled until implemented and GPU-validated.
- Real RTX 3090 inference has not been tested.


## Phase 1 implementation update — 5 November 2026

The Phase 1 upgrade retains the existing Supabase/local-cache architecture and adds the following improvements without replacing existing services:

- Added a project production manager connected to project records for character profiles, episode creation/editing/deletion, scene creation/editing/deletion/reordering, scene duration, narration, visual prompts, and character-to-scene assignment.
- Added the missing General predefined category to the existing category engine.
- Added current-password reauthentication before password changes through the existing Supabase Auth session.
- Added authenticated cloud project deletion while retaining immediate local deletion and explicit offline status.
- Improved offline project-state cache retrieval and deletion helpers in ProjectSyncService.
- Improved project autosave failure reporting and ensured new projects receive an ISO updatedAt timestamp.
- Tightened video trim boundaries so start/end cannot collapse to an invalid zero-length segment.
- Corrected the Settings screen's draft-clear action to target the actual signed-in user's project cache key rather than unrelated legacy keys.

Verification: application regression tests and backend engine tests pass; Python syntax and model-registry tests pass. A full Next.js build, browser interaction test, Android build and Windows build were not run because dependencies are not installed in this workspace. Live Supabase password change/cloud deletion and cross-device sync require configured Supabase credentials and remain deployment verification items.

Additional Phase 1 account recovery update:
- Added a password-recovery request flow through the existing Supabase Auth `/recover` endpoint. The recovery link returns to the app, where the existing token/session completion flow establishes the recovery session; the signed-in Settings screen then supports a password update with current-password reauthentication for normal password changes.
- Added authenticated project deletion through the existing Supabase `user_projects` table endpoint, subject to the configured row-level security policy.

Remaining Phase 1 verification limitations:
- Custom category create/rename/delete exists in the category service, but a complete category-management screen and custom-category selection throughout every project form still require UI integration.
- Supabase recovery email delivery, password reset link behaviour, cloud project deletion and cross-device sync require the user's configured Supabase project and were not live-tested here.
- Full Next.js production build, interactive browser testing, Android build and Windows build remain unverified because this archive workspace has no installed npm dependencies.

## Phase 1 completion pass — 2026-11-05

### Implemented in this pass
- [x] Integrated custom category creation, listing, renaming and deletion into Settings.
- [x] Connected custom categories back into the Studio project creation, edit, filter and category-group lists when Settings closes.
- [x] Added a password-recovery request action using the existing Supabase Auth recovery endpoint.
- [x] Added persistent named AI worker profiles in `engine/worker_registry.py`.
- [x] Added worker management commands (`engine/manage_workers.py list|add|update|delete`).
- [x] Added authenticated-by-engine-key API routes to list, create, update and delete worker profiles.
- [x] Added worker selection to the AI generation screen and passed the selected worker through the existing job API and Python CLI.
- [x] Enforced that only implemented model adapters can be registered as runnable workers; the default worker cannot be disabled or deleted.
- [x] Added automated worker-registry tests and worker-selection request validation tests.

### Verification completed
- `python -m compileall -q engine`: PASS.
- `python -m unittest engine.test_model_registry engine.test_worker_registry -v`: PASS, 14 tests.
- `node --check backend/server.mjs`: PASS.
- `node --check backend/ai-video-engine.mjs`: PASS.
- `node --test backend/ai-video-engine.test.mjs`: PASS, 8 tests.
- `npm run test:regression`: PASS, 6 tests.
- TypeScript/TSX transpile syntax check for `app/page.tsx`, `SettingsView.tsx` and `AiVideoView.tsx`: PASS.
- ZIP integrity: checked at packaging time.

### Not production-verified
- Full Next.js build and ESLint: NOT RUN. `npm install --ignore-scripts --no-audit --no-fund` timed out and no `node_modules` directory was available.
- Browser interaction and live backend worker CRUD: NOT RUN because Node dependencies are not installed in this workspace.
- Supabase email recovery, live password update and cross-device sync: require the user's configured Supabase project and were not live-tested.
- Android and Windows builds: NOT RUN.
- AI worker profiles are named, selectable execution profiles. They currently bind to the default adapter (`wan-2.2-ti2v-5b`), with `ltx-legacy` retained as an optional legacy adapter; creating additional profiles does not create additional parallel GPU processes or install a new model.
- Video quality is not upgraded to the requested premium standard in this Phase 1 pass. The active legacy model remains 768x432 landscape / 432x768 portrait at its configured generation profile. Modern model integration and actual GPU quality benchmarking remain a separate engine milestone.

Do not treat unrun production checks or unavailable model adapters as complete.

### Additional finalisation fixes — 2026-11-05
- [x] Added the missing password-reset completion screen: the Supabase recovery callback establishes the recovery session, then the creator sets a new password without being asked for the forgotten current password.
- [x] Added worker registry support to the backend container image and placed the runtime registry on the persistent `/data` volume.
- [x] Added CLI smoke test for creating and listing a worker profile.
- [x] Added the selected worker ID to the AI generation job request and Python worker CLI path.
- [x] Connected custom categories to Studio category selection, project editing, filtering and grouping after returning from Settings.

Phase 1 source implementation is now complete for the app-level foundations and named worker-profile management. Release sign-off remains pending the unavailable dependency installation/full production build, live Supabase verification, browser tests and Android/Windows builds. The model quality ceiling is unchanged: only LTX legacy is implemented and no premium-quality claim is made.

## Phase 1 final build and browser verification gate (2026-11-05)

The following verification automation has been added:

- `playwright.config.ts` serves the static production export and runs Chromium browser tests.
- `e2e/auth-entry.spec.ts` covers sign-in rendering, account-creation form, password-recovery form, and navigation back to sign-in.
- `.github/workflows/phase1-full-verification.yml` builds the production web export, runs browser tests, builds an Android debug APK, and builds a Windows installer. It uploads each artifact and the browser report.

Local verification in the current execution environment:

- Backend tests: 8/8 passed.
- Application regression tests: 6/6 passed.
- Python engine and worker-registry tests: 14/14 passed.
- Python compilation: passed.
- Backend JavaScript syntax: passed.
- Package JSON and workflow YAML parsing: passed.

Still requires a network-enabled CI runner: dependency installation, Next.js production build, Chromium browser execution, Android Gradle build, and Windows NSIS installer build. The local `npm install` command timed out twice in this environment before dependencies could be installed. These builds must not be represented as passed until the workflow has run successfully.

## Phase 2 & Phase 3 upgrade — 2026-11-05

### Phase 2: Movie-production foundations
- [x] Preserved the existing `SeriesManager` API and added script validation, episode/scene duration totals, and proportional scene-duration allocation.
- [x] Added scene transition metadata with validation (`cut`, `fade`, `dissolve`, `slide`) without breaking existing saved scenes.
- [x] Added narration-to-timed-subtitle conversion from scene plans.
- [x] Added valid SRT and WebVTT generation, including millisecond formatting and VTT parsing.
- [x] Added a validated FFmpeg argv builder for normalized video/audio clip stitching. Arguments are passed as an array, not interpolated into a shell command.
- [x] Executed the FFmpeg builder against two generated clips with different dimensions and audio tracks; output MP4 was produced and ffprobe reported approximately 2.04 seconds.

### Phase 3: Backend, security and testing
- [x] Hardened engine API-key comparison with constant-time comparison.
- [x] Bounded and pruned the in-memory authentication rate-limit map.
- [x] Restricted video uploads to supported video MIME types.
- [x] Added strict trim-range validation and cleanup of rejected uploaded files.
- [x] Changed server error handling so unexpected server errors are logged server-side and do not disclose internal paths/FFmpeg details to clients.
- [x] Added regression tests for duration allocation, script validation, SRT/VTT round-tripping, scene subtitle export and FFmpeg argument construction.

### Phase 2 & 3 verification
- `node --experimental-strip-types test/regression.test.mjs`: PASS, 10/10.
- `node --test backend/ai-video-engine.test.mjs`: PASS, 8/8.
- `python -m compileall -q engine`: PASS.
- `python -m unittest engine.test_model_registry engine.test_worker_registry -v`: PASS, 14/14.
- `node --check backend/server.mjs`: PASS.
- `node --check backend/ai-video-engine.mjs`: PASS.
- FFmpeg two-clip stitch execution: PASS; ffprobe confirmed output duration.

### Not claimed complete
- Full Next.js production build, browser E2E, Android and Windows packaging remain dependent on successful dependency installation / CI execution.
- The FFmpeg stitch builder expects every supplied clip to contain an audio stream; clips without audio must first receive a silent audio track or be normalized by the backend render pipeline.
- The supplied transition metadata is validated and persisted in the scene model, but the current browser storyboard renderer does not yet render cinematic transition effects between generated footage clips.
- Authentication/API isolation remains enforced by the existing session middleware and per-user database queries; live multi-account HTTP integration tests still require installing runtime dependencies.

## Phase 4 & 5 — dependency-free implementation pass (2026-11-05)

### Phase 2/3 follow-through
- [x] Replaced concat-only editor stitch generation with FFmpeg `xfade` video transitions and `acrossfade` audio transitions (cut, fade, dissolve and slide).
- [x] Added silent-audio source injection for clips explicitly marked without audio in the reusable stitch builder.
- [x] Updated the backend render queue to probe source audio, inject silence for silent clips, normalize every clip to a common audio/video profile, and render actual transitions into the final MP4.
- [x] Added transition request validation to `/api/render`.
- [x] Executed an actual FFmpeg dissolve between clips with different dimensions and a silent first clip; ffprobe verified the resulting MP4.

### Phase 4 — GPU/cloud infrastructure code (no credentials or paid GPU used)
- [x] Added a Python-standard-library private remote worker HTTP service (`engine/remote_worker.py`) with authenticated job submission, progress polling, cancellation, output download, queue bounds and temporary output retention.
- [x] Added control-plane remote worker client with HTTPS enforcement, authenticated submit/poll/download, timeout and cancellation handling.
- [x] Integrated remote generation selection into the existing AI job queue when `MOTIONITON_REMOTE_WORKER_URL` is configured; local generation remains the default otherwise.
- [x] Added authenticated remote-worker health endpoint.
- [x] Added RunPod REST provider adapter for pod creation, status and termination, plus worker proxy URL and readiness polling helpers.
- [x] Added a GPU idle-shutdown manager utility.
- [x] Added a RunPod control CLI (`scripts/runpod-control.mjs`) for create, wait, status and terminate operations.
- [x] Added a private storage transfer abstraction using provider-issued presigned HTTPS URLs, streaming uploads/downloads, size limits and partial-file cleanup.
- [x] Updated the GPU worker Dockerfile to start the authenticated remote worker service.
- [x] Added remote worker profile handoff and character continuity data to remote jobs.

### Phase 5 — dependency-free generation/production improvements
- [x] Added deterministic style-aware prompt enhancement for realistic, cinematic, cartoon, documentary, cooking, nature and general production styles.
- [x] Added structured character continuity bible generation from character name, appearance and wardrobe.
- [x] Added character reference validation (maximum eight, unique names, bounded fields).
- [x] Integrated scene-specific prompt compilation into the Python video worker so each generated scene receives continuity, composition and quality-control instructions.
- [x] Added a production manifest builder that allocates requested duration across scene chunks without changing total runtime.
- [x] Passed character continuity information through the existing generation API and local/remote worker contracts.

### Phase 4/5 verification
- Python syntax compilation: PASS.
- Python model registry, worker registry, production planner and remote worker tests: PASS (25 tests after the final run).
- Node backend, remote-worker client, RunPod provider, storage helper, production-plan and application regression tests: PASS (see release verification output).
- FFmpeg integration: PASS; actual dissolve and silent-audio test produced an MP4 and ffprobe confirmed duration.
- No paid GPU, RunPod account, object-storage account, or AI API was used for these tests.

### Still dependent on external services/hardware (not claimed complete)
- RunPod pod creation, live worker readiness, GPU generation and actual idle shutdown against a rented pod require the user's RunPod API key, template ID, GPU type ID and worker token.
- Persistent cloud volume and object-storage integration require a storage account and credentials/presigned URL issuer. The streaming transfer code is implemented; no bucket was provisioned.
- Premium modern video models, image-to-video, image-reference conditioning, native voice/music/SFX generation and model-specific high-resolution output require model adapters, compatible package versions, model weights and GPU validation. Existing LTX legacy remains the only enabled model adapter.
- Character continuity in this pass is text-conditioned. It is not image-reference conditioning and does not guarantee identity consistency from the legacy model.
- Actual Android/Windows/Next production builds remain CI/dependency verification tasks from Phase 1.


## ChatGPT script submission bridge (software integration)
- [x] Authenticated ChatGPT GPT Action API contract and OpenAPI schema.
- [x] Owner-account isolation for submitted scripts.
- [x] Idempotent script submission.
- [x] Persistent queued production jobs in the existing AI job database.
- [x] Structured scene and character validation.
- [x] Scene-by-scene generation and FFmpeg assembly workflow.
- [x] Wait for configured remote GPU worker health before starting ChatGPT-submitted jobs.
- [x] Job status lookup and visibility in the existing AI jobs list.
- [ ] Configure public HTTPS endpoint, server token and ChatGPT GPT Action in the user's deployed accounts.
- [ ] Verify end-to-end Wan 2.2 production on the deployed GPU worker.
