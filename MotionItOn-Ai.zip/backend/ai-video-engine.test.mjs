import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeGenerateRequest } from './ai-video-engine.mjs';

test('defaults to Wan 2.2 automatic model selection and landscape output', () => {
  assert.deepEqual(normalizeGenerateRequest({ prompt: 'A bird flies over a lake' }), {
    prompt: 'A bird flies over a lake', model: 'motioniton-auto', ratio: '1280:720', duration: 3, quality: 'high', style: 'general',
  });
});
test('accepts portrait, custom durations and long-form productions up to five minutes', () => {
  assert.equal(normalizeGenerateRequest({ prompt: 'Rain on a window', ratio: '720:1280', duration: 5 }).ratio, '720:1280');
  assert.equal(normalizeGenerateRequest({ prompt: 'A cinematic river', duration: 12 }).duration, 12);
  assert.equal(normalizeGenerateRequest({ prompt: 'A cinematic river', duration: 20 }).duration, 20);
  assert.equal(normalizeGenerateRequest({ prompt: 'A cinematic river', duration: 60 }).duration, 60);
  assert.equal(normalizeGenerateRequest({ prompt: 'A cinematic river', duration: 120 }).duration, 120);
  assert.equal(normalizeGenerateRequest({ prompt: 'A cinematic river', duration: 300 }).duration, 300);
});
test('rejects empty/oversized prompts, unsupported ratios and durations', () => {
  for (const body of [{ prompt: '' }, { prompt: 'x'.repeat(1001) }, { prompt: 'x', ratio: '1:1' }, { prompt: 'x', duration: 301 }, { prompt: 'x', duration: 1 }]) {
    assert.throws(() => normalizeGenerateRequest(body));
  }
});

test('rejects unsupported generation modes and quality profiles', () => {
  assert.throws(() => normalizeGenerateRequest({ prompt: 'A quiet forest', model: 'runway' }), /Unsupported generation mode/);
  assert.throws(() => normalizeGenerateRequest({ prompt: 'A quiet forest', quality: 'ultra' }), /Quality must be/);
});

test('trims prompts and preserves the selected local model', () => {
  assert.deepEqual(normalizeGenerateRequest({ prompt: '  A quiet forest  ' }), {
    prompt: 'A quiet forest', model: 'motioniton-auto', ratio: '1280:720', duration: 3, quality: 'high', style: 'general',
  });
});

import { mkdtemp, writeFile, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { runLocalVideoGeneration } from './ai-video-engine.mjs';

test('streams structured worker progress and accepts a final JSON line without newline', async () => {
  const dir = await mkdtemp(path.join(os.tmpdir(), 'motioniton-worker-test-'));
  const worker = path.join(dir, 'worker.py');
  const oldWorker = process.env.MOTIONITON_VIDEO_WORKER;
  try {
    await writeFile(worker, "import sys\nprint('{\\\"type\\\":\\\"progress\\\",\\\"progress\\\":42,\\\"message\\\":\\\"frames generated\\\"}', flush=True)\nprint('{\\\"type\\\":\\\"progress\\\",\\\"progress\\\":100}', end='', flush=True)\n");
    process.env.MOTIONITON_VIDEO_WORKER = worker;
    const events = [];
    await runLocalVideoGeneration({ prompt: 'test', ratio: '1280:720', duration: 2, outputPath: path.join(dir, 'out.mp4'), onProgress: (progress, message) => events.push({ progress, message }), timeoutMs: 5000 });
    assert.deepEqual(events, [{ progress: 42, message: 'frames generated' }, { progress: 99, message: undefined }]);
  } finally {
    if (oldWorker === undefined) delete process.env.MOTIONITON_VIDEO_WORKER; else process.env.MOTIONITON_VIDEO_WORKER = oldWorker;
    await rm(dir, { recursive: true, force: true });
  }
});

test('stops a hung worker after the configured timeout', async () => {
  const dir = await mkdtemp(path.join(os.tmpdir(), 'motioniton-worker-timeout-'));
  const worker = path.join(dir, 'worker.py');
  const oldWorker = process.env.MOTIONITON_VIDEO_WORKER;
  try {
    await writeFile(worker, 'import time\ntime.sleep(10)\n');
    process.env.MOTIONITON_VIDEO_WORKER = worker;
    await assert.rejects(runLocalVideoGeneration({ prompt: 'test', ratio: '1280:720', duration: 2, outputPath: path.join(dir, 'out.mp4'), timeoutMs: 100 }), /exceeded the 1-second timeout/);
  } finally {
    if (oldWorker === undefined) delete process.env.MOTIONITON_VIDEO_WORKER; else process.env.MOTIONITON_VIDEO_WORKER = oldWorker;
    await rm(dir, { recursive: true, force: true });
  }
});

test('accepts a registered AI worker selection and rejects malformed worker IDs', () => {
  const request = normalizeGenerateRequest({ prompt: 'A quiet forest', workerId: 'worker-abc123' });
  assert.equal(request.workerId, 'worker-abc123');
  assert.throws(() => normalizeGenerateRequest({ prompt: 'A quiet forest', workerId: '../unsafe' }), /Invalid AI worker selection/);
});
