import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.motioniton.ai",
  appName: "MotionItOn",
  webDir: "out"
};

export default config;
