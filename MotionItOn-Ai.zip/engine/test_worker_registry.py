import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from engine.worker_registry import list_workers, create_worker, update_worker, delete_worker, select_worker, DEFAULT_WORKER_ID


class WorkerRegistryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.patch = patch.dict(os.environ, {"MOTIONITON_WORKERS_FILE": str(Path(self.temp.name) / "workers.json")})
        self.patch.start()

    def tearDown(self):
        self.patch.stop()
        self.temp.cleanup()

    def test_default_worker_available_without_registry_file(self):
        workers = list_workers()
        self.assertEqual(workers[0]["id"], DEFAULT_WORKER_ID)
        self.assertTrue(workers[0]["is_default"])
        self.assertEqual(workers[0]["model_id"], "wan-2.2-ti2v-5b")

    def test_create_worker_persists_and_selects(self):
        worker = create_worker("Documentary Worker", "wan-2.2-ti2v-5b", "doc-worker-01")
        self.assertEqual(worker["name"], "Documentary Worker")
        chosen, model = select_worker("doc-worker-01", requested_model="motioniton-auto", vram_gb=28)
        self.assertEqual(chosen["id"], "doc-worker-01")
        self.assertEqual(model.model_id, "wan-2.2-ti2v-5b")

    def test_worker_name_validation(self):
        with self.assertRaises(ValueError):
            create_worker("", "wan-2.2-ti2v-5b")

    def test_unimplemented_model_cannot_be_created_as_runnable_worker(self):
        with self.assertRaises(RuntimeError):
            create_worker("Future Worker", "ltx-2")

    def test_default_worker_cannot_be_deleted_or_disabled(self):
        with self.assertRaises(ValueError):
            delete_worker(DEFAULT_WORKER_ID)
        with self.assertRaises(ValueError):
            update_worker(DEFAULT_WORKER_ID, enabled=False)

    def test_worker_can_be_disabled_and_cannot_be_selected(self):
        create_worker("Temporary Worker", "wan-2.2-ti2v-5b", "temp-worker-01")
        update_worker("temp-worker-01", enabled=False)
        with self.assertRaises(ValueError):
            select_worker("temp-worker-01", requested_model="motioniton-auto", vram_gb=28)

    def test_worker_can_be_deleted(self):
        create_worker("Temporary Worker", "wan-2.2-ti2v-5b", "temp-worker-02")
        self.assertTrue(delete_worker("temp-worker-02"))
        self.assertFalse(any(w["id"] == "temp-worker-02" for w in list_workers()))


if __name__ == "__main__":
    unittest.main()
