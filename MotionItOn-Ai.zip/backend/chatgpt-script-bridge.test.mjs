import test from 'node:test';
import assert from 'node:assert/strict';
import { validateProductionScript, compileProductionPrompt } from './chatgpt-script-bridge.mjs';

const valid = {
  title: 'Tariro Episode 1', style: 'drama', ratio: '1280:720', quality: 'high',
  characters: [{ name: 'Tariro', appearance: 'Young adult woman with short natural black hair', wardrobe: 'Blue jacket' }],
  scenes: [
    { title: 'Opening', prompt: 'Tariro walks through a quiet village at sunrise.', durationSeconds: 10, transition: 'fade' },
    { title: 'Arrival', prompt: 'Tariro arrives at the old family home.', durationSeconds: 8, transition: 'dissolve' }
  ]
};

test('validates a structured ChatGPT production script', () => {
  const script = validateProductionScript(valid);
  assert.equal(script.totalDuration, 18);
  assert.equal(script.scenes.length, 2);
  assert.equal(script.characters[0].name, 'Tariro');
});

test('compiles scene prompts with character continuity and style', () => {
  const script = validateProductionScript(valid);
  const prompt = compileProductionPrompt(script, script.scenes[0], 0);
  assert.match(prompt, /Tariro Episode 1/);
  assert.match(prompt, /natural black hair/);
  assert.match(prompt, /dramatic/);
});

test('rejects missing scenes, invalid transitions and durations over five minutes', () => {
  assert.throws(() => validateProductionScript({ ...valid, scenes: [] }), /1–20 scenes/);
  assert.throws(() => validateProductionScript({ ...valid, scenes: [{ prompt: 'x', durationSeconds: 21 }] }), /2–20 seconds/);
  assert.throws(() => validateProductionScript({ ...valid, scenes: Array(16).fill({ prompt: 'x', durationSeconds: 20 }) }), /cannot exceed 300 seconds/);
  assert.throws(() => validateProductionScript({ ...valid, scenes: [{ prompt: 'x', durationSeconds: 5, transition: 'wipe' }] }), /unsupported transition/);
});

test('rejects invalid character references and unsupported styles', () => {
  assert.throws(() => validateProductionScript({ ...valid, style: 'unknown' }), /Unsupported style/);
  assert.throws(() => validateProductionScript({ ...valid, characters: [{ name: 'X', appearance: '' }] }), /needs a name and appearance/);
});
