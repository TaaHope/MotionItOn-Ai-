import test from 'node:test';
import assert from 'node:assert/strict';
import { verifySupabaseAccessToken } from './supabase-auth.mjs';

const env = { SUPABASE_URL: 'https://example.supabase.co', SUPABASE_ANON_KEY: 'anon-public-key' };
test('verifies a Supabase access token and returns a minimal account identity', async () => {
  let request;
  const user = await verifySupabaseAccessToken('access-token', { env, fetchImpl: async (url, options) => {
    request = { url, options };
    return new Response(JSON.stringify({ id: 'user-123', email: 'creator@example.com', user_metadata: { display_name: 'Creator' } }), { status: 200 });
  } });
  assert.equal(user.id, 'user-123');
  assert.equal(user.displayName, 'Creator');
  assert.equal(request.url, 'https://example.supabase.co/auth/v1/user');
  assert.equal(request.options.headers.Authorization, 'Bearer access-token');
  assert.equal(request.options.headers.apikey, env.SUPABASE_ANON_KEY);
});
test('rejects invalid Supabase access tokens without trusting their contents', async () => {
  const result = await verifySupabaseAccessToken('expired', { env, fetchImpl: async () => new Response('{}', { status: 401 }) });
  assert.equal(result, null);
});
test('returns null when Supabase Auth is not configured', async () => {
  assert.equal(await verifySupabaseAccessToken('token', { env: {} }), null);
});
