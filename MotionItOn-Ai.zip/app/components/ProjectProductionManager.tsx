'use client';

import React, { useMemo, useState } from 'react';
import { CharacterManager, CharacterProfile } from '../services/characterEngine';
import { EpisodeDetail, SceneItem, SeriesManager } from '../services/seriesAndSceneEngine';

type Props = {
  projectTitle: string;
  initialCharacters?: CharacterProfile[];
  initialEpisodes?: EpisodeDetail[];
  onSave: (data: { characters: CharacterProfile[]; episodes: EpisodeDetail[] }) => void;
  onClose: () => void;
};

export function ProjectProductionManager({ projectTitle, initialCharacters = [], initialEpisodes = [], onSave, onClose }: Props) {
  const [characters, setCharacters] = useState<CharacterProfile[]>(() => initialCharacters.filter(item => item && typeof item.id === 'string' && typeof item.name === 'string' && typeof item.description === 'string'));
  const [episodes, setEpisodes] = useState<EpisodeDetail[]>(() => initialEpisodes.filter(item => item && typeof item.id === 'string' && typeof item.title === 'string' && Array.isArray(item.scenes)).map(item => ({ ...item, scenes: item.scenes.filter(scene => scene && typeof scene.id === 'string' && typeof scene.title === 'string') }))); 
  const [selectedEpisode, setSelectedEpisode] = useState(initialEpisodes[0]?.id || '');
  const [characterName, setCharacterName] = useState('');
  const [characterRole, setCharacterRole] = useState<CharacterProfile['role']>('Supporting');
  const [characterDescription, setCharacterDescription] = useState('');
  const [characterReference, setCharacterReference] = useState('');
  const [episodeTitle, setEpisodeTitle] = useState('');
  const [sceneTitle, setSceneTitle] = useState('');
  const [message, setMessage] = useState('');

  const episode = episodes.find(item => item.id === selectedEpisode) || episodes[0] || null;
  const totalScenes = useMemo(() => episodes.reduce((sum, item) => sum + item.scenes.length, 0), [episodes]);

  function addCharacter() {
    try {
      const container = { characters: [...characters] };
      CharacterManager.addCharacterToProject(container, { name: characterName, role: characterRole, description: characterDescription, referenceImageUrl: characterReference.trim() || undefined });
      setCharacters(container.characters);
      setCharacterName(''); setCharacterDescription(''); setCharacterReference(''); setMessage('Character added to this project.');
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Could not add character.'); }
  }

  function addEpisode() {
    const next = SeriesManager.createEpisode(episodeTitle, episodes.length + 1);
    setEpisodes(current => [...current, next]); setSelectedEpisode(next.id); setEpisodeTitle('');
  }

  function updateEpisode(changes: Partial<Pick<EpisodeDetail, 'title' | 'synopsis'>>) {
    if (!episode) return;
    setEpisodes(current => SeriesManager.updateEpisode(current, episode.id, changes));
  }

  function addScene() {
    if (!episode) return;
    const scene = SeriesManager.createScene(sceneTitle || `Scene ${episode.scenes.length + 1}`);
    setEpisodes(current => current.map(item => item.id === episode.id ? { ...item, scenes: [...item.scenes, { ...scene, sceneNumber: item.scenes.length + 1 }] } : item));
    setSceneTitle('');
  }

  function updateScene(sceneId: string, changes: Partial<Omit<SceneItem, 'id' | 'sceneNumber'>>) {
    if (!episode) return;
    setEpisodes(current => current.map(item => item.id === episode.id ? { ...item, scenes: SeriesManager.updateScene(item.scenes, sceneId, changes) } : item));
  }

  function removeCharacter(id: string) {
    const container = { characters: [...characters] };
    CharacterManager.removeCharacterFromProject(container, id);
    setCharacters(container.characters);
    setEpisodes(current => current.map(item => ({ ...item, scenes: item.scenes.map(scene => ({ ...scene, characterIds: (scene.characterIds || []).filter(characterId => characterId !== id) })) })));
  }

  function assignCharacter(scene: SceneItem, characterId: string, checked: boolean) {
    if (!episode) return;
    const ids = new Set(scene.characterIds || []);
    if (checked) ids.add(characterId); else ids.delete(characterId);
    updateScene(scene.id, { characterIds: [...ids] } as Partial<Omit<SceneItem, 'id' | 'sceneNumber'>>);
  }

  return <div className="editor-backdrop" role="dialog" aria-modal="true" aria-label="Project production manager">
    <section className="editor-window" style={{ maxWidth: 1100, width: '96%' }}>
      <header className="editor-header"><div><h2>Production manager</h2><p>{projectTitle} · {episodes.length} episodes · {totalScenes} scenes · {characters.length} characters</p></div><button className="icon-button" onClick={onClose} aria-label="Close production manager">×</button></header>
      <div className="editor-body" style={{ display: 'grid', gridTemplateColumns: 'minmax(240px, 0.8fr) minmax(0, 1.5fr)', gap: 20, overflow: 'auto' }}>
        <section className="panel-card">
          <h3>Character profiles</h3>
          <label className="settings-field">Character name<input value={characterName} onChange={e => setCharacterName(e.target.value)} maxLength={80} /></label>
          <label className="settings-field">Role<select value={characterRole} onChange={e => setCharacterRole(e.target.value as CharacterProfile['role'])}><option>Protagonist</option><option>Antagonist</option><option>Supporting</option><option>Narrator</option></select></label>
          <label className="settings-field">Description<textarea value={characterDescription} onChange={e => setCharacterDescription(e.target.value)} rows={3} maxLength={2000} /></label>
          <label className="settings-field">Reference image URL<input type="url" value={characterReference} onChange={e => setCharacterReference(e.target.value)} placeholder="https://…" maxLength={2048}/></label>
          <button className="primary-button" disabled={!characterName.trim()} onClick={addCharacter}>Add character</button>
          <div className="mt-4 space-y-2">{characters.map(character => <div className="project-row" key={character.id}><div className="project-info"><b>{character.name}</b><small>{character.role} · {character.description}</small><input className="form-input" aria-label={`${character.name} description`} value={character.description} onChange={e => { const container={characters:[...characters]}; CharacterManager.updateCharacterInProject(container,{...character,description:e.target.value}); setCharacters(container.characters); }}/><input className="form-input" aria-label={`${character.name} reference image URL`} value={character.referenceImageUrl || ''} onChange={e => { const container={characters:[...characters]}; CharacterManager.updateCharacterInProject(container,{...character,referenceImageUrl:e.target.value || undefined}); setCharacters(container.characters); }} placeholder="Reference image URL"/></div><button className="delete-button" onClick={() => removeCharacter(character.id)} aria-label={`Remove ${character.name}`}>×</button></div>)}</div>
        </section>
        <section className="panel-card">
          <h3>Episodes and scenes</h3>
          <div className="flex gap-2"><input className="form-input" value={episodeTitle} onChange={e => setEpisodeTitle(e.target.value)} placeholder="Episode title" maxLength={120}/><button className="secondary-button" onClick={addEpisode}>Add episode</button></div>
          <div className="flex flex-wrap gap-2 mt-3">{episodes.map(item => <div key={item.id} className="flex gap-1 items-center"><button className={item.id === episode?.id ? 'primary-button' : 'secondary-button'} onClick={() => setSelectedEpisode(item.id)}>EP {item.episodeNumber}: {item.title}</button><button className="delete-button" aria-label={`Delete episode ${item.title}`} onClick={() => { const next = SeriesManager.deleteEpisode(episodes, item.id); setEpisodes(next); setSelectedEpisode(next[0]?.id || ''); }}>×</button></div>)}</div>
          {episode && <div className="mt-4 space-y-3">
            <label className="settings-field">Episode title<input value={episode.title} onChange={e => updateEpisode({ title: e.target.value })} maxLength={120}/></label>
            <label className="settings-field">Synopsis<textarea value={episode.synopsis} onChange={e => updateEpisode({ synopsis: e.target.value })} rows={2} maxLength={5000}/></label>
            <div className="flex gap-2"><input className="form-input" value={sceneTitle} onChange={e => setSceneTitle(e.target.value)} placeholder="New scene title" maxLength={120}/><button className="secondary-button" onClick={addScene}>Add scene</button></div>
            {episode.scenes.map(scene => <article className="panel-card" key={scene.id}>
              <div className="flex justify-between gap-2"><b>Scene {scene.sceneNumber}</b><div className="flex gap-2"><button className="secondary-button" disabled={scene.sceneNumber === 1} onClick={() => setEpisodes(current => current.map(item => item.id === episode.id ? { ...item, scenes: SeriesManager.reorderScenes(item.scenes, scene.sceneNumber - 1, scene.sceneNumber - 2) } : item))}>↑</button><button className="secondary-button" disabled={scene.sceneNumber === episode.scenes.length} onClick={() => setEpisodes(current => current.map(item => item.id === episode.id ? { ...item, scenes: SeriesManager.reorderScenes(item.scenes, scene.sceneNumber - 1, scene.sceneNumber) } : item))}>↓</button><button className="delete-button" onClick={() => setEpisodes(current => current.map(item => item.id === episode.id ? { ...item, scenes: SeriesManager.deleteScene(item.scenes, scene.id) } : item))}>Remove</button></div></div>
              <label className="settings-field">Title<input value={scene.title} onChange={e => updateScene(scene.id, { title: e.target.value })}/></label>
              <label className="settings-field">Visual prompt<textarea value={scene.visualPrompt} onChange={e => updateScene(scene.id, { visualPrompt: e.target.value })} rows={2}/></label>
              <label className="settings-field">Narration / dialogue<textarea value={scene.narrationText} onChange={e => updateScene(scene.id, { narrationText: e.target.value })} rows={2}/></label>
              <label className="settings-field">Duration (seconds)<input type="number" min="1" max="3600" value={scene.durationSeconds} onChange={e => updateScene(scene.id, { durationSeconds: Number(e.target.value) })}/></label>
              {characters.length > 0 && <div><b>Characters in this scene</b>{characters.map(character => <label key={character.id} className="setting-toggle"><span>{character.name}</span><input type="checkbox" checked={(scene.characterIds || []).includes(character.id)} onChange={e => assignCharacter(scene, character.id, e.target.checked)}/></label>)}</div>}
            </article>)}
          </div>}
          {message && <p className="settings-feedback" role="status">{message}</p>}
        </section>
      </div>
      <footer className="editor-header"><span>Changes are saved to the project when you select Save production.</span><button className="primary-button" onClick={() => onSave({ characters, episodes })}>Save production</button></footer>
    </section>
  </div>;
}
