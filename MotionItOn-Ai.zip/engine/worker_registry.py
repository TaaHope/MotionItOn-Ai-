"""Persistent registry for named MotionItOn AI generation workers.

A worker is a configured execution profile bound to a validated model adapter.
Profiles are stored outside source code and can be created without a GPU. A
profile is runnable only when its model adapter is implemented and the host
has a compatible CUDA device.
"""
from __future__ import annotations
import json
import os
import re
import tempfile
import uuid
from pathlib import Path
from typing import Any

from engine.model_registry import MODEL_REGISTRY, get_model

DEFAULT_WORKER_ID = "motioniton-default"
DEFAULT_WORKER = {
    "id": DEFAULT_WORKER_ID,
    "name": "MotionItOn Default Worker",
    "model_id": "wan-2.2-ti2v-5b",
    "enabled": True,
    "is_default": True,
}


def registry_path() -> Path:
    configured = os.environ.get("MOTIONITON_WORKERS_FILE")
    return Path(configured).expanduser().resolve() if configured else Path(__file__).with_name("workers.json")


def _validate_worker(value: Any) -> dict:
    if not isinstance(value, dict):
        raise ValueError("Worker profile must be an object.")
    worker_id = value.get("id")
    name = value.get("name")
    model_id = value.get("model_id")
    if not isinstance(worker_id, str) or not re.fullmatch(r"[a-zA-Z0-9_-]{3,80}", worker_id):
        raise ValueError("Worker ID must contain 3–80 letters, numbers, underscores or hyphens.")
    if not isinstance(name, str) or not name.strip() or len(name.strip()) > 80:
        raise ValueError("Worker name must contain 1–80 characters.")
    if model_id not in MODEL_REGISTRY:
        raise ValueError("Worker references an unknown model adapter.")
    description = value.get("description", "")
    if not isinstance(description, str) or len(description) > 1200:
        raise ValueError("Worker description must be text no longer than 1200 characters.")
    if not isinstance(value.get("enabled", True), bool):
        raise ValueError("Worker enabled flag must be boolean.")
    return {"id": worker_id, "name": name.strip(), "model_id": model_id,
            "enabled": value.get("enabled", True), "is_default": bool(value.get("is_default", False)), "description": description.strip()}


def list_workers() -> list[dict]:
    path = registry_path()
    if not path.exists():
        return [dict(DEFAULT_WORKER)]
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(raw, list):
            raise ValueError("Worker registry must contain a JSON array.")
        workers = [_validate_worker(item) for item in raw]
        ids = [item["id"] for item in workers]
        if len(ids) != len(set(ids)):
            raise ValueError("Worker registry contains duplicate IDs.")
        if not workers:
            return [dict(DEFAULT_WORKER)]
        if not any(item["enabled"] for item in workers):
            raise ValueError("At least one AI worker must remain enabled.")
        return workers
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Could not read AI worker registry: {exc}") from exc


def _write(workers: list[dict]) -> None:
    path = registry_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix="workers-", suffix=".json", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(workers, stream, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def create_worker(name: str, model_id: str, worker_id: str | None = None, description: str = "") -> dict:
    # Creation is allowed only for implemented adapters; no fake runnable workers.
    get_model(model_id)
    workers = list_workers()
    new_id = worker_id or f"worker-{uuid.uuid4().hex[:12]}"
    if any(item["id"] == new_id for item in workers):
        raise ValueError("An AI worker with this ID already exists.")
    item = _validate_worker({"id": new_id, "name": name, "model_id": model_id, "enabled": True, "is_default": False, "description": description})
    workers.append(item)
    _write(workers)
    return item


def update_worker(worker_id: str, *, name: str | None = None, enabled: bool | None = None) -> dict:
    workers = list_workers()
    for index, item in enumerate(workers):
        if item["id"] != worker_id:
            continue
        updated = dict(item)
        if name is not None:
            updated["name"] = name
        if enabled is not None:
            if item["is_default"] and not enabled:
                raise ValueError("The default AI worker cannot be disabled.")
            updated["enabled"] = enabled
        updated = _validate_worker(updated)
        workers[index] = updated
        if not any(worker["enabled"] for worker in workers):
            raise ValueError("At least one AI worker must remain enabled.")
        _write(workers)
        return updated
    raise ValueError("AI worker was not found.")


def delete_worker(worker_id: str) -> bool:
    workers = list_workers()
    target = next((item for item in workers if item["id"] == worker_id), None)
    if target is None:
        return False
    if target["is_default"]:
        raise ValueError("The default AI worker cannot be deleted.")
    _write([item for item in workers if item["id"] != worker_id])
    return True


def select_worker(worker_id: str | None = None, requested_model: str = "motioniton-auto", style: str = "general", task: str = "text_to_video", vram_gb: float | None = None):
    from engine.model_registry import select_model
    workers = list_workers()
    enabled = [item for item in workers if item["enabled"]]
    if worker_id:
        chosen = next((item for item in enabled if item["id"] == worker_id), None)
        if chosen is None:
            raise ValueError("Selected AI worker does not exist or is disabled.")
    else:
        chosen = next((item for item in enabled if item["is_default"]), enabled[0])
    model_request = chosen["model_id"] if requested_model in ("motioniton-auto", "ltx-video-local") else requested_model
    model = select_model(style=style, task=task, requested_model=model_request, vram_gb=vram_gb)
    if model.model_id != chosen["model_id"]:
        raise RuntimeError("Selected worker does not support the requested model.")
    return chosen, model
