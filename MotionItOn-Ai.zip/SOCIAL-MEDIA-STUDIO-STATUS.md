# Social Media Studio integration

This is an additive integration. Existing application folders, generation engine, projects, storage and workflows are retained.

## Included in this build
- New Social Media Studio navigation entry and screen.
- Select and preview an existing finished video file.
- Prepare platform title, description/caption and hashtags.
- Copy publishing metadata.
- Export a video file for manual TikTok upload without depending on TikTok Content Posting API approval.
- Optional planned publishing date field (planning only; no scheduler is claimed).
- Explicit status messages explaining which external credentials are still required.

## Not activated yet
- YouTube direct upload and scheduled publishing require a configured Google Cloud project, YouTube Data API enabled, OAuth consent configuration, and client credentials stored on the backend. No credentials were supplied in this project archive, so direct upload is not falsely represented as active.
- TikTok public direct posting is intentionally excluded because the Content Posting API requires app review/audit. Manual export is supported.
- Automatic clip extraction from a long video is not included in this UI change; it needs to be wired to the existing FFmpeg renderer and verified against actual media.

## Account details
The account email addresses provided by the user are identifiers only. They are not embedded as credentials and do not grant access. Account linking must use official OAuth sign-in.
