'use client';
import React, { useEffect, useState } from 'react';
import { AccountService } from '../services/accountService';
import { CategoryManager, CategoryConfig } from '../services/categoryEngine';
import { Trash2, ArrowLeft, Check, UserRound, Film, AudioLines, Cloud, ShieldCheck, Bell, Plus, LogOut, Globe, CreditCard, SlidersHorizontal } from 'lucide-react';

type Preferences = {
  displayName: string; defaultResolution: string; aspectRatio: string; frameRate: string;
  defaultDuration: string; narration: boolean; subtitles: boolean; characterReferences: boolean;
  saveDrafts: boolean; notifications: boolean; backendUrl: string; backendKey: string;
  theme: string; publishingPlatforms: string[]; aiBaseUrl: string; aiModel: string; aiOrganization: string; youtubeClientId: string; youtubeRedirectUri: string; tiktokClientKey: string; tiktokRedirectUri: string;
};
const KEY = 'motioniton_preferences_v1';
const defaults: Preferences = {
  displayName: '', defaultResolution: '1080p', aspectRatio: '9:16', frameRate: '30 fps',
  defaultDuration: '30 seconds', narration: true, subtitles: true, characterReferences: true,
  saveDrafts: true, notifications: true, backendUrl: '', backendKey: '', theme: 'Dark', publishingPlatforms: ['YouTube','TikTok','Instagram','Facebook','X','Vimeo'], aiBaseUrl: '', aiModel: '', aiOrganization: '', youtubeClientId: '', youtubeRedirectUri: '', tiktokClientKey: '', tiktokRedirectUri: ''
};
function Toggle({ label, description, checked, onChange }: {label:string;description:string;checked:boolean;onChange:(v:boolean)=>void}) {
  return <label className="setting-toggle"><span><b>{label}</b><small>{description}</small></span><input type="checkbox" checked={checked} onChange={e=>onChange(e.target.checked)} /></label>;
}
export function SettingsView({ onBack, onSignOut, section = 'settings' }: { onBack: () => void; onSignOut: () => void; section?: 'account' | 'settings' }) {
  const [prefs,setPrefs] = useState<Preferences>(defaults);
  const [savedStatus,setSavedStatus] = useState(false);
  const [storage,setStorage] = useState<{usage?:number;quota?:number}|null>(null);
  const [error,setError] = useState('');
  const [newPlatform,setNewPlatform] = useState('');
  const [currentPassword,setCurrentPassword] = useState('');
  const [newPassword,setNewPassword] = useState('');
  const [accountBusy,setAccountBusy] = useState(false);
  const [accountMessage,setAccountMessage] = useState('');
  const [email,setEmail] = useState('');
  const [profilePhoto,setProfilePhoto] = useState('');
  const [billingMessage,setBillingMessage] = useState('PayPal checkout is not active yet. A merchant email alone cannot process payments; secure PayPal REST app credentials and a deployed HTTPS backend are required.');
  const [categories,setCategories] = useState<CategoryConfig[]>([]);
  const [categoryName,setCategoryName] = useState('');
  const [categoryTag,setCategoryTag] = useState('');
  const [categoryColor,setCategoryColor] = useState('#6b7280');
  const [recoveryEmail,setRecoveryEmail] = useState('');
  const [recoveryBusy,setRecoveryBusy] = useState(false);
  const [aiApiKey,setAiApiKey] = useState('');
  const [youtubeClientSecret,setYoutubeClientSecret] = useState('');
  const [tiktokClientSecret,setTiktokClientSecret] = useState('');
  const [integrationNotice,setIntegrationNotice] = useState('');
  useEffect(()=>{
    try { const raw=localStorage.getItem(KEY); const user=JSON.parse(localStorage.getItem('motioniton_user')||'{}') as {displayName?:string;email?:string;user_metadata?:{display_name?:string}}; const name=user.user_metadata?.display_name||user.displayName||''; setEmail(user.email||''); setProfilePhoto(localStorage.getItem('motioniton_profile_photo')||''); if(raw) { const loaded={...defaults,...JSON.parse(raw),displayName:name||JSON.parse(raw).displayName||'',theme:(localStorage.getItem('motioniton-theme')==='light'?'Light':'Dark')}; setPrefs(loaded); document.documentElement.dataset.theme=String(loaded.theme||'Dark').toLowerCase(); } else if(name) setPrefs(p=>({...p,displayName:name})); } catch { setError('Saved preferences could not be read.'); }
    setCategories(CategoryManager.getCategories());
    if(navigator.storage?.estimate) navigator.storage.estimate().then(v=>setStorage({usage:v.usage,quota:v.quota})).catch(()=>setStorage(null));
  },[]);
  const update = <K extends keyof Preferences>(key:K,value:Preferences[K])=>setPrefs(p=>({...p,[key]:value}));
  const save=()=>{ try { localStorage.removeItem('motioniton_auth_url'); localStorage.setItem(KEY,JSON.stringify(prefs)); localStorage.setItem('motioniton-theme',prefs.theme.toLowerCase()); localStorage.setItem('motioniton_ai_backend_url',prefs.backendUrl); localStorage.setItem('motioniton_ai_backend_key',prefs.backendKey); document.documentElement.dataset.theme=prefs.theme.toLowerCase(); setSavedStatus(true); setError(''); window.setTimeout(()=>setSavedStatus(false),2500); } catch(e) {setError(e instanceof Error?e.message:'Could not save settings.');} };
  const clear=()=>{ if(!confirm('Clear this account’s saved project drafts from this device? This does not delete exported videos or cloud projects.')) return; try { const userId=(JSON.parse(localStorage.getItem('motioniton_user')||'{}') as {id?:string}).id; if(userId) localStorage.removeItem(`motioniton-projects-${userId}`); localStorage.removeItem('storymotion-projects'); localStorage.removeItem('motioniton_projects_cache'); window.location.reload();}catch(e){setError(e instanceof Error?e.message:'Could not clear drafts.');} };
  const bytes=(n?:number)=>typeof n==='number'?`${(n/1048576).toFixed(1)} MB`:'Unavailable';
  const updateProfile=async()=>{setAccountBusy(true);setAccountMessage('');try{const user=await AccountService.updateUser({data:{display_name:prefs.displayName.trim()}});localStorage.setItem('motioniton_user',JSON.stringify(user));setAccountMessage('Profile updated.');}catch(e){setError(e instanceof Error?e.message:String(e));}finally{setAccountBusy(false);}};
  const updateEmail=async()=>{setAccountBusy(true);setAccountMessage('');try{if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()))throw new Error('Enter a valid email address.');const user=await AccountService.updateUser({email:email.trim().toLowerCase()});localStorage.setItem('motioniton_user',JSON.stringify(user));setAccountMessage('Email change requested. Check your inbox to confirm the new address.');}catch(e){setError(e instanceof Error?e.message:String(e));}finally{setAccountBusy(false);}};
  const updatePhoto=(file?:File)=>{if(!file)return;if(!file.type.startsWith('image/')){setError('Choose an image file.');return;}if(file.size>3*1024*1024){setError('Profile pictures must be 3 MB or smaller.');return;}const reader=new FileReader();reader.onload=()=>{const value=String(reader.result||'');setProfilePhoto(value);localStorage.setItem('motioniton_profile_photo',value);};reader.readAsDataURL(file);};
  const updatePassword=async()=>{setAccountBusy(true);setAccountMessage('');setError('');try{await AccountService.changePassword(currentPassword,newPassword);setCurrentPassword('');setNewPassword('');setAccountMessage('Password changed successfully.');}catch(e){setError(e instanceof Error?e.message:String(e));}finally{setAccountBusy(false);}};
  const requestRecovery=async()=>{setRecoveryBusy(true);setError('');setAccountMessage('');try{await AccountService.requestPasswordReset(recoveryEmail || email);setAccountMessage('Password recovery email requested. Check your inbox and follow the secure link.');}catch(e){setError(e instanceof Error?e.message:String(e));}finally{setRecoveryBusy(false);}};
  const addCategory=()=>{try{CategoryManager.addCategory(categoryName,categoryTag,categoryColor);setCategories(CategoryManager.getCategories());setCategoryName('');setCategoryTag('');setError('');setAccountMessage('Custom category created.');}catch(e){setError(e instanceof Error?e.message:String(e));}};
  const renameCategory=(item:CategoryConfig)=>{if(!item.isCustom)return;const name=window.prompt('New category name',item.name);if(name===null)return;try{CategoryManager.renameCategory(item.id,name);setCategories(CategoryManager.getCategories());}catch(e){setError(e instanceof Error?e.message:String(e));}};
  const deleteCategory=(item:CategoryConfig)=>{if(!item.isCustom)return;if(!window.confirm(`Delete the custom category \"${item.name}\"? Existing projects will not be deleted.`))return;try{CategoryManager.deleteCategory(item.id);setCategories(CategoryManager.getCategories());}catch(e){setError(e instanceof Error?e.message:String(e));}};
  const validateAiSettings=()=>{if(!prefs.aiBaseUrl.trim()||!/^https:\/\//i.test(prefs.aiBaseUrl.trim())){setIntegrationNotice('Enter a valid HTTPS API base URL.');return;}if(!prefs.aiModel.trim()){setIntegrationNotice('Enter the model identifier required by your provider.');return;}if(!aiApiKey.trim()){setIntegrationNotice('Enter the API key. It remains in this session and is not saved in browser storage.');return;}setIntegrationNotice('Fields are complete. Server-side provider testing is not enabled yet; no live connection has been made.');};
  return <section className="settings-panel" data-theme={prefs.theme.toLowerCase()}>
    <header className="panel-head"><button className="secondary-button" onClick={onBack}><ArrowLeft size={16}/> Back</button><div><h2>{section === 'account' ? 'Account & profile' : 'General settings'}</h2><p>{section === 'account' ? 'Manage your personal account and subscription.' : 'Manage your application preferences and AI production settings.'}</p></div>{section === 'settings' && <button className="primary-button" onClick={save}><Check size={16}/> Save settings</button>}</header>
    <div className="panel-grid">
      {section === 'account' && <>
      <article className="panel-card"><h3><UserRound size={18}/> Profile & account</h3><label className="settings-field">Email address<input type="email" value={email} readOnly placeholder="you@example.com"/></label><label className="settings-field">Display name<input value={prefs.displayName} onChange={e=>update('displayName',e.target.value)} placeholder="Your creator name" /></label><button className="secondary-button" disabled={accountBusy||prefs.displayName.trim().length<2} onClick={()=>void updateProfile()}>Update profile</button><p className="field-hint">Verify your current password before changing it. New passwords require at least 10 characters, including letters and numbers.</p><label className="settings-field">Current password<input type="password" value={currentPassword} onChange={e=>setCurrentPassword(e.target.value)} autoComplete="current-password" /></label><label className="settings-field">New password<input type="password" value={newPassword} onChange={e=>setNewPassword(e.target.value)} minLength={10} autoComplete="new-password" /></label><button className="secondary-button" disabled={accountBusy||!currentPassword||newPassword.length<10} onClick={()=>void updatePassword()}>Change password</button>{accountMessage&&<p className="settings-feedback" role="status">{accountMessage}</p>}<article className="account-recovery"><h3><ShieldCheck size={18}/> Password recovery</h3><label className="settings-field">Account email<input type="email" value={recoveryEmail} onChange={e=>setRecoveryEmail(e.target.value)} placeholder={email||'you@example.com'}/></label><button className="secondary-button" disabled={recoveryBusy||!(recoveryEmail||email).trim()} onClick={()=>void requestRecovery()}>{recoveryBusy?'Requesting…':'Send password recovery email'}</button></article><button className="secondary-button danger-button" onClick={onSignOut}><LogOut size={15}/> Sign out</button></article>
      <article className="panel-card subscription-settings"><h3><CreditCard size={18}/> Subscription & credits</h3><p>Manage your creator subscription.</p><div className="subscription-plan-row"><div><b>Creator</b><small>Monthly plan · credits for exports and publishing</small></div><span>Coming soon</span></div><div className="subscription-plan-row"><div><b>Studio</b><small>Higher monthly credit allowance</small></div><span>Coming soon</span></div></article></>}
      {section === 'settings' && <>
        <article className="panel-card"><h3><SlidersHorizontal size={18}/> General settings</h3><p>Set the default output and behaviour for new videos.</p>
          <div className="settings-fields-grid">
            <label className="settings-field">Resolution<select value={prefs.defaultResolution} onChange={e=>update('defaultResolution',e.target.value)}><option>720p</option><option>1080p</option><option>4K</option></select></label>
            <label className="settings-field">Aspect ratio<select value={prefs.aspectRatio} onChange={e=>update('aspectRatio',e.target.value)}><option>9:16</option><option>16:9</option><option>1:1</option></select></label>
            <label className="settings-field">Frame rate<select value={prefs.frameRate} onChange={e=>update('frameRate',e.target.value)}><option>24 fps</option><option>25 fps</option><option>30 fps</option><option>60 fps</option></select></label>
            <label className="settings-field">Default duration<select value={prefs.defaultDuration} onChange={e=>update('defaultDuration',e.target.value)}><option>15 seconds</option><option>30 seconds</option><option>45 seconds</option><option>60 seconds</option><option>90 seconds</option></select></label>
          </div>
        </article>
        <article className="panel-card"><h3><AudioLines size={18}/> Audio and continuity</h3>
          <Toggle label="Narration by default" description="Include narration options in new production plans." checked={prefs.narration} onChange={v=>update('narration',v)}/>
          <Toggle label="Subtitles by default" description="Include subtitle planning in new projects." checked={prefs.subtitles} onChange={v=>update('subtitles',v)}/>
          <Toggle label="Character reference workflow" description="Keep recurring character references consistent across episodes." checked={prefs.characterReferences} onChange={v=>update('characterReferences',v)}/>
        </article>
        <article className="panel-card"><h3><Globe size={18}/> Publishing destinations</h3><p>Choose the platforms you prepare videos for.</p>
          <div className="platform-chips">{prefs.publishingPlatforms.map(name=><span className="platform-chip" key={name}>{name}<button type="button" aria-label={`Remove ${name}`} onClick={()=>update('publishingPlatforms',prefs.publishingPlatforms.filter(x=>x!==name))}>×</button></span>)}</div>
          <div className="platform-add"><input value={newPlatform} onChange={e=>setNewPlatform(e.target.value)} placeholder="Add platform or channel" maxLength={40}/><button type="button" className="secondary-button" onClick={()=>{const v=newPlatform.trim();if(v&&!prefs.publishingPlatforms.some(x=>x.toLowerCase()===v.toLowerCase()))update('publishingPlatforms',[...prefs.publishingPlatforms,v]);setNewPlatform('');}}><Plus size={16}/> Add</button></div>
        </article>
        <article className="panel-card integration-settings-card"><h3><Globe size={18}/> Social accounts & publishing</h3><p>Prepare secure account connections. OAuth secrets must be configured on the server; never paste them into a shared or public device.</p>
          <div className="integration-platform"><div><b>YouTube</b><small>Google OAuth · upload permission</small></div><span className="integration-state">Not connected</span></div>
          <label className="settings-field">Google OAuth Client ID<input value={prefs.youtubeClientId} onChange={e=>update('youtubeClientId',e.target.value)} placeholder="Client ID from Google Cloud" autoComplete="off"/></label>
          <label className="settings-field">OAuth redirect URI<input value={prefs.youtubeRedirectUri} onChange={e=>update('youtubeRedirectUri',e.target.value)} placeholder="https://your-domain.com/api/oauth/youtube/callback"/></label>
          <label className="settings-field">Client secret<input type="password" value={youtubeClientSecret} onChange={e=>setYoutubeClientSecret(e.target.value)} placeholder="Configure securely on backend" autoComplete="new-password"/></label>
          <button className="secondary-button" type="button" onClick={()=>{if(!prefs.youtubeClientId.trim()||!prefs.youtubeRedirectUri.trim())setIntegrationNotice('Enter the YouTube Client ID and redirect URI first.');else setIntegrationNotice('YouTube details are ready for server-side OAuth setup. Account authorization is not active yet.');}}>Validate YouTube fields</button>
          <button className="text-link-button" type="button" onClick={()=>window.open('https://console.cloud.google.com/apis/credentials','_blank','noopener,noreferrer')}>Open Google Cloud credentials</button>
          <div className="integration-platform"><div><b>TikTok</b><small>Login Kit / Content Posting API</small></div><span className="integration-state">Not connected</span></div>
          <label className="settings-field">TikTok Client Key<input value={prefs.tiktokClientKey} onChange={e=>update('tiktokClientKey',e.target.value)} placeholder="Client key from TikTok for Developers" autoComplete="off"/></label>
          <label className="settings-field">OAuth redirect URI<input value={prefs.tiktokRedirectUri} onChange={e=>update('tiktokRedirectUri',e.target.value)} placeholder="https://your-domain.com/api/oauth/tiktok/callback"/></label>
          <label className="settings-field">Client secret<input type="password" value={tiktokClientSecret} onChange={e=>setTiktokClientSecret(e.target.value)} placeholder="Configure securely on backend" autoComplete="new-password"/></label>
          <button className="secondary-button" type="button" onClick={()=>{if(!prefs.tiktokClientKey.trim()||!prefs.tiktokRedirectUri.trim())setIntegrationNotice('Enter the TikTok Client Key and redirect URI first.');else setIntegrationNotice('TikTok details are ready for server-side OAuth setup. Account authorization is not active yet.');}}>Validate TikTok fields</button>
          <button className="text-link-button" type="button" onClick={()=>window.open('https://developers.tiktok.com/','_blank','noopener,noreferrer')}>Open TikTok developer portal</button>
          <p className="field-hint">Direct publishing requires approved API products, granted scopes and server-side token storage. TikTok unaudited clients may be restricted to private posts.</p>
        </article>
        <article className="panel-card integration-settings-card"><h3><ShieldCheck size={18}/> AI provider connection</h3><p>Generic connection fields for the next supported model/API provider. No provider brand is assumed.</p>
          <label className="settings-field">API base URL<input value={prefs.aiBaseUrl} onChange={e=>update('aiBaseUrl',e.target.value)} placeholder="https://api.provider.com/v1" inputMode="url"/></label>
          <label className="settings-field">Model identifier<input value={prefs.aiModel} onChange={e=>update('aiModel',e.target.value)} placeholder="e.g. model-name"/></label>
          <label className="settings-field">Organization / project (optional)<input value={prefs.aiOrganization} onChange={e=>update('aiOrganization',e.target.value)} placeholder="Organization or project ID"/></label>
          <label className="settings-field">API key<input type="password" value={aiApiKey} onChange={e=>setAiApiKey(e.target.value)} placeholder="Enter key for this session" autoComplete="new-password"/></label>
          <button type="button" className="secondary-button" onClick={validateAiSettings}>Validate connection fields</button>
          <p className="field-hint">API keys and OAuth client secrets are not saved in browser storage. Live connection testing and encrypted server-side credential storage require backend integration.</p>
        </article>
        <article className="panel-card"><h3><Cloud size={18}/> Workspace and storage</h3>
          <Toggle label="Save project drafts" description="Keep project plans on this device." checked={prefs.saveDrafts} onChange={v=>update('saveDrafts',v)}/>
          <p>Browser storage used: <b>{bytes(storage?.usage)}</b></p><p>Available browser quota: <b>{bytes(storage?.quota)}</b></p>
          <button className="secondary-button danger-button" onClick={clear}><Trash2 size={15}/> Clear project drafts</button>
        </article>
        <article className="panel-card"><h3><Bell size={18}/> Notifications</h3>
          <Toggle label="In-app notifications" description="Show generation and project status messages." checked={prefs.notifications} onChange={v=>update('notifications',v)}/>
        </article>
        <article className="panel-card"><h3><Film size={18}/> Categories</h3><p>Manage the categories available when creating projects. Built-in categories are protected.</p>
          <div className="settings-fields-grid">
            <label className="settings-field">Category name<input value={categoryName} onChange={e=>setCategoryName(e.target.value)} maxLength={50} placeholder="e.g. Travel"/></label>
            <label className="settings-field">Category tag<input value={categoryTag} onChange={e=>setCategoryTag(e.target.value)} maxLength={20} placeholder="e.g. TRAVEL"/></label>
            <label className="settings-field">Category colour<input type="color" value={categoryColor} onChange={e=>setCategoryColor(e.target.value)}/></label>
          </div>
          <button className="secondary-button" disabled={!categoryName.trim()||!categoryTag.trim()} onClick={addCategory}><Plus size={15}/> Add category</button>
          <div className="mt-3 space-y-2">{categories.map(item=><div className="project-row" key={item.id}><div className="project-info"><b><span style={{display:'inline-block',width:9,height:9,borderRadius:99,background:item.color,marginRight:8}}/>{item.name}</b><small>{item.tag} · {item.isCustom?'Custom category':'Built-in category'}</small></div>{item.isCustom&&<div className="flex gap-2"><button className="secondary-button" onClick={()=>renameCategory(item)}>Rename</button><button className="delete-button" onClick={()=>deleteCategory(item)} aria-label={`Delete ${item.name}`}>×</button></div>}</div>)}</div>
        </article>
        <details className="settings-advanced"><summary><ShieldCheck size={15}/> Advanced system configuration</summary><article className="panel-card"><h3><Cloud size={18}/> AI engine connection</h3><p className="field-hint">Administrative connection settings. Changes take effect after saving.</p><label className="settings-field">Service URL<input value={prefs.backendUrl} onChange={e=>update('backendUrl',e.target.value)} placeholder="https://your-engine.example.com" inputMode="url" autoComplete="url" /></label><label className="settings-field">Access key<input type="password" value={prefs.backendKey} onChange={e=>update('backendKey',e.target.value)} placeholder="Engine access key" autoComplete="off" /></label></article></details>
      </>}

    </div>
    {integrationNotice&&<p className="settings-feedback" role="status">{integrationNotice}</p>}{savedStatus&&<p className="settings-feedback" role="status"><Check size={16}/> Settings saved on this device. Social OAuth secrets and the model-provider key remain session-only.</p>}{error&&<p className="settings-feedback error" role="alert">{error}</p>}

  </section>;
}
