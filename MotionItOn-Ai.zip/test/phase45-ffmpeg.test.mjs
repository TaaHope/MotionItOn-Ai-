import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { buildFfmpegStitchCommand } from '../app/services/videoSynthesizer.ts';
import { buildFfmpegStitchArgs } from '../backend/ffmpeg-stitch.mjs';

const available = spawnSync('ffmpeg', ['-version'], { encoding: 'utf8' }).status === 0;
test('FFmpeg renders dissolve transition and fills missing clip audio with silence', { skip: !available }, async () => {
  const dir = await mkdtemp(path.join(tmpdir(), 'motioniton-phase45-'));
  try {
    const a = path.join(dir, 'silent.mp4'), b = path.join(dir, 'with-audio.mp4'), output = path.join(dir, 'final.mp4');
    let result = spawnSync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=red:s=320x240:r=25:d=2', '-an', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', a]);
    assert.equal(result.status, 0, result.stderr?.toString());
    result = spawnSync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=blue:s=640x360:r=25:d=2', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=2', '-shortest', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', b]);
    assert.equal(result.status, 0, result.stderr?.toString());
    const command = buildFfmpegStitchCommand([{ path: a, durationSeconds: 2, hasAudio: false }, { path: b, durationSeconds: 2, transition: 'dissolve', hasAudio: true }], output, { width: 320, height: 240, fps: 25, transitionSeconds: .5 });
    result = spawnSync(command.command, command.args, { encoding: 'utf8' });
    assert.equal(result.status, 0, result.stderr);
    const probe = spawnSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', output], { encoding: 'utf8' });
    assert.equal(probe.status, 0, probe.stderr); assert.ok(Number(probe.stdout.trim()) > 3 && Number(probe.stdout.trim()) < 4);
  } finally { await rm(dir, { recursive: true, force: true }); }
});
test('backend FFmpeg builder uses real xfade and acrossfade filters', () => {
  const args = buildFfmpegStitchArgs([{ path: '/tmp/a.mp4', durationSeconds: 3 }, { path: '/tmp/b.mp4', durationSeconds: 4, transition: 'slide' }], '/tmp/out.mp4');
  const filter = args[args.indexOf('-filter_complex') + 1];
  assert.match(filter, /xfade=transition=slideleft/); assert.match(filter, /acrossfade=/);
});
