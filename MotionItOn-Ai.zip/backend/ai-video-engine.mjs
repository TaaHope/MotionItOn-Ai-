import { spawn } from 'node:child_process';
import path from 'node:path';

export function normalizeGenerateRequest(body = {}) {
  const prompt = typeof body.prompt === 'string' ? body.prompt.trim() : '';
  if (!prompt) throw new Error('Enter a video prompt.');
  if (prompt.length > 1000) throw new Error('The prompt must be 1,000 characters or fewer.');
  // Keep the public API model identifier stable while the server-side worker
  // chooses its installed checkpoint. Model implementation stays hidden in UI.
  const model = body.model === undefined ? 'motioniton-auto' : body.model;
  if (!['motioniton-auto', 'ltx-video-local'].includes(model)) throw new Error('Unsupported generation mode.');
  const ratio = body.ratio === undefined ? '1280:720' : body.ratio;
  if (!['1280:720', '720:1280'].includes(ratio)) throw new Error('Aspect ratio must be landscape 16:9 or portrait 9:16.');
  const duration = Number(body.duration ?? 3);
  if (!Number.isInteger(duration) || duration < 2 || duration > 300) throw new Error('Video duration must be between 2 seconds and 5 minutes.');
  const quality = body.quality === undefined ? 'high' : body.quality;
  if (!['standard', 'high'].includes(quality)) throw new Error('Quality must be standard or high.');
  const style = typeof body.style === 'string' ? body.style.trim().slice(0, 40) : 'general';
  const workerId = body.workerId === undefined ? undefined : String(body.workerId);
  if (workerId && !/^[a-zA-Z0-9_-]{3,80}$/.test(workerId)) throw new Error('Invalid AI worker selection.');
  const characters = body.characters === undefined ? [] : body.characters;
  if (!Array.isArray(characters) || characters.length > 8) throw new Error('Provide no more than eight character references.');
  const seen = new Set();
  for (const [index, character] of characters.entries()) {
    if (!character || typeof character !== 'object' || Array.isArray(character)) throw new Error(`Character reference ${index + 1} must be an object.`);
    const name = String(character.name || '').trim(), appearance = String(character.appearance || '').trim(), wardrobe = String(character.wardrobe || '').trim();
    if (!name || name.length > 80 || !appearance || appearance.length > 600 || wardrobe.length > 300) throw new Error(`Character reference ${index + 1} has missing or oversized fields.`);
    if (seen.has(name.toLowerCase())) throw new Error(`Duplicate character reference: ${name}.`); seen.add(name.toLowerCase());
  }
  return { prompt, model, ratio, duration, quality, style, ...(characters.length ? { characters } : {}), ...(workerId ? { workerId } : {}) };
}

/** Runs the self-hosted MotionItOn worker (Wan 2.2 by default). It never calls a commercial generation API. */
export function runLocalVideoGeneration({ prompt, ratio, duration, quality = 'high', style = 'general', model = 'motioniton-auto', workerId, characters = [], outputPath, onProgress = () => {}, timeoutMs = Number(process.env.MOTIONITON_VIDEO_TIMEOUT_MS || 6 * 60 * 60 * 1000) }) {
  const worker = process.env.MOTIONITON_VIDEO_WORKER || path.resolve('engine/generate_video.py');
  const python = process.env.PYTHON_BIN || 'python3';
  return new Promise((resolve, reject) => {
    const args = [worker, '--prompt', prompt, '--ratio', ratio, '--duration', String(duration), '--quality', quality, '--style', style, '--model', model, '--output', outputPath];
    if (workerId) args.push('--worker-id', workerId);
    if (characters.length) args.push('--character-bible', JSON.stringify(characters));
    const child = spawn(python, args, {
      stdio: ['ignore', 'pipe', 'pipe'], env: process.env,
    });
    let stdout = '', stderr = '', settled = false, timedOut = false;
    const timeout = Number.isFinite(timeoutMs) && timeoutMs > 0 ? setTimeout(() => {
      timedOut = true;
      child.kill('SIGTERM');
      const forceKill = setTimeout(() => child.kill('SIGKILL'), 5000);
      forceKill.unref?.();
    }, timeoutMs) : null;
    timeout?.unref?.();
    const cleanup = () => { if (timeout) clearTimeout(timeout); };
    const fail = error => { if (settled) return; settled = true; cleanup(); reject(error); };
    const consumeLine = line => {
      if (!line.trim()) return;
      try {
        const event = JSON.parse(line);
        if (event.type === 'progress') onProgress(Math.max(1, Math.min(99, Number(event.progress) || 1)), event.message ? String(event.message).slice(0, 300) : undefined);
        else if (event.type === 'error') stderr += `${event.message || 'The local video worker failed.'}\n`;
      } catch { /* Worker diagnostics that are not JSON are ignored. */ }
    };
    child.stdout.setEncoding('utf8');
    child.stdout.on('data', chunk => {
      stdout += chunk;
      const lines = stdout.split(/\r?\n/); stdout = lines.pop() || '';
      for (const line of lines) consumeLine(line);
    });
    child.stderr.setEncoding('utf8');
    child.stderr.on('data', chunk => { stderr = (stderr + chunk).slice(-12000); });
    child.on('error', error => fail(new Error(`Could not start the local AI engine (${python}): ${error.message}. Install engine/requirements.txt first.`)));
    child.on('close', code => {
      if (settled) return;
      cleanup();
      if (stdout.trim()) consumeLine(stdout);
      if (timedOut) { const limit = timeoutMs < 60000 ? `${Math.ceil(timeoutMs / 1000)}-second` : `${Math.ceil(timeoutMs / 60000)}-minute`; return fail(new Error(`AI video generation exceeded the ${limit} timeout and was stopped. Try a shorter clip or reduce MOTIONITON_VIDEO_STEPS.`)); }
      if (code !== 0) return fail(new Error((stderr || `Local video model exited with code ${code}.`).slice(-3000)));
      settled = true; resolve({ outputPath });
    });
  });
}
