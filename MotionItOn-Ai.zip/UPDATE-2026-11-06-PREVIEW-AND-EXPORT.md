# MotionItOn-Ai update — 6 November 2026

- Reduced all five category preview loops to four seconds, muted, 480px maximum width, 15 fps, H.264 baseline, with fast-start MP4 metadata.
- Kept the five category preview assets separate from generated project videos.
- Added a welcome/top-bar light/dark toggle. Light mode uses a soft green page palette and the choice is stored on the device.
- Changed the General settings navigation entry to open General settings instead of the video creation screen.
- Reworked Social Media Studio into a platform selector (YouTube, TikTok, Instagram, Facebook, X, Vimeo, WhatsApp, Telegram, or a custom platform), with video export, native share-sheet support where the device/browser supports it, and copyable post metadata.

## Important limitations

- Export and native share are functional client-side actions. Authenticated direct publishing and scheduled publishing still require each platform's approved OAuth/API integration on the backend.
- The existing preview source clips include TikTok watermarks on some categories. They have not been digitally erased. Replace those source clips with clean licensed footage before presenting the preview set as watermark-free. The current runtime environment could not download replacement stock footage.
- A full Next.js production build and Android build were not run because project dependencies are not installed in this environment.
