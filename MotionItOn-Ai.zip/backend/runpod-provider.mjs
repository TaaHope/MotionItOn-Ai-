/** RunPod REST control-plane adapter. Credentials stay server-side. */
export class RunPodProvider {
  constructor({ apiKey = process.env.RUNPOD_API_KEY, baseUrl = 'https://rest.runpod.io/v1', fetchImpl = fetch } = {}) {
    if (!apiKey || String(apiKey).length < 20) throw new Error('RUNPOD_API_KEY is missing or invalid.');
    this.apiKey = String(apiKey); this.baseUrl = baseUrl.replace(/\/+$/, ''); this.fetch = fetchImpl;
  }
  async request(path, options = {}) {
    const response = await this.fetch(`${this.baseUrl}${path}`, { ...options, headers: { Authorization: `Bearer ${this.apiKey}`, 'Content-Type': 'application/json', ...(options.headers || {}) } });
    const body = await response.text(); let data = null;
    try { data = body ? JSON.parse(body) : null; } catch { data = { message: body.slice(0, 500) }; }
    if (!response.ok) throw new Error(`RunPod request failed (${response.status}): ${String(data?.error || data?.message || 'Provider rejected request').slice(0, 500)}`);
    return data;
  }
  async createGpuPod({ name = 'motioniton-gpu-worker', templateId = process.env.RUNPOD_TEMPLATE_ID, gpuTypeId = process.env.RUNPOD_GPU_TYPE_ID, containerDiskGb = 50, volumeGb = 0, volumeMountPath = '/workspace', ports = ['8790/http'], env = {} } = {}) {
    if (!templateId || !gpuTypeId) throw new Error('RUNPOD_TEMPLATE_ID and RUNPOD_GPU_TYPE_ID are required before provisioning.');
    if (!Number.isInteger(containerDiskGb) || containerDiskGb < 10 || containerDiskGb > 500) throw new Error('Container disk must be between 10 and 500 GB.');
    if (!Number.isInteger(volumeGb) || volumeGb < 0 || volumeGb > 1000) throw new Error('Persistent volume size must be between 0 and 1000 GB.');
    if (!/^[-a-zA-Z0-9_]{3,60}$/.test(name)) throw new Error('Invalid GPU pod name.');
    if (typeof env.MOTIONITON_WORKER_TOKEN !== 'string' || env.MOTIONITON_WORKER_TOKEN.length < 32) throw new Error('Provide a private MOTIONITON_WORKER_TOKEN of at least 32 characters for the GPU worker.');
    if (Object.hasOwn(env, 'RUNPOD_API_KEY')) throw new Error('Never pass RUNPOD_API_KEY into the GPU pod environment.');
    const safeEnv = Object.fromEntries(Object.entries({ MOTIONITON_WORKER_PORT: '8790', ...env }).filter(([key, value]) => /^[A-Z][A-Z0-9_]{1,63}$/.test(key) && typeof value === 'string'));
    const payload = { name, templateId, gpuTypeIds: [gpuTypeId], cloudType: 'SECURE', containerDiskInGb: containerDiskGb, ports, env: safeEnv };
    if (volumeGb > 0) { payload.volumeInGb = volumeGb; payload.volumeMountPath = volumeMountPath; }
    return this.request('/pods', { method: 'POST', body: JSON.stringify(payload) });
  }
  workerProxyUrl(podId, port = 8790) {
    if (!/^[a-zA-Z0-9-]{5,100}$/.test(podId) || !Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Invalid pod ID or worker port.');
    return `https://${podId}-${port}.proxy.runpod.net`;
  }
  async waitForWorker(workerUrl, workerToken, { timeoutMs = 10 * 60 * 1000, pollMs = 5000, fetchImpl = this.fetch } = {}) {
    if (workerToken.length < 32) throw new Error('Worker token must contain at least 32 characters.');
    const deadline = Date.now() + timeoutMs; let lastError = 'Worker is starting.';
    while (Date.now() < deadline) {
      try {
        const response = await fetchImpl(`${workerUrl.replace(/\/+$/, '')}/health`, { headers: { Authorization: `Bearer ${workerToken}` }, signal: AbortSignal.timeout(5000) });
        if (response.ok) return response.json();
        lastError = `Worker health returned ${response.status}.`;
      } catch (error) { lastError = String(error?.message || error).slice(0, 250); }
      await new Promise(resolve => setTimeout(resolve, pollMs));
    }
    throw new Error(`GPU worker did not become healthy before timeout: ${lastError}`);
  }
  getPod(podId) { if (!/^[a-zA-Z0-9-]{5,100}$/.test(podId)) throw new Error('Invalid RunPod pod ID.'); return this.request(`/pods/${encodeURIComponent(podId)}`); }
  terminatePod(podId) { if (!/^[a-zA-Z0-9-]{5,100}$/.test(podId)) throw new Error('Invalid RunPod pod ID.'); return this.request(`/pods/${encodeURIComponent(podId)}`, { method: 'DELETE' }); }
}

/** A small idle timer; caller must invoke markBusy/markIdle from its queue lifecycle. */
export class GpuIdleShutdown {
  constructor(provider, { idleSeconds = 300, onShutdown = () => {} } = {}) {
    if (!Number.isInteger(idleSeconds) || idleSeconds < 60) throw new Error('GPU idle shutdown must be at least 60 seconds.');
    this.provider = provider; this.idleSeconds = idleSeconds; this.onShutdown = onShutdown; this.timer = null; this.podId = null; this.busy = false;
  }
  attach(podId) { this.podId = podId; }
  markBusy() { this.busy = true; if (this.timer) clearTimeout(this.timer); this.timer = null; }
  markIdle() {
    this.busy = false; if (!this.podId) return;
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(async () => {
      if (this.busy || !this.podId) return;
      const id = this.podId;
      try { await this.provider.terminatePod(id); this.podId = null; this.onShutdown(id); }
      catch (error) { this.onShutdown(id, error); }
    }, this.idleSeconds * 1000);
    this.timer.unref?.();
  }
  cancel() { if (this.timer) clearTimeout(this.timer); this.timer = null; }
}
