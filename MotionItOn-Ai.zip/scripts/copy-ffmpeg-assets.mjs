import { mkdir, copyFile } from 'node:fs/promises';
import path from 'node:path';
const root = process.cwd();
const source = path.join(root, 'node_modules', '@ffmpeg', 'core', 'dist', 'umd');
const destination = path.join(root, 'public', 'ffmpeg');
await mkdir(destination, { recursive: true });
for (const file of ['ffmpeg-core.js', 'ffmpeg-core.wasm']) {
  await copyFile(path.join(source, file), path.join(destination, file));
}
console.log('Copied single-thread FFmpeg WebAssembly runtime into public/ffmpeg.');
