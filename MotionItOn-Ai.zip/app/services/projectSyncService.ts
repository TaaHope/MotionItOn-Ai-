import { AccountService } from "./accountService";

export interface UnifiedProjectData {
  id: string;
  title: string;
  category: string;
  version: number;
  updatedAt: number | string;
  episodes: unknown[];
  characters: unknown[];
  productionNotes: string;
  scriptPlan: string;
  [key: string]: unknown;
}

const validId = (value: unknown): value is string =>
  typeof value === "string" && /^[a-zA-Z0-9_-]{1,100}$/.test(value);

const cacheKey = (id: string) => `proj_cache_${id}`;

export class ProjectSyncService {
  static getCachedProject<T extends UnifiedProjectData = UnifiedProjectData>(id: string): T | null {
    if (typeof window === "undefined" || !validId(id)) return null;
    try {
      const raw = localStorage.getItem(cacheKey(id));
      if (!raw) return null;
      const value: unknown = JSON.parse(raw);
      return this.validateImportedProject(value) ? value as T : null;
    } catch { return null; }
  }

  static getCachedProjects<T extends UnifiedProjectData = UnifiedProjectData>(): T[] {
    if (typeof window === "undefined") return [];
    const projects: T[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key?.startsWith("proj_cache_")) continue;
      const item = this.getCachedProject<T>(key.slice("proj_cache_".length));
      if (item) projects.push(item);
    }
    return projects.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }

  static async deleteProjectState(id: string): Promise<{ success: boolean; offline: boolean; error?: string }> {
    if (!validId(id)) return { success: false, offline: false, error: "Invalid project ID." };
    try { if (typeof window !== "undefined") localStorage.removeItem(cacheKey(id)); }
    catch { return { success: false, offline: true, error: "Could not remove the local project copy." }; }
    try {
      const cloudDeleted = await AccountService.deleteProject(id);
      return { success: true, offline: !cloudDeleted };
    } catch (error) {
      return { success: true, offline: true, error: error instanceof Error ? error.message : "Cloud deletion could not be confirmed." };
    }
  }

  static validateImportedProject(value: unknown): value is UnifiedProjectData {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const project = value as Record<string, unknown>;
    return validId(project.id) &&
      typeof project.title === "string" && !!project.title.trim() &&
      typeof project.category === "string" &&
      Array.isArray(project.episodes) && Array.isArray(project.characters) &&
      Number.isInteger(project.version) && Number(project.version) >= 0 &&
      typeof project.productionNotes === "string" &&
      typeof project.scriptPlan === "string";
  }

  static async saveProjectState(project: UnifiedProjectData): Promise<{ success: boolean; offline: boolean; error?: string }> {
    if (!this.validateImportedProject(project)) {
      return { success: false, offline: false, error: "Project data failed validation." };
    }
    const payload = { ...project, updatedAt: new Date().toISOString(), version: project.version + 1 };
    try {
      await AccountService.syncProjects([payload]);
      return { success: true, offline: false };
    } catch (error) {
      try {
        localStorage.setItem(cacheKey(project.id), JSON.stringify(payload));
        return { success: true, offline: true, error: error instanceof Error ? error.message : "Cloud unavailable; saved locally." };
      } catch {
        return { success: false, offline: true, error: "Cloud unavailable and local storage could not save the project." };
      }
    }
  }
}
