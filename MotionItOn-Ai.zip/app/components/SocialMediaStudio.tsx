"use client";

import { useEffect, useMemo, useState } from "react";
import { Upload, Download, Copy, CalendarDays, Share2, AlertCircle, Check, ChevronDown } from "lucide-react";

const PLATFORMS = ["YouTube", "TikTok", "Instagram", "Facebook", "X", "Vimeo", "WhatsApp", "Telegram", "Other"];

export function SocialMediaStudio() {
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [hashtags, setHashtags] = useState("");
  const [platform, setPlatform] = useState("YouTube");
  const [otherPlatform, setOtherPlatform] = useState("");
  const [notice, setNotice] = useState("");
  const [scheduledAt, setScheduledAt] = useState("");
  const sizeLabel = useMemo(() => file ? `${(file.size / 1024 / 1024).toFixed(1)} MB` : "No video selected", [file]);
  const platformName = platform === "Other" ? (otherPlatform.trim() || "your platform") : platform;

  useEffect(() => () => { if (previewUrl) URL.revokeObjectURL(previewUrl); }, [previewUrl]);
  function selectVideo(next: File | null) {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setFile(next); setPreviewUrl(next ? URL.createObjectURL(next) : "");
    if (next && !title) setTitle(next.name.replace(/\.[^.]+$/, ""));
  }
  async function copyText(value: string) {
    try { await navigator.clipboard.writeText(value); setNotice("Video details copied."); }
    catch { setNotice("Clipboard unavailable on this device."); }
  }
  function exportVideo() {
    if (!file) { setNotice("Select a finished video first."); return; }
    const safe = (title || file.name.replace(/\.[^.]+$/, "")).replace(/[^a-z0-9-_]+/gi, "-").slice(0, 80) || "motioniton-video";
    const url = URL.createObjectURL(file); const a = document.createElement("a"); a.href = url; a.download = `${safe}-${platformName.replace(/[^a-z0-9]+/gi,'-')}.${file.name.split('.').pop() || 'mp4'}`; document.body.appendChild(a); a.click(); a.remove(); window.setTimeout(() => URL.revokeObjectURL(url), 60000);
    setNotice(`Video exported for ${platformName}. Open that platform and select the exported file to post.`);
  }
  async function shareVideo() {
    if (!file) { setNotice("Select a finished video first."); return; }
    const shareData = { files: [file], title: title || file.name, text: [description, hashtags].filter(Boolean).join("\n") };
    try {
      if (navigator.canShare?.({ files: [file] }) && navigator.share) { await navigator.share(shareData); setNotice("Share sheet opened."); }
      else exportVideo();
    } catch (e) { if (e instanceof Error && e.name === "AbortError") return; setNotice("Direct sharing is not available here. Use Export video instead."); }
  }
  const metadata = `${title}\n\n${description}\n\n${hashtags}`.trim();
  return <section className="social-studio">
    <div className="social-hero"><div><span className="eyebrow">PUBLISHING</span><h1>Export video</h1><p>Choose where you want to send your finished video.</p></div><div className="social-hero-icon"><Share2 size={28}/></div></div>
    <div className="social-panel social-platform-select"><label htmlFor="export-platform">Platform</label><div className="social-select-wrap"><select id="export-platform" value={platform} onChange={e=>setPlatform(e.target.value)}>{PLATFORMS.map(name=><option key={name}>{name}</option>)}</select><ChevronDown size={18}/></div>{platform === "Other" && <input value={otherPlatform} onChange={e=>setOtherPlatform(e.target.value)} placeholder="Enter platform name" maxLength={50}/>}</div>
    <div className="social-work-grid">
      <div className="social-panel"><h2><Upload size={18}/> Finished video</h2><label className="social-file-drop"><input type="file" accept="video/mp4,video/quicktime,video/webm,.mov" onChange={e=>selectVideo(e.target.files?.[0]||null)}/><Upload size={25}/><strong>{file ? file.name : "Choose a finished video"}</strong><span>{sizeLabel} · MP4 recommended</span></label>{file && <video className="social-video-preview" controls playsInline src={previewUrl}/>}</div>
      <div className="social-panel"><h2>Post details</h2><label>Title<input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Video title" maxLength={100}/></label><label>Caption / description<textarea value={description} onChange={e=>setDescription(e.target.value)} placeholder="Write a caption" rows={4}/></label><label>Hashtags<input value={hashtags} onChange={e=>setHashtags(e.target.value)} placeholder="#Animation #Shorts"/></label><label className="social-schedule-label"><CalendarDays size={16}/> Planned date<input type="datetime-local" value={scheduledAt} onChange={e=>setScheduledAt(e.target.value)}/></label><button className="social-secondary-action" onClick={()=>void copyText(metadata)} disabled={!metadata.trim()}><Copy size={16}/> Copy post details</button><button className="social-primary-action" onClick={exportVideo} disabled={!file}><Download size={17}/> Export for {platformName}</button><button className="social-secondary-action" onClick={()=>void shareVideo()} disabled={!file}><Share2 size={16}/> Share to app</button></div>
    </div>
    {notice && <div className="social-status"><Check size={18}/><span>{notice}{scheduledAt ? ` Planned: ${new Date(scheduledAt).toLocaleString()}.` : ""}</span></div>}
  </section>;
}
