# MotionItOn account and project API

All endpoints use JSON except video uploads/downloads. Protected endpoints require `Authorization: Bearer <account-session-token>`.

## Public account endpoints
- `POST /api/auth/register` — `{ "email", "displayName", "password" }`; password must be 10+ characters with letters and numbers.
- `POST /api/auth/login` — `{ "email", "password" }`.
- `GET /api/auth/me` — returns the current account when the session is valid.
- `POST /api/auth/logout` — revokes the presented session.

## Authenticated account endpoints
- `PATCH /api/auth/profile` — `{ "displayName" }`.
- `POST /api/auth/change-password` — `{ "currentPassword", "newPassword" }`; revokes all existing sessions and returns a new session.

## Projects
- `GET /api/projects` — list the signed-in account's projects.
- `PUT /api/projects/:id` — save one `{ "project": { ... } }` record.
- `DELETE /api/projects/:id` — delete one owned project.
- `POST /api/projects/sync` — `{ "projects": [...] }`; synchronizes the signed-in account's full current project list.

## Rendering and AI jobs
- `/api/jobs*`, `/api/render` and `/api/ai/jobs*` require an account session.
- `POST /api/ai/generate` and `GET /api/ai/engine` additionally require `X-API-Key: <MOTIONITON_API_KEY>`.
- Account sessions and the engine API key are separate credentials. Never put the engine key in the Authorization header.
- Job listing, status and downloads are restricted to the account that created the job.

## Email and publishing
No email delivery or social platform publishing endpoint is claimed to be active in this build. Those require email-provider credentials or platform OAuth credentials and approval.


## AI worker profiles

- `GET /api/ai/workers` — engine-key protected; returns registered named worker profiles and implemented model options.
- `POST /api/ai/workers` — engine-key protected; creates a profile using `{ "name": "...", "modelId": "wan-2.2-ti2v-5b" }` by default; `ltx-legacy` remains an optional legacy adapter.
- `PATCH /api/ai/workers/:id` — engine-key protected; updates a profile name and/or enabled state.
- `DELETE /api/ai/workers/:id` — engine-key protected; deletes a non-default profile.
- `POST /api/ai/generate` accepts optional `workerId`; the selected enabled profile is resolved by the Python worker registry before model selection.

Worker profiles are stored in `MOTIONITON_WORKERS_FILE`. The default profile is protected. Only model adapters marked implemented in `engine/model_registry.py` can be assigned to runnable profiles. The default profile uses Wan 2.2 TI2V 5B; LTX legacy remains optional; multiple profiles do not imply parallel GPU execution.

## Remote GPU operations

- `GET /api/ai/remote-worker-health` — engine-key protected remote worker health check. Returns 503 if remote mode is not configured or the worker is unavailable.
- Production AI generation defaults to remote mode (`MOTIONITON_GENERATION_MODE=remote`). Jobs are dispatched only to the authenticated MotionItOn GPU worker. If the worker URL/token are missing or the worker is offline, jobs remain queued; there is no silent local CPU fallback. The completed MP4 is downloaded into the backend persistent data directory before the account download endpoint becomes available. Set `MOTIONITON_GENERATION_MODE=local` only for deliberate local development.
- `POST /api/ai/generate` additionally accepts optional `characters`: up to eight `{ name, appearance, wardrobe? }` text references. These are compiled into a scene continuity bible. They are not image-reference inputs.
- `POST /api/render` optionally accepts `transitions` as a JSON array with one value (`cut`, `fade`, `dissolve`, or `slide`) between each pair of uploaded clips, and `transitionSeconds` from 0.1 to 5. The backend adds a silent audio track to clips with no audio before applying video/audio transitions.
