// Accept either the Supabase project URL or a copied REST/Auth endpoint URL.
// Auth and REST requests below append their own API paths, so remove any
// accidentally included /rest/v1 or /auth/v1 suffix first.
const SUPABASE_URL = (process.env.NEXT_PUBLIC_SUPABASE_URL || "")
  .trim()
  .replace(/\/(?:rest\/v1|auth\/v1)\/?$/i, "")
  .replace(/\/+$/, "");
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "";

export type MotionItOnUser = {
  id: string;
  email?: string;
  user_metadata?: { display_name?: string; [key: string]: unknown };
};

type AuthSession = {
  access_token: string;
  refresh_token: string;
  user: MotionItOnUser;
};

const SESSION_KEY = "motioniton_session";
const REFRESH_KEY = "motioniton_refresh_token";
const USER_KEY = "motioniton_user";

export function isAccountServiceConfigured(): boolean {
  return Boolean(SUPABASE_URL && SUPABASE_ANON_KEY);
}

function requireConfig() {
  if (!isAccountServiceConfigured()) {
    throw new Error("Account service is currently unavailable. Please try again later.");
  }
}

type ApiObject = Record<string, unknown>;

async function readResponse(response: Response): Promise<unknown> {
  const raw = await response.text();
  let data: unknown = {};
  if (raw) {
    try { data = JSON.parse(raw); }
    catch {
      throw new Error(`Account service returned an unexpected response (${response.status}). Check the Supabase URL and project status.`);
    }
  }
  if (!response.ok) {
    const details = data && typeof data === "object" && !Array.isArray(data)
      ? data as ApiObject
      : {};
    const message = details.msg ?? details.message ?? details.error_description ?? details.error ?? details.details;
    throw new Error(typeof message === "string" ? message : `Account request failed (${response.status}).`);
  }
  return data;
}

function saveSession(session: AuthSession) {
  localStorage.setItem(SESSION_KEY, session.access_token);
  localStorage.setItem(REFRESH_KEY, session.refresh_token);
  localStorage.setItem(USER_KEY, JSON.stringify(session.user));
}

function clearSession() {
  localStorage.removeItem(SESSION_KEY);
  localStorage.removeItem(REFRESH_KEY);
  localStorage.removeItem(USER_KEY);
}

async function authRequest(path: string, body?: unknown, token?: string) {
  requireConfig();
  const response = await fetch(`${SUPABASE_URL}/auth/v1${path}`, {
    method: body === undefined ? "GET" : "POST",
    headers: {
      apikey: SUPABASE_ANON_KEY,
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {})
    },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    cache: "no-store"
  });
  return readResponse(response);
}

export const AccountService = {
  async register(email: string, password: string, displayName: string): Promise<
    | { authenticated: true; user: MotionItOnUser }
    | { authenticated: false; confirmationRequired: true }
  > {
    const configuredOrigin = (process.env.NEXT_PUBLIC_APP_URL || window.location.origin).trim();
    let callbackUrl: string;
    try {
      const callback = new URL(configuredOrigin);
      callback.pathname = "/";
      callback.search = "?verified=1";
      callback.hash = "";
      callbackUrl = callback.toString();
    } catch {
      throw new Error("The application verification URL is invalid. Check NEXT_PUBLIC_APP_URL.");
    }
    const redirect = encodeURIComponent(callbackUrl);
    const data = await authRequest(`/signup?redirect_to=${redirect}`, {
      email: email.trim().toLowerCase(),
      password,
      data: { display_name: displayName.trim() }
    }) as ApiObject;
    if (data.access_token && data.refresh_token && data.user) {
      saveSession(data as AuthSession);
      return { authenticated: true, user: data.user as MotionItOnUser };
    }
    return { authenticated: false, confirmationRequired: true };
  },

  async completeEmailVerification(): Promise<MotionItOnUser | null> {
    if (typeof window === "undefined" || !window.location.hash) return null;
    const params = new URLSearchParams(window.location.hash.slice(1));
    const accessToken = params.get("access_token");
    const refreshToken = params.get("refresh_token");
    const authError = params.get("error_description") || params.get("error");
    if (authError) {
      window.history.replaceState({}, document.title, window.location.pathname + window.location.search);
      throw new Error("Email verification could not be completed. Please request a new verification email.");
    }
    if (!accessToken || !refreshToken) return null;

    window.history.replaceState({}, document.title, window.location.pathname + window.location.search);
    const response = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
      headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${accessToken}` },
      cache: "no-store"
    });
    const user = await readResponse(response) as MotionItOnUser;
    saveSession({ access_token: accessToken, refresh_token: refreshToken, user });
    return user;
  },

  async requestPasswordReset(email: string) {
    const cleanEmail = email.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) throw new Error("Enter a valid email address.");
    const origin = (process.env.NEXT_PUBLIC_APP_URL || window.location.origin).trim();
    const callback = new URL(origin);
    callback.pathname = "/";
    callback.search = "?password-recovery=1";
    callback.hash = "";
    await authRequest(`/recover?redirect_to=${encodeURIComponent(callback.toString())}`, { email: cleanEmail });
  },

  async login(email: string, password: string) {
    const data = await authRequest("/token?grant_type=password", {
      email: email.trim().toLowerCase(),
      password
    }) as ApiObject;
    if (!data.access_token || !data.refresh_token || !data.user) {
      throw new Error("The account service did not return a valid login session.");
    }
    saveSession(data as AuthSession);
    return data.user as MotionItOnUser;
  },

  async refresh() {
    requireConfig();
    const refreshToken = localStorage.getItem(REFRESH_KEY);
    if (!refreshToken) {
      clearSession();
      return null;
    }
    try {
      const data = await authRequest("/token?grant_type=refresh_token", { refresh_token: refreshToken }) as ApiObject;
      if (!data.access_token || !data.refresh_token || !data.user) throw new Error("Session refresh failed.");
      saveSession(data as AuthSession);
      return data.user as MotionItOnUser;
    } catch {
      clearSession();
      return null;
    }
  },

  async currentUser() {
    requireConfig();
    let token = localStorage.getItem(SESSION_KEY) || "";
    if (!token) return null;
    let response = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
      headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${token}` },
      cache: "no-store"
    });
    if (response.status === 401) {
      const refreshed = await this.refresh();
      if (!refreshed) return null;
      token = localStorage.getItem(SESSION_KEY) || "";
      response = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
        headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${token}` },
        cache: "no-store"
      });
    }
    const user = await readResponse(response) as MotionItOnUser;
    localStorage.setItem(USER_KEY, JSON.stringify(user));
    return user;
  },

  validatePassword(password: string) {
    if (password.length < 10) throw new Error("Password must be at least 10 characters long.");
    if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) {
      throw new Error("Password must include both letters and numbers.");
    }
  },

  async changePassword(currentPassword: string, newPassword: string) {
    this.validatePassword(newPassword);
    if (!currentPassword) throw new Error("Enter your current password to continue.");
    const current = await this.currentUser();
    if (!current?.email) throw new Error("Your signed-in account email could not be verified.");
    // Re-authenticate before changing credentials. Supabase rotates the session
    // on successful login, then the authenticated user endpoint updates password.
    await this.login(current.email, currentPassword);
    return this.updateUser({ password: newPassword });
  },

  async updateUser(attributes: { data?: Record<string, unknown>; password?: string; email?: string }) {
    const token = localStorage.getItem(SESSION_KEY) || "";
    if (!token) throw new Error("Sign in to update your account.");
    const response = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
      method: "PUT",
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(attributes)
    });
    const user = await readResponse(response) as MotionItOnUser;
    localStorage.setItem(USER_KEY, JSON.stringify(user));
    return user;
  },

  async logout() {
    const token = localStorage.getItem(SESSION_KEY) || "";
    try {
      if (token && isAccountServiceConfigured()) {
        await fetch(`${SUPABASE_URL}/auth/v1/logout`, {
          method: "POST",
          headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${token}` }
        });
      }
    } finally {
      clearSession();
    }
  },

  async listProjects<T>() {
    const token = localStorage.getItem(SESSION_KEY) || "";
    if (!token) throw new Error("Sign in to synchronize projects.");
    const response = await fetch(`${SUPABASE_URL}/rest/v1/user_projects?select=id,payload,updated_at&order=updated_at.desc`, {
      headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${token}` },
      cache: "no-store"
    });
    const rows = await readResponse(response);
    return (Array.isArray(rows) ? rows as Array<{ payload: T }> : []).map(row => row.payload);
  },

  async deleteProject(projectId: string): Promise<boolean> {
    if (!/^[a-zA-Z0-9_-]{1,100}$/.test(projectId)) throw new Error("Invalid project ID.");
    const token = localStorage.getItem(SESSION_KEY) || "";
    if (!token) return false;
    const response = await fetch(`${SUPABASE_URL}/rest/v1/user_projects?id=eq.${encodeURIComponent(projectId)}`, {
      method: "DELETE",
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${token}`,
        Prefer: "return=minimal"
      },
      cache: "no-store"
    });
    await readResponse(response);
    return true;
  },

  async syncProjects<T extends { id: string }>(projects: T[]) {
    const token = localStorage.getItem(SESSION_KEY) || "";
    if (!token) throw new Error("Sign in to synchronize projects.");
    const user = JSON.parse(localStorage.getItem(USER_KEY) || "{}") as { id?: string };
    if (!user.id) throw new Error("Signed-in account details are missing.");
    const records = projects.map(project => ({
      id: project.id,
      user_id: user.id,
      payload: project,
      updated_at: new Date().toISOString()
    }));
    if (!records.length) return;
    const response = await fetch(`${SUPABASE_URL}/rest/v1/user_projects?on_conflict=user_id,id`, {
      method: "POST",
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        Prefer: "resolution=merge-duplicates,return=minimal"
      },
      body: JSON.stringify(records)
    });
    await readResponse(response);
  }
};
