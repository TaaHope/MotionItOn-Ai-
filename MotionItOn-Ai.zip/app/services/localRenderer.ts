import { FFmpeg } from '@ffmpeg/ffmpeg';
import { fetchFile, toBlobURL } from '@ffmpeg/util';

type LocalClip = { id: string; name: string; url: string; duration: number; start: number; end: number; mediaKind?: 'video' | 'image' };
type RenderOptions = {
  clips: LocalClip[];
  audioTrack?: { url: string; name: string; start: number; end: number; volume?: number; delay?: number };
  audioTracks?: Array<{ url: string; name: string; start: number; end: number; volume?: number; delay?: number }>;
  transition?: 'Cut' | 'Crossfade' | 'Fade';
  titleOverlays?: Array<{ text: string; start: number; end: number; fontSize: number; color: string; position: 'top' | 'center' | 'bottom' }>; 
  resolution: string;
  orientation: string;
  fps: string;
  audioMode: string;
  onProgress?: (progress: number) => void;
  onStatus?: (message: string) => void;
};

let ffmpegInstance: FFmpeg | null = null;
let loadPromise: Promise<FFmpeg> | null = null;

async function getFFmpeg(onProgress?: (progress: number) => void, onStatus?: (message: string) => void) {
  if (ffmpegInstance) return ffmpegInstance;
  if (loadPromise) return loadPromise;
  loadPromise = (async () => {
    const instance = new FFmpeg();
    instance.on('progress', ({ progress }) => onProgress?.(Math.max(0, Math.min(99, Math.round(progress * 100)))));
    instance.on('log', ({ message }) => {
      if (/error|failed/i.test(message)) onStatus?.(`FFmpeg: ${message.slice(0, 180)}`);
    });
    onStatus?.('Preparing video tools…');
    const base = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd';
    const coreURL = await toBlobURL(`${base}/ffmpeg-core.js`, 'text/javascript');
    const wasmURL = await toBlobURL(`${base}/ffmpeg-core.wasm`, 'application/wasm');
    await instance.load({ coreURL, wasmURL });
    ffmpegInstance = instance;
    return instance;
  })();
  try { return await loadPromise; } catch (error) { loadPromise = null; throw error; }
}

function readVideoMetadata(url: string): Promise<{ width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.muted = true;
    video.onloadedmetadata = () => {
      const width = video.videoWidth;
      const height = video.videoHeight;
      const duration = video.duration;
      video.removeAttribute('src');
      video.load();
      if (!width || !height || !Number.isFinite(duration)) reject(new Error('Could not read the source video metadata.'));
      else resolve({ width, height });
    };
    video.onerror = () => reject(new Error('Could not inspect the source video. Try another video format.'));
    video.src = url;
  });
}

function readImageMetadata(url: string): Promise<{ width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve({ width: image.naturalWidth, height: image.naturalHeight });
    image.onerror = () => reject(new Error('Could not inspect the selected picture. Try another image format.'));
    image.src = url;
  });
}

function dimensions(resolution: string, orientation: string, source: { width: number; height: number }) {
  let w: number;
  let h: number;
  if (resolution === 'Match source') {
    w = source.width;
    h = source.height;
  } else {
    const longEdge = resolution === '720p' ? 1280 : resolution === '1440p' ? 2560 : resolution === '4K' ? 3840 : 1920;
    const sourceIsPortrait = source.height > source.width;
    w = sourceIsPortrait ? Math.round(longEdge * source.width / source.height) : longEdge;
    h = sourceIsPortrait ? longEdge : Math.round(longEdge * source.height / source.width);
  }
  const longEdge = Math.max(w, h);
  if (orientation === 'Vertical 9:16') {
    w = Math.round(longEdge * 9 / 16); h = longEdge;
  } else if (orientation === 'Landscape 16:9') {
    w = longEdge; h = Math.round(longEdge * 9 / 16);
  } else if (orientation === 'Square 1:1') {
    w = longEdge; h = longEdge;
  } else if (orientation === 'Portrait 4:5') {
    w = Math.round(longEdge * 4 / 5); h = longEdge;
  }
  // H.264 yuv420p requires even dimensions.
  w = Math.max(2, w - (w % 2));
  h = Math.max(2, h - (h % 2));
  return `${w}:${h}`;
}

export async function renderVideoLocally(options: RenderOptions): Promise<Blob> {
  const { clips, resolution, orientation, fps, audioMode, audioTrack, audioTracks = audioTrack ? [audioTrack] : [], transition = 'Cut', titleOverlays = [], onProgress, onStatus } = options;
  if (!clips.length) throw new Error('Import at least one picture or video clip.');
  if (typeof window === 'undefined') throw new Error('Local video rendering must run in a browser.');
  const firstMetadata = clips[0].mediaKind === 'image'
    ? await readImageMetadata(clips[0].url)
    : await readVideoMetadata(clips[0].url);
  const ffmpeg = await getFFmpeg(onProgress, onStatus);
  const target = dimensions(resolution, orientation, firstMetadata);
  const parsedFps = Number.parseInt(fps, 10);
  const fpsValue = String(Number.isFinite(parsedFps) && parsedFps >= 1 && parsedFps <= 60 ? parsedFps : 30);
  const names: string[] = [];
  const safe = (s: string) => s.replace(/[^a-zA-Z0-9._-]/g, '_').slice(-60) || 'clip.mp4';
  try {
    for (let i = 0; i < clips.length; i++) {
      const clip = clips[i];
      const input = `input_${i}_${safe(clip.name)}`;
      const output = `segment_${i}.mp4`;
      const start = Math.max(0, clip.start || 0);
      const end = clip.end > start ? Math.min(clip.end, clip.duration || clip.end) : clip.duration;
      if (!Number.isFinite(end) || end <= start) throw new Error(`Invalid duration or trim range for ${clip.name}.`);
      onStatus?.(`Preparing ${clip.mediaKind === 'image' ? 'picture' : 'video'} ${i + 1} of ${clips.length}…`);
      await ffmpeg.writeFile(input, await fetchFile(clip.url));
      const filter = `scale=${target}:force_original_aspect_ratio=decrease,pad=${target}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=${fpsValue}`;
      const args = clip.mediaKind === 'image'
        ? ['-loop', '1', '-framerate', fpsValue, '-t', String(end - start), '-i', input, '-vf', filter, '-an', '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p']
        : ['-ss', String(start), '-i', input, '-t', String(end - start), '-vf', filter, '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p'];
      // Keep original audio for a single clip; multi-clip concat is normalized to silent segments for reliable compatibility.
      if (clip.mediaKind === 'image' || clips.length > 1 || audioMode === 'Mute original audio') args.push('-an');
      else args.push('-c:a', 'aac', '-b:a', '128k');
      args.push('-movflags', '+faststart', output);
      await ffmpeg.exec(args);
      await ffmpeg.deleteFile(input);
      names.push(output);
      onProgress?.(Math.round(((i + 1) / clips.length) * (clips.length === 1 ? 95 : 80)));
    }
    let finalName = names[0];
    if (names.length > 1) {
      onStatus?.(transition === 'Cut' ? 'Joining clips…' : `Applying ${transition.toLowerCase()} transitions…`);
      if (transition === 'Cut') {
        const concatText = names.map(name => `file '${name}'`).join('\n');
        await ffmpeg.writeFile('concat.txt', new TextEncoder().encode(concatText));
        await ffmpeg.exec(['-f', 'concat', '-safe', '0', '-i', 'concat.txt', '-c', 'copy', '-movflags', '+faststart', 'motioniton-output.mp4']);
        await ffmpeg.deleteFile('concat.txt');
      } else {
        const inputs = names.flatMap(name => ['-i', name]);
        const overlap = 0.6;
        let graph = names.map((_, i) => `[${i}:v]settb=AVTB,fps=${fpsValue},format=yuv420p[v${i}]`).join(';');
        let last = 'v0';
        let elapsed = Math.max(0.1, clips[0].end - clips[0].start);
        for (let i = 1; i < names.length; i++) {
          const label = `vx${i}`;
          const duration = Math.max(0.1, clips[i].end - clips[i].start);
          const d = transition === 'Fade' ? 0.35 : overlap;
          graph += `;[${last}][v${i}]xfade=transition=${transition === 'Fade' ? 'fade' : 'fade'}:duration=${d}:offset=${Math.max(0, elapsed-d)}[${label}]`;
          last = label;
          elapsed += duration-d;
        }
        await ffmpeg.exec([...inputs, '-filter_complex', graph, '-map', `[${last}]`, '-an', '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', 'motioniton-output.mp4']);
      }
      finalName = 'motioniton-output.mp4';
    }
    const videoDuration = clips.reduce((sum, clip) => sum + Math.max(0, (clip.end > clip.start ? clip.end : clip.duration) - clip.start), 0) - (transition === 'Cut' ? 0 : Math.max(0, clips.length - 1) * (transition === 'Fade' ? 0.35 : 0.6));
    // Burn title cards as transparent PNG overlays generated by the browser canvas.
    if (titleOverlays.length) {
      onStatus?.('Adding titles and captions…');
      const meta = firstMetadata;
      const overlayInputs: string[] = [];
      for (let i=0;i<titleOverlays.length;i++) {
        const item=titleOverlays[i]; const canvas=document.createElement('canvas'); canvas.width=meta.width; canvas.height=meta.height;
        const ctx=canvas.getContext('2d'); if(!ctx) continue;
        ctx.font=`700 ${Math.max(18,Math.min(160,item.fontSize))}px Arial`; ctx.textAlign='center'; ctx.textBaseline='middle';
        const y=item.position==='top'?meta.height*.13:item.position==='bottom'?meta.height*.87:meta.height*.5;
        ctx.lineWidth=Math.max(3,item.fontSize/12); ctx.strokeStyle='rgba(0,0,0,.8)'; ctx.fillStyle=item.color||'#ffffff';
        ctx.strokeText(item.text,meta.width/2,y,meta.width*.88); ctx.fillText(item.text,meta.width/2,y,meta.width*.88);
        const png=await new Promise<Uint8Array>(resolve=>canvas.toBlob(async b=>resolve(new Uint8Array(await b!.arrayBuffer())),'image/png'));
        const filename=`title_${i}.png`; await ffmpeg.writeFile(filename,png); overlayInputs.push(filename);
      }
      if(overlayInputs.length){
        const inputs=overlayInputs.flatMap(f=>['-loop','1','-i',f]);
        let graph='[0:v]null[v0]'; let last='v0';
        titleOverlays.forEach((item,i)=>{const next=`vt${i}`;const y=item.position==='top'?'h*0.08':item.position==='bottom'?'h-th-h*0.08':'(H-h)/2';graph+=`;[${last}][${i+1}:v]overlay=(W-w)/2:${y}:enable='between(t,${Math.max(0,item.start)},${Math.max(item.start+.1,item.end)})'[${next}]`;last=next;});
        await ffmpeg.exec(['-i',finalName,...inputs,'-filter_complex',graph,'-map',`[${last}]`,'-map','0:a?','-c:v','libx264','-preset','ultrafast','-c:a','copy','-shortest','motioniton-titled.mp4']);
        finalName='motioniton-titled.mp4';
      }
    }
    if (audioTracks.length) {
      onStatus?.(`Mixing ${audioTracks.length} audio track(s)…`);
      const args=['-i',finalName]; const filters:string[]=[]; const labels:string[]=[];
      for(let i=0;i<audioTracks.length;i++){
        const track=audioTracks[i]; const start=Math.max(0,Number(track.start)||0); const end=Number(track.end);
        if(!Number.isFinite(end)||end<=start) throw new Error(`Choose a valid trim range for audio track ${track.name}.`);
        const filename=`audio_${i}_${safe(track.name)}`; await ffmpeg.writeFile(filename,await fetchFile(track.url)); args.push('-ss',String(start),'-t',String(end-start),'-i',filename);
        const inputIndex=i+1; const label=`a${i}`; const delay=Math.max(0,Math.round(Number(track.delay||0)*1000));
        filters.push(`[${inputIndex}:a]volume=${Math.max(0,Math.min(2,Number(track.volume??1)))},adelay=${delay}|${delay},apad[${label}]`); labels.push(`[${label}]`);
      }
      filters.push(`${labels.join('')}amix=inputs=${labels.length}:duration=longest:dropout_transition=2[aout]`);
      args.push('-filter_complex',filters.join(';'),'-map','0:v:0','-map','[aout]','-c:v','copy','-c:a','aac','-b:a','192k','-ar','48000','-t',Math.max(.1,videoDuration).toFixed(3),'-movflags','+faststart','motioniton-audio-mix.mp4');
      await ffmpeg.exec(args); finalName='motioniton-audio-mix.mp4';
    }
    onStatus?.('Preparing MP4 download…');
    const data = await ffmpeg.readFile(finalName);
    const bytes = data instanceof Uint8Array ? data : new TextEncoder().encode(data as string);
    const outputBytes = new Uint8Array(bytes.byteLength);
    outputBytes.set(bytes);
    onProgress?.(100);
    return new Blob([outputBytes.buffer], { type: 'video/mp4' });
  } finally {
    for (const clip of clips) {
      // Inputs are deleted after processing; object URLs belong to the editor and are not revoked here.
      void clip;
    }
    for (const name of names) { try { await ffmpeg.deleteFile(name); } catch {} }
    try { await ffmpeg.deleteFile('motioniton-output.mp4'); } catch {}
    try { await ffmpeg.deleteFile('motioniton-audio-mix.mp4'); } catch {}
    try { await ffmpeg.deleteFile('motioniton-titled.mp4'); } catch {}
    for(let i=0;i<titleOverlays.length;i++){try{await ffmpeg.deleteFile(`title_${i}.png`)}catch{}}
  }
}
