# MotionItOn-Ai — RunPod GPU worker deployment

## Intended architecture

MotionItOn-Ai is the application the user operates. Its backend owns authentication, the generation queue, job status, project records and permanent MP4 files. RunPod supplies GPU compute only. The GPU worker receives a generation request, creates an MP4 in its temporary `/workspace/jobs` area, and streams the finished MP4 back to the MotionItOn backend. The backend stores the MP4 under its persistent `MOTIONITON_DATA_DIR/renders` directory and serves it through the authenticated `/api/ai/jobs/:id/download` endpoint.

The user does not open RunPod to retrieve or view videos. The RunPod pod can be stopped after generation; completed videos remain on the backend's persistent data volume. A persistent volume on the GPU pod is useful for model cache, but it is NOT the permanent video library.

No Supabase Storage account, bucket, service-role key or Supabase dashboard setup is required for generated video retention. Existing account authentication settings may remain as already configured; they are separate from the GPU/video-storage connection.

## 1. Build the MotionItOn GPU worker image

The standard RunPod PyTorch template by itself is not the MotionItOn worker. The supplied `Dockerfile.gpu-worker` must be built into a container image and pushed to a container registry accessible to RunPod. From the project root, use a registry you control (for example GHCR or Docker Hub):

```bash
docker build -f Dockerfile.gpu-worker -t YOUR_REGISTRY/motioniton-gpu-worker:wan22 .
docker push YOUR_REGISTRY/motioniton-gpu-worker:wan22
```

Do not put RunPod API keys or worker tokens into the image. Supply the worker token as a pod environment secret at deployment time.

## 2. Deploy the pod in RunPod

Use the custom image above, not the generic PyTorch image. Configure:

- GPU: RTX 3090 (24 GB VRAM)
- Container disk: 50 GB
- Persistent volume: 50 GB mounted at `/workspace`
- Exposed HTTP port: `8790`
- Environment: `MOTIONITON_WORKER_TOKEN` = a random secret of at least 32 characters
- Environment: `MOTIONITON_WORKER_PORT=8790`
- Environment: `MOTIONITON_REMOTE_DATA=/workspace/jobs`
- Environment: `HF_HOME=/workspace/.cache/huggingface`
- Environment: `MOTIONITON_WAN_CPU_OFFLOAD=true`
- Environment: `MOTIONITON_SELECTED_MODEL=wan-2.2-ti2v-5b`

The same worker token must be configured on the MotionItOn backend. Do not put the RunPod API key inside the GPU pod.

## 3. Connect RunPod to the MotionItOn backend

After the pod starts, copy its HTTPS proxy URL for port 8790. It follows this pattern:

```text
https://POD_ID-8790.proxy.runpod.net
```

Set these server-side backend environment variables:

```dotenv
MOTIONITON_GENERATION_MODE=remote
MOTIONITON_REMOTE_WORKER_URL=https://POD_ID-8790.proxy.runpod.net
MOTIONITON_WORKER_TOKEN=THE_SAME_RANDOM_SECRET_AS_THE_POD
MOTIONITON_REMOTE_TIMEOUT_MS=21600000
MOTIONITON_REMOTE_POLL_MS=2000
```

Restart the backend after saving the values. From MotionItOn-Ai, save the backend service URL and engine access key in Settings. The app uses the signed-in user's session for generation and project access; the RunPod worker token stays exclusively between the backend and GPU worker.

Verify the worker from the backend using the authenticated `GET /api/ai/remote-worker-health` endpoint with the engine API key in `X-API-Key`. The backend calls the worker health endpoint using the shared bearer worker token. Check `/api/health` for `remoteWorkerConfigured: true`, `backendPersistentStorage: true` and `generationMode: remote`. The worker health response also reports detected GPU name and VRAM.

## 4. What happens when Generate is clicked

1. MotionItOn-Ai sends the prompt, selected category and generation settings to its backend.
2. The backend writes a queued job to its SQLite database.
3. The backend submits the job to the authenticated RunPod worker and polls progress in the background.
4. Wan 2.2 TI2V-5B generates the MP4 on the GPU pod.
5. The backend downloads the MP4 into its own persistent `/data/renders` directory.
6. The backend records the completed project and exposes its authenticated download URL.
7. MotionItOn-Ai displays the finished video under My Projects.

If the worker is temporarily unavailable, the backend keeps the job queued and retries the connection. It does not silently fall back to CPU generation.

## 5. Permanent backend storage is mandatory

The backend must be deployed with a persistent disk/volume mounted at `/data`. The included `compose.backend.yml` creates a named Docker volume called `motioniton_backend_data`. For another hosting platform, attach a persistent disk at `/data`. Both the SQLite database and generated MP4 files are stored beneath this directory. This is MotionItOn storage; it is independent of the RunPod `/workspace` model-cache volume and does not require Supabase Storage. Do not use an ephemeral container filesystem for production. Back up this volume regularly.

## 6. Cost and shutdown

The worker pod is compute-only. The backend does not require the GPU to remain online to serve already completed MP4 files. Stop the RunPod pod when generation work is finished to stop GPU charges. The RunPod `/workspace` model cache volume may be retained for later sessions and can have a separate storage charge.

Automatic pod creation/termination through the RunPod API is optional and is not enabled by this fixed-URL worker connection. The current workflow uses a deployed pod URL and token. Do not assume automatic scale-to-zero unless that feature is separately implemented and tested.

## 7. Acceptance test before longer videos

- Backend health reports remote mode and a configured worker.
- Authenticated remote-worker health check succeeds.
- Submit one 2–5 second test prompt from MotionItOn-Ai.
- Job progresses from queued to running to completed in MotionItOn-Ai.
- The worker returns a valid MP4 and backend stores it under `/data/renders`.
- The video appears in My Projects and plays from the MotionItOn backend URL.
- Stop the GPU pod and verify the same video still plays.

Do not claim production readiness until this end-to-end test has passed on the actual RTX 3090.
