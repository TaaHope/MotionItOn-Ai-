'use client';
import { ArrowRight, Sparkles } from 'lucide-react';
export function ProductionPlanActionBanner({ planPrompt, onProceedToVideo }: { planPrompt: string; onProceedToVideo: (promptText: string) => void }) {
  return <div className="production-plan-banner"><div><b><Sparkles size={15}/> Production plan ready</b><p>Send this script to the video creator.</p></div><button type="button" className="primary-button" disabled={!planPrompt.trim()} onClick={() => onProceedToVideo(planPrompt)}>{'Continue to Video Generation'} <ArrowRight size={15}/></button></div>;
}
