# MotionItOn-Ai engine upgrade notes — 2026-11-05

## Included in this archive
- Added server-side `high` and `standard` quality profiles. High is the default.
- High profile targets 768x432 landscape / 432x768 portrait, 24 fps and 30 inference steps.
- Standard profile targets the same working dimensions, 16 fps and 22 inference steps.
- Added configurable FPS, inference steps, H.264 preset and CRF through server environment variables.
- Preserved `/api/ai/generate`, `/api/ai/jobs`, `/api/ai/engine` and legacy `ltx-video-local` request compatibility.
- Added `motioniton-auto` as the default UI-neutral model identifier; model implementation stays server-side.
- Added validation for generation mode and quality profile.

## Important engine status
Wan 2.2 TI2V-5B is the configured default model and its Diffusers adapter is included. The default worker and automatic model selection now target Wan 2.2. LTX legacy remains available only when explicitly selected. The Wan adapter has not yet passed a real GPU model-load and MP4-generation smoke test, so production inference is not yet verified.

Higher frame rate and inference-step counts increase render time and VRAM use. 768x432 is a moderate working resolution, not native 720p/1080p. A real RTX 3090 benchmark is required before increasing resolution or enabling more memory-intensive checkpoints.

## RunPod and storage
- Keep the existing 50 GB container disk initially; no paid volume is required for the first controlled smoke test.
- Do not retain finished user videos on the GPU. Transfer completed MP4s to application object storage before cleaning temporary files.
- Model weights cached only on container disk may need downloading again after pod replacement. This is a time/bandwidth trade-off.
- A real RunPod control-plane provisioner, authenticated worker HTTP service, automatic pod lifecycle management and cloud-object-storage transfer are not implemented in this archive. Deployment docs describe required work, not live functionality.

## Verification
- Backend syntax checks: PASS.
- Engine unit tests: PASS (7 tests).
- Python syntax compilation: PASS.
- Real GPU generation: NOT RUN (no RunPod GPU session/credentials).
- Next.js and Android/Windows builds: NOT RUN (dependencies/build environment not installed here).


## Wan 2.2 default model update (2026-11-12)
- Wan 2.2 TI2V-5B is now the default model for every automatic generation style and the default AI worker profile.
- Automatic selection does not silently fall back to LTX when the GPU is below Wan's VRAM requirement.
- LTX legacy remains available only when explicitly selected.
- Wan scenes are split into maximum five-second chunks to match the adapter's validated request limit.
- The Wan adapter still requires a real CUDA worker smoke test before production generation can be declared operational.
