const STYLES = new Set(['realistic','cinematic','cartoons','cooking','nature','documentary','drama','general']);
const TRANSITIONS = new Set(['cut','fade','dissolve','slide']);

export function validateProductionScript(body = {}) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw new Error('A production script object is required.');
  const title = String(body.title || '').trim();
  if (!title || title.length > 120) throw new Error('title must contain 1–120 characters.');
  const style = String(body.style || 'realistic').trim().toLowerCase();
  if (!STYLES.has(style)) throw new Error(`Unsupported style. Choose: ${[...STYLES].join(', ')}.`);
  const ratio = body.ratio || '1280:720';
  if (!['1280:720', '720:1280'].includes(ratio)) throw new Error('ratio must be 1280:720 or 720:1280.');
  const quality = body.quality || 'high';
  if (!['standard', 'high'].includes(quality)) throw new Error('quality must be standard or high.');
  const scenes = body.scenes;
  if (!Array.isArray(scenes) || scenes.length < 1 || scenes.length > 20) throw new Error('Provide 1–20 scenes per production script.');
  let totalDuration = 0;
  const cleanScenes = scenes.map((scene, index) => {
    if (!scene || typeof scene !== 'object' || Array.isArray(scene)) throw new Error(`Scene ${index + 1} must be an object.`);
    const prompt = String(scene.prompt || '').trim();
    const duration = Number(scene.durationSeconds ?? scene.duration ?? 5);
    if (!prompt || prompt.length > 1000) throw new Error(`Scene ${index + 1} prompt must contain 1–1,000 characters.`);
    if (!Number.isInteger(duration) || duration < 2 || duration > 20) throw new Error(`Scene ${index + 1} duration must be 2–20 seconds.`);
    const transition = String(scene.transition || 'cut').toLowerCase();
    if (!TRANSITIONS.has(transition)) throw new Error(`Scene ${index + 1} has an unsupported transition.`);
    totalDuration += duration;
    return { title: String(scene.title || `Scene ${index + 1}`).trim().slice(0, 100), prompt, durationSeconds: duration, transition };
  });
  if (totalDuration > 300) throw new Error('A production script cannot exceed 300 seconds total.');
  const characters = body.characters ?? [];
  if (!Array.isArray(characters) || characters.length > 8) throw new Error('Provide no more than eight character references.');
  const cleanCharacters = characters.map((c, i) => {
    if (!c || typeof c !== 'object') throw new Error(`Character ${i + 1} must be an object.`);
    const name = String(c.name || '').trim(), appearance = String(c.appearance || '').trim(), wardrobe = String(c.wardrobe || '').trim();
    if (!name || name.length > 80 || !appearance || appearance.length > 600 || wardrobe.length > 300) throw new Error(`Character ${i + 1} needs a name and appearance within the field limits.`);
    return { name, appearance, wardrobe };
  });
  return { title, style, ratio, quality, scenes: cleanScenes, characters: cleanCharacters, totalDuration };
}

export function compileProductionPrompt(script, scene, index) {
  const continuity = script.characters.map(c => `${c.name}: ${c.appearance}${c.wardrobe ? ` Wardrobe: ${c.wardrobe}` : ''}`).join('\n');
  const styleGuide = {
    realistic: 'Photorealistic live-action footage, natural human anatomy, authentic skin texture, believable motion and natural lighting.',
    cinematic: 'High-end cinematic live-action, intentional camera movement, expressive lighting, coherent composition and filmic colour.',
    cartoons: 'Polished original 3D animated cartoon, expressive characters, appealing shapes, consistent character design and fluid animation.',
    cooking: 'Professional food cinematography, appetising textures, clean preparation, realistic steam and controlled kitchen lighting.',
    nature: 'Photorealistic nature documentary, believable animal movement, natural environments and observational camera work.',
    documentary: 'Authentic documentary visual language, realistic locations, natural camera movement and credible details.',
    drama: 'Cinematic dramatic live-action, emotionally expressive performances, consistent wardrobe and motivated lighting.',
    general: 'Coherent high-quality visual storytelling, stable objects, natural movement and deliberate composition.'
  }[script.style];
  return [scene.prompt, `Production: ${script.title}. Scene ${index + 1} of ${script.scenes.length}.`, styleGuide,
    `Maintain visual continuity with the other scenes. Output ${script.ratio === '720:1280' ? 'vertical 9:16' : 'landscape 16:9'}.`,
    continuity ? `Character continuity:\n${continuity}` : '',
    'Avoid flicker, morphing faces, duplicate limbs, unstable objects, unintended text and abrupt changes in character appearance.'
  ].filter(Boolean).join('\n').slice(0, 1000);
}
