# MotionItOn-Ai pre-GPU readiness report — 2026-11-12

## Agreed architecture

MotionItOn-Ai is the user-facing application. The MotionItOn backend owns the authenticated job queue, progress, project records and permanent generated MP4 files. RunPod is a compute-only GPU worker. It receives prompts/settings, generates an MP4, and returns the file to the backend. The backend stores the MP4 under `/data/renders`; the SQLite database is under `/data`. The backend `/data` directory MUST be mounted on persistent storage.

Generated-video storage does not require Supabase Storage or a Supabase service-role key. Existing Supabase Auth configuration may remain if already used for sign-in; authentication and generated-video storage are separate concerns.

## Implemented in this ZIP

- Wan 2.2 TI2V-5B is the default worker/model; LTX remains optional legacy.
- The GPU worker service accepts authenticated jobs, reports progress, serves completed MP4s to the backend, and keeps temporary job data under `/workspace/jobs`.
- The backend has a remote worker client that submits, polls, cancels on timeout and downloads generated MP4 files.
- Production generation defaults to remote mode. If the worker is not connected or healthy, jobs stay queued and retry; there is no silent CPU fallback. Local generation is available only when `MOTIONITON_GENERATION_MODE=local` is explicitly selected for development.
- The backend writes completed MP4s to its own `MOTIONITON_DATA_DIR/renders` directory and creates a completed My Projects record.
- `Dockerfile.gpu-worker`, `Dockerfile.backend`, `.env.example`, `compose.backend.yml`, and the RunPod setup instructions are included.
- Backend health reports the generation mode and whether the remote worker URL/token are configured.

## Still required from the operator

1. Build and push the custom `Dockerfile.gpu-worker` image to a container registry RunPod can access. The generic PyTorch template alone is not the MotionItOn worker.
2. Deploy the custom image to the RTX 3090 pod with port `8790/http`, a 50 GB `/workspace` volume, and a strong `MOTIONITON_WORKER_TOKEN`.
3. Deploy the MotionItOn backend with a persistent volume mounted at `/data`. The included `compose.backend.yml` shows a named Docker volume configuration.
4. Configure `MOTIONITON_REMOTE_WORKER_URL` to the pod's HTTPS proxy URL and set the identical worker token on the backend. Keep all tokens server-side.
5. Configure the backend public HTTPS URL, `MOTIONITON_API_KEY`, and exact `ALLOWED_ORIGINS`; enter the backend URL and engine API key in MotionItOn Settings.
6. Verify `/api/health`, then call `/api/ai/remote-worker-health` with the engine key.
7. Run one 2–5 second test through the Generate button, verify the video appears in My Projects, stop the GPU pod, and verify the same video still plays.

## Not yet verified

- The custom GPU worker image has not been built/pushed to the user's registry or deployed to their RunPod pod in this session.
- The real RunPod HTTPS proxy URL and worker token have not been configured.
- The backend persistent volume has not been attached to the user's hosting environment.
- Wan 2.2 checkpoint loading and inference have not been tested on the actual RTX 3090.
- The end-to-end Generate → RunPod → backend MP4 persistence → My Projects → GPU-offline playback test has not yet passed.

Do not treat the ZIP's source tests or documentation as proof of a live GPU deployment. Follow `RUNPOD-DEPLOYMENT.md` in order and keep the first paid test short.
