import { setTimeout as delay } from 'node:timers/promises';
import { createWriteStream } from 'node:fs';
import { mkdir, rm } from 'node:fs/promises';
import path from 'node:path';
import { pipeline } from 'node:stream/promises';
import { Readable } from 'node:stream';

function workerConfig(env = process.env) {
  const baseUrl = String(env.MOTIONITON_REMOTE_WORKER_URL || '').replace(/\/+$/, '');
  const token = String(env.MOTIONITON_WORKER_TOKEN || '');
  if (!baseUrl || !token) throw new Error('Remote worker is not configured. Set MOTIONITON_REMOTE_WORKER_URL and MOTIONITON_WORKER_TOKEN.');
  const parsed = new URL(baseUrl);
  if (parsed.protocol !== 'https:' && parsed.hostname !== 'localhost' && parsed.hostname !== '127.0.0.1') throw new Error('Remote worker connections must use HTTPS outside localhost.');
  if (token.length < 32) throw new Error('MOTIONITON_WORKER_TOKEN must contain at least 32 characters.');
  return { baseUrl, token };
}

export async function runRemoteVideoGeneration({ prompt, ratio, duration, quality = 'high', style = 'general', model = 'motioniton-auto', workerId, workerProfile, characters = [], outputPath, onProgress = () => {}, env = process.env, fetchImpl = fetch }) {
  const { baseUrl, token } = workerConfig(env);
  const headers = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
  const response = await fetchImpl(`${baseUrl}/jobs`, { method: 'POST', headers, body: JSON.stringify({ prompt, ratio, duration, quality, style, model, workerId, workerProfile, characters }), signal: AbortSignal.timeout(30_000) });
  if (!response.ok) throw new Error(`Remote worker rejected the job (${response.status}): ${(await response.text()).slice(0, 500)}`);
  const submitted = await response.json();
  if (typeof submitted.id !== 'string' || !/^[a-f0-9-]{36}$/.test(submitted.id)) throw new Error('Remote worker returned an invalid job ID.');
  const timeoutMs = Math.max(60_000, Number(env.MOTIONITON_REMOTE_TIMEOUT_MS || 6 * 60 * 60 * 1000));
  const pollMs = Math.max(500, Math.min(10_000, Number(env.MOTIONITON_REMOTE_POLL_MS || 2000)));
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    await delay(pollMs);
    const statusResponse = await fetchImpl(`${baseUrl}/jobs/${submitted.id}`, { headers: { Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(30_000) });
    if (!statusResponse.ok) throw new Error(`Remote worker status request failed (${statusResponse.status}).`);
    const status = await statusResponse.json();
    onProgress(Math.max(1, Math.min(99, Number(status.progress) || 1)), String(status.message || 'Remote GPU is processing your video.').slice(0, 300));
    if (status.status === 'failed') throw new Error(String(status.error || 'Remote video generation failed.').slice(0, 2000));
    if (status.status === 'completed') {
      const fileResponse = await fetchImpl(`${baseUrl}/jobs/${submitted.id}/download`, { headers: { Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(10 * 60_000) });
      if (!fileResponse.ok || !fileResponse.body) throw new Error(`Remote worker output download failed (${fileResponse.status}).`);
      await mkdir(path.dirname(outputPath), { recursive: true });
      try { await pipeline(Readable.fromWeb(fileResponse.body), createWriteStream(outputPath)); }
      catch (error) { await rm(outputPath, { force: true }); throw error; }
      onProgress(100, 'Remote MP4 downloaded to private application storage.');
      return { outputPath, remoteJobId: submitted.id };
    }
  }
  await fetchImpl(`${baseUrl}/jobs/${submitted.id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } }).catch(() => {});
  throw new Error('Remote GPU worker timed out. A cancellation request was sent; verify worker status before retrying.');
}

export async function remoteWorkerHealth({ env = process.env, fetchImpl = fetch } = {}) {
  const { baseUrl, token } = workerConfig(env);
  const response = await fetchImpl(`${baseUrl}/health`, { headers: { Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(5000) });
  if (!response.ok) throw new Error(`Remote worker health check failed (${response.status}).`);
  return response.json();
}
