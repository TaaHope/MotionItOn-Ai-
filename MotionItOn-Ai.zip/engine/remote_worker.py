#!/usr/bin/env python3
"""Private HTTP worker for MotionItOn GPU pods (Python standard library only).

Endpoints: authenticated GET /health, POST /jobs, GET /jobs/{id}, GET /jobs/{id}/download.
Every endpoint requires Authorization: Bearer MOTIONITON_WORKER_TOKEN.
The control-plane sends only generation instructions, never account credentials.
"""
from __future__ import annotations
import hmac
import json
import os
import re
import shutil
import subprocess
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(os.environ.get("MOTIONITON_REMOTE_DATA", "/workspace/jobs")).resolve()
ROOT.mkdir(parents=True, exist_ok=True)
TOKEN = os.environ.get("MOTIONITON_WORKER_TOKEN", "")
PYTHON = os.environ.get("PYTHON_BIN", "python3")
GENERATOR = Path(os.environ.get("MOTIONITON_GENERATOR", Path(__file__).with_name("generate_video.py"))).resolve()
MAX_BODY = 64 * 1024
MAX_JOBS = max(1, min(8, int(os.environ.get("MOTIONITON_REMOTE_MAX_JOBS", "1"))))
RETENTION_SECONDS = max(600, int(os.environ.get("MOTIONITON_REMOTE_RETENTION_SECONDS", "43200")))
JOBS: dict[str, dict] = {}
LOCK = threading.RLock()
SLOTS = threading.BoundedSemaphore(MAX_JOBS)


def clean_old_jobs():
    cutoff = time.time() - RETENTION_SECONDS
    with LOCK:
        for job_id, job in list(JOBS.items()):
            if job.get("finished_at", 0) and job["finished_at"] < cutoff:
                shutil.rmtree(job["directory"], ignore_errors=True)
                del JOBS[job_id]


def validate(payload):
    if not isinstance(payload, dict): raise ValueError("JSON object required.")
    prompt = payload.get("prompt")
    if not isinstance(prompt, str) or not prompt.strip() or len(prompt) > 1000: raise ValueError("Prompt must contain 1–1000 characters.")
    ratio = payload.get("ratio", "1280:720")
    if ratio not in ("1280:720", "720:1280"): raise ValueError("Unsupported aspect ratio.")
    duration = payload.get("duration", 5)
    if isinstance(duration, bool) or not isinstance(duration, int) or not 2 <= duration <= 300: raise ValueError("Duration must be 2–300 seconds.")
    quality = payload.get("quality", "high")
    if quality not in ("standard", "high"): raise ValueError("Unsupported quality profile.")
    style = str(payload.get("style", "general"))[:40]
    model = payload.get("model", "motioniton-auto")
    if model not in ("motioniton-auto", "ltx-video-local", "wan-2.2-ti2v-5b", "ltx-legacy"): raise ValueError("Unsupported model selection.")
    characters = payload.get("characters", [])
    if not isinstance(characters, list) or len(characters) > 8: raise ValueError("Provide no more than eight character references.")
    names = set()
    for item in characters:
        if not isinstance(item, dict): raise ValueError("Character reference must be an object.")
        name, appearance, wardrobe = str(item.get("name", "")).strip(), str(item.get("appearance", "")).strip(), str(item.get("wardrobe", "")).strip()
        if not name or len(name) > 80 or not appearance or len(appearance) > 600 or len(wardrobe) > 300: raise ValueError("Character reference has missing or oversized fields.")
        if name.casefold() in names: raise ValueError("Duplicate character reference name.")
        names.add(name.casefold())
    worker_id = payload.get("workerId")
    worker_profile = payload.get("workerProfile")
    if worker_profile is not None:
        if not isinstance(worker_profile, dict) or worker_profile.get("id") != worker_id or worker_profile.get("model_id") not in ("wan-2.2-ti2v-5b", "ltx-legacy"):
            raise ValueError("Selected worker profile is invalid or unsupported by this GPU worker.")
        if not isinstance(worker_profile.get("name"), str) or not worker_profile["name"].strip() or len(worker_profile["name"]) > 80:
            raise ValueError("Selected worker profile name is invalid.")
    if worker_id is not None and (not isinstance(worker_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{3,80}", worker_id)): raise ValueError("Invalid worker ID.")
    return {"prompt": prompt.strip(), "ratio": ratio, "duration": duration, "quality": quality, "style": style, "model": model, "workerId": worker_id, "workerProfile": worker_profile, "characters": characters}


def run_job(job_id, options):
    job = JOBS[job_id]
    if not SLOTS.acquire(blocking=False):
        with LOCK: job.update(status="queued", progress=0, message="Waiting for an available GPU worker slot.")
        # Requeue without holding a thread or spinning.
        threading.Timer(2, lambda: start_job(job_id, options)).start()
        return
    try:
        directory = Path(job["directory"])
        output = directory / "output.mp4"
        args = [PYTHON, str(GENERATOR), "--prompt", options["prompt"], "--ratio", options["ratio"], "--duration", str(options["duration"]), "--quality", options["quality"], "--style", options["style"], "--model", options["model"], "--output", str(output)]
        if options.get("workerId"): args += ["--worker-id", options["workerId"]]
        worker_env = os.environ.copy()
        if options.get("workerProfile"):
            default_profile = dict(__import__("engine.worker_registry", fromlist=["DEFAULT_WORKER"]).DEFAULT_WORKER)
            worker_registry = [default_profile] if options["workerProfile"]["id"] == default_profile["id"] else [default_profile, {"id": options["workerProfile"]["id"], "name": options["workerProfile"]["name"], "model_id": options["workerProfile"].get("model_id", "wan-2.2-ti2v-5b"), "enabled": True, "is_default": False}]
            registry_file = directory / "workers.json"
            registry_file.write_text(json.dumps(worker_registry), encoding="utf-8")
            worker_env["MOTIONITON_WORKERS_FILE"] = str(registry_file)
        if options.get("characters"): args += ["--character-bible", json.dumps(options["characters"], separators=(",", ":"))]
        with LOCK: job.update(status="running", progress=1, message="GPU worker started.")
        error_log = directory / "worker-stderr.log"
        with error_log.open("w", encoding="utf-8") as error_stream:
            process = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=error_stream, text=True, bufsize=1, env=worker_env)
            with LOCK: job["process"] = process
            assert process.stdout is not None
            for line in process.stdout:
                try:
                    event = json.loads(line)
                    if event.get("type") == "progress":
                        with LOCK: job.update(progress=max(1, min(99, int(event.get("progress", 1)))), message=str(event.get("message", "Generating video"))[:300])
                    elif event.get("type") == "error":
                        with LOCK: job["message"] = str(event.get("message", "Generation failed"))[:500]
                except (json.JSONDecodeError, ValueError):
                    continue
            code = process.wait()
            process.stdout.close()
        stderr = error_log.read_text(encoding="utf-8", errors="replace") if error_log.exists() else ""
        if code != 0 or not output.is_file() or output.stat().st_size < 1024:
            raise RuntimeError((stderr or f"Generation worker exited with code {code}.")[-2000:])
        with LOCK: job.update(status="completed", progress=100, message="MP4 ready.", finished_at=time.time(), size=output.stat().st_size)
    except Exception as exc:
        with LOCK: job.update(status="failed", progress=100, error=str(exc)[-2000:], finished_at=time.time())
    finally:
        with LOCK: job.pop("process", None)
        SLOTS.release()
        clean_old_jobs()


def start_job(job_id, options):
    thread = threading.Thread(target=run_job, args=(job_id, options), daemon=True)
    thread.start()


class Handler(BaseHTTPRequestHandler):
    server_version = "MotionItOnWorker/1.0"
    def log_message(self, *_): return
    def respond(self, status, data, content_type="application/json"):
        raw = data if isinstance(data, bytes) else json.dumps(data).encode()
        self.send_response(status); self.send_header("Content-Type", content_type); self.send_header("Content-Length", str(len(raw))); self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(raw)
    def authorized(self):
        supplied = self.headers.get("Authorization", "")
        expected = f"Bearer {TOKEN}"
        return bool(TOKEN) and hmac.compare_digest(supplied.encode(), expected.encode())
    def do_GET(self):
        path = urlparse(self.path).path
        if not self.authorized(): return self.respond(401, {"error": "Worker authentication required."})
        if path == "/health":
            try:
                import torch
                gpu = {"available": bool(torch.cuda.is_available()), "name": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
                       "vram_gb": round(torch.cuda.get_device_properties(0).total_memory / (1024 ** 3), 2) if torch.cuda.is_available() else 0}
            except Exception as exc:
                gpu = {"available": False, "error": str(exc)[:200]}
            return self.respond(200, {"ok": True, "service": "motioniton-gpu-worker", "gpu_slots": MAX_JOBS, "gpu": gpu, "model": os.environ.get("MOTIONITON_SELECTED_MODEL", "wan-2.2-ti2v-5b")})
        match = re.fullmatch(r"/jobs/([a-f0-9-]{36})(/download)?", path)
        if not match: return self.respond(404, {"error": "Not found."})
        with LOCK: job = JOBS.get(match.group(1))
        if not job: return self.respond(404, {"error": "Worker job not found."})
        if match.group(2):
            file = Path(job["directory"]) / "output.mp4"
            if job["status"] != "completed" or not file.is_file(): return self.respond(409, {"error": "Output is not ready."})
            self.send_response(200); self.send_header("Content-Type", "video/mp4"); self.send_header("Content-Length", str(file.stat().st_size)); self.send_header("Content-Disposition", "attachment; filename=motioniton-output.mp4"); self.send_header("Cache-Control", "no-store"); self.end_headers()
            with file.open("rb") as stream: shutil.copyfileobj(stream, self.wfile)
            return
        return self.respond(200, {key: job.get(key) for key in ("id", "status", "progress", "message", "error", "size")})
    def do_POST(self):
        if urlparse(self.path).path != "/jobs": return self.respond(404, {"error": "Not found."})
        if not self.authorized(): return self.respond(401, {"error": "Worker authentication required."})
        try: length = int(self.headers.get("Content-Length", "0"))
        except ValueError: return self.respond(400, {"error": "Invalid Content-Length."})
        if length <= 0 or length > MAX_BODY: return self.respond(413, {"error": "Job request size is invalid."})
        try:
            with LOCK:
                active = sum(item.get("status") in ("queued", "running") for item in JOBS.values())
                if active >= MAX_JOBS * 4: return self.respond(429, {"error": "Remote worker queue is full. Retry later."})
            options = validate(json.loads(self.rfile.read(length)))
            job_id = str(uuid.uuid4()); directory = ROOT / job_id; directory.mkdir(mode=0o700)
            job = {"id": job_id, "status": "queued", "progress": 0, "directory": str(directory), "created_at": time.time()}
            with LOCK: JOBS[job_id] = job
            start_job(job_id, options)
            return self.respond(202, {"id": job_id, "status": "queued"})
        except (ValueError, json.JSONDecodeError) as exc: return self.respond(400, {"error": str(exc)})


    def do_DELETE(self):
        if not self.authorized(): return self.respond(401, {"error": "Worker authentication required."})
        match = re.fullmatch(r"/jobs/([a-f0-9-]{36})", urlparse(self.path).path)
        if not match: return self.respond(404, {"error": "Not found."})
        with LOCK: job = JOBS.get(match.group(1))
        if not job: return self.respond(404, {"error": "Worker job not found."})
        process = job.get("process")
        if process and process.poll() is None:
            process.terminate()
            with LOCK: job.update(status="cancelled", error="Cancelled by control plane.", finished_at=time.time())
            return self.respond(202, {"ok": True, "status": "cancelling"})
        return self.respond(409, {"error": "Job is no longer running."})


def main():
    if len(TOKEN) < 32: raise SystemExit("MOTIONITON_WORKER_TOKEN must be at least 32 characters.")
    host = os.environ.get("MOTIONITON_WORKER_HOST", "0.0.0.0")
    port = int(os.environ.get("MOTIONITON_WORKER_PORT", "8790"))
    server = ThreadingHTTPServer((host, port), Handler)
    print(json.dumps({"ready": True, "host": host, "port": port, "max_jobs": MAX_JOBS}), flush=True)
    server.serve_forever()

if __name__ == "__main__": main()
