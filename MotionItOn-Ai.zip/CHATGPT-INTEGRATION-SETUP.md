# ChatGPT -> MotionItOn-Ai script queue integration

This integration exposes a private, authenticated API that a configured ChatGPT GPT Action can call to submit structured scripts. Scripts are stored in MotionItOn's existing SQLite-backed AI job store and appear in the owner's normal AI jobs list. They survive backend restarts while queued. Production scripts are rendered scene-by-scene, stitched with the requested transitions, and saved in the backend's private render storage.

## 1. Requirements

- Deploy the MotionItOn backend on a public HTTPS URL (for example `https://api.example.com`). Do not expose the backend over plain public HTTP.
- Create a MotionItOn account and sign in.
- Set `MOTIONITON_CHATGPT_OWNER_USER_ID` to that account's `user.id` from `GET /api/auth/me`.
- Generate a unique secret token of at least 32 random characters and set it as `MOTIONITON_CHATGPT_TOKEN` on the backend. Keep it server-side only.
- Configure the backend to use the private remote GPU worker when ready. Script jobs submitted through this bridge remain queued until `MOTIONITON_REMOTE_WORKER_URL` is configured and its `/health` endpoint succeeds. They will not fall back to an unintended local GPU.

Generate a token with:

```bash
node scripts/generate-chatgpt-token.mjs
```

## 2. Configure a ChatGPT GPT Action

1. In ChatGPT, create or edit a GPT and open **Configure -> Actions -> Create new action**.
2. Import `openapi/chatgpt-script-bridge.yaml`.
3. Replace `https://YOUR-MOTIONITON-API-DOMAIN` with the public HTTPS backend origin.
4. Set Authentication to **API Key**, choose **Bearer**, and paste the exact value of `MOTIONITON_CHATGPT_TOKEN`.
5. Save the GPT. When ChatGPT asks to authorise the Action, approve the connection.
6. Ask that GPT to prepare a production script and submit it to MotionItOn-Ai. It can then check the returned job ID with the status action.

A custom GPT Action is an explicit ChatGPT integration. ChatGPT cannot silently push arbitrary conversation content to a private app in the background; it calls this Action when the user asks it to submit the script and confirms any applicable Action approval.

## 3. Supported script contract

- `title`: 1–120 characters.
- `style`: realistic, cinematic, cartoons, cooking, nature, documentary, drama or general.
- `ratio`: `1280:720` landscape or `720:1280` portrait.
- `quality`: standard or high.
- `characters`: up to eight objects with `name`, `appearance`, optional `wardrobe`.
- `scenes`: 1–20 scenes; each has a 1–1000 character `prompt`, `durationSeconds` from 2–20 and optional transition `cut`, `fade`, `dissolve` or `slide`.
- Total script duration is limited to 300 seconds.

Use an `Idempotency-Key` header for each script submission. Repeating the same key for the same account returns the original job instead of creating a duplicate.

## 4. Endpoints

- `GET /api/integrations/chatgpt/health`
- `POST /api/integrations/chatgpt/scripts`
- `GET /api/integrations/chatgpt/jobs/{id}`

All require `Authorization: Bearer <MOTIONITON_CHATGPT_TOKEN>`.

## 5. Storage and queue behaviour

The submitted script and its production settings are persisted in the AI jobs database. The job is visible in the signed-in owner's MotionItOn AI jobs list. A queued script waits for the configured remote worker to become healthy. Scene MP4s are downloaded from the remote worker to MotionItOn backend storage, stitched there, and temporary scene files are removed after successful assembly. Configure `MOTIONITON_DATA_DIR` on durable backend storage and back up that storage. For a multi-instance production deployment, use shared durable storage and a distributed queue before scaling beyond one backend worker.

## 6. Important current limitations

The bridge and queue integration do not themselves create Wan model capability. The actual worker must have an implemented and tested Wan 2.2 adapter before it can render Wan jobs. The currently bundled worker registry in this baseline must be checked against the selected model adapter; do not treat a registered model name as proof of working inference. GPU scheduling and hard stop-at-9pm behaviour must be configured and verified separately. A job that has not completed by the session cutoff must be safely retained/requeued, not reported as completed.

For suggested GPT behaviour/instructions, copy `CHATGPT-GPT-INSTRUCTIONS.md` into the GPT's Instructions field. This makes the GPT structure scripts consistently and call the Action when the user explicitly asks it to submit them.
