# MotionItOn Local AI Video Engine (Android app first)

## What changed

The Runway API adapter has been removed from the generation path. MotionItOn now queues generation jobs and invokes `engine/generate_video.py`, which loads the open-weight Wan 2.2 TI2V-5B model through Hugging Face Diffusers by default and encodes a real MP4 with FFmpeg. The app remains a Capacitor Android app; Windows and web sources/workflows are retained.

This is a **self-hosted open-weight model engine**, not an on-device Android model and not a commercial video-generation API. The Android app talks to a separately hosted MotionItOn backend. Model inference runs on the machine hosting the worker and requires a compatible NVIDIA GPU. The current worker intentionally fails clearly rather than pretending CPU/phone generation works. No Claude API or ChatGPT API is used.

## Engine host requirements

- Linux recommended, Python 3.10/3.11, Node.js 22, FFmpeg.
- NVIDIA GPU with CUDA and enough VRAM for the Wan 2.2 TI2V-5B; the TI2V-5B 24 GB offload profile requires CPU offloading and sufficient free VRAM. MotionItOn enables Diffusers model CPU offloading by default and checks for 20 GB free before loading. See the official Wan 2.2 TI2V-5B model card.
- Install a CUDA-enabled PyTorch build using the official PyTorch install selector, then run `pip install -r engine/requirements.txt`.
- Set `MOTIONITON_API_KEY` to a long random secret and `MOTIONITON_DATA_DIR` to persistent storage. Start the Node API with `npm run backend`.
- The model is downloaded from Hugging Face on first generation. Set `MOTIONITON_VIDEO_MODEL` to a compatible local model ID or path. To force cache-only loading, set `MOTIONITON_LOCAL_FILES_ONLY=true` after downloading the model.
- Optional `MOTIONITON_VIDEO_STEPS` controls denoising steps (default 20). More steps can improve output but take longer.

## API

- `GET /api/ai/engine` reports the self-hosted engine identity and model mode.
- `POST /api/ai/generate` accepts `{prompt, ratio, duration}`. Duration is currently 2–20 seconds. Returns a queued job.
- `GET /api/ai/jobs` lists jobs.
- `GET /api/ai/jobs/:id` checks a job.
- `GET /api/ai/jobs/:id/download` downloads the generated MP4.

The backend access key protects your own engine; it is not a commercial model-provider key. Do not expose the engine publicly without HTTPS, real user authentication, per-user authorization, and rate limits. The current daily limit is a safety cap, not billing.

## Android-first validation plan

1. Run `npm run test:backend` and `node --check backend/server.mjs`.
2. On the engine host, verify `python3 -c 'import torch; print(torch.cuda.is_available())'` returns `True`.
3. Run a short worker smoke test with a simple prompt and confirm the output is a playable MP4.
4. Start the Node backend and test the health and `/api/ai/engine` endpoints.
5. Build the existing Android APK workflow, set the engine HTTPS URL and MotionItOn backend key in the app, generate a short clip, download it, and play it on Android.

## Limitations honestly retained

This code has not yet been run against model weights or a CUDA GPU in this environment. Therefore no real generated clip has been verified yet. The first model load is large and may take time. The current engine is self-hosted on a compatible GPU host; porting LTX inference into the Android APK itself would be a separate native-model project and is not claimed here. The Windows and web workflows are preserved but are not the immediate validation target.

## Engine diagnostics (new)

The AI Video screen's **Test engine** action checks backend reachability and calls `GET /api/ai/engine`. That endpoint runs `engine/doctor.py` in the configured Python environment and reports Python, FFmpeg, PyTorch, CUDA, Diffusers, Transformers, Accelerate, Safetensors, and model-cache status. A successful HTTP connection no longer implies the model runtime is ready. Failed checks include their diagnostic detail in the app.

Run the same preflight directly on the engine host with `python3 engine/doctor.py`. It does not download model weights or run inference.

## Generation reliability update

The backend now applies a configurable process timeout to local model generation. Default: 30 minutes. Set `MOTIONITON_VIDEO_TIMEOUT_MS` to another positive millisecond value on the engine host if your hardware needs longer. Timed-out workers are terminated and the job is marked failed with a user-facing error rather than remaining in `running` indefinitely. Structured progress output is parsed even if the final worker message does not end with a newline.

A GitHub Actions workflow (`MotionItOn Engine Checks`) runs backend unit/integration tests, JavaScript syntax checks, and Python syntax checks whenever engine code changes. This validates orchestration and syntax; it does not claim to validate GPU inference or build an Android APK.


## No paid writing API

MotionItOn does not require Claude or ChatGPT API credentials. Write scripts and episode dialogue in ChatGPT separately and paste prompts into the application. The current generation screen accepts one short scene prompt (2–20 seconds); full episode-script ingestion and automatic multi-scene movie production are not implemented yet.

## VPS-independent target

The Windows VPS is not required by the target architecture. However, the current Node backend and Python worker still need to run somewhere reachable. For the intended hourly-GPU model, deploy the backend/worker to an on-demand GPU host or implement a provider-specific remote worker adapter. Automatic cloud GPU provisioning and shutdown are not included in this archive yet. See `MOTIONITON-ARCHITECTURE.md`.
