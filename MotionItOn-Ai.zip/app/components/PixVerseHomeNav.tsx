'use client';
import { Film, Image as ImageIcon, Scissors, Sparkles, UserRound, Video, Wand2, Volume2, Smile, SlidersHorizontal, Play, AudioLines } from 'lucide-react';


type Tool = { id: string; label: string; icon: typeof Video; description: string };
const primary: Tool[] = [
  { id: 'text-to-video', label: 'Text to Video', icon: Video, description: 'Generate a video from a written prompt.' },
  { id: 'image-to-video', label: 'Image to Video', icon: Film, description: 'Animate an image with a motion prompt.' },
  { id: 'create-image', label: 'Create Image', icon: ImageIcon, description: 'Create a still image from a prompt.' },
  { id: 'vibemvai', label: 'VibeMVAI', icon: Wand2, description: 'Create a music-led visual concept.' }
];
const secondary: Tool[] = [
  { id: 'video-editor', label: 'Video Trimmer', icon: Scissors, description: 'Trim and arrange video clips.' },
  { id: 'audio-trimmer', label: 'Audio Trimmer', icon: AudioLines, description: 'Trim audio tracks.' },
  { id: 'sound-effects', label: 'Sound FX', icon: Volume2, description: 'Create sound effects.' },
  { id: 'lip-sync', label: 'Lip Sync', icon: Smile, description: 'Synchronise speech and character movement.' },
  { id: 'edit-image', label: 'Edit Image', icon: ImageIcon, description: 'Edit an existing image.' },
  { id: 'transition', label: 'Transitions', icon: SlidersHorizontal, description: 'Create a transition between clips.' }
];
const categories = [
  { name: 'Cooking', art: 'cooking', note: 'Recipes, food films and kitchen stories' },
  { name: 'Drama series', art: 'drama', note: 'Characters, episodes and cinematic stories' },
  { name: 'Nature', art: 'nature', note: 'Natural landscapes and outdoor scenes' },
  { name: 'Cartoons', art: 'cartoons', note: 'Animated worlds and family stories' },
  { name: 'Documentary', art: 'documentary', note: 'Real stories and explainers' }
];

export function PixVerseHomeNav({ onSelectTool, onOpenCategory, onProfile }: { onSelectTool: (id: string) => void; onOpenCategory: (name: string) => void; onProfile: () => void }) {
  return <section className="pixverse-home" aria-label="Creator tools">
    <div className="pixverse-brand-row"><div><span className="pixverse-kicker">MOTIONITON CREATOR STUDIO</span><h2>What would you like to create?</h2></div><button className="primary-button" onClick={() => onSelectTool('text-to-video')}><Sparkles size={16}/> Create video</button></div>
    <h3>Creation tools</h3><div className="pixverse-tool-grid">{primary.map(tool => { const Icon=tool.icon; return <button key={tool.id} className="pixverse-tool-card" onClick={() => onSelectTool(tool.id)}><span><Icon size={19}/></span><b>{tool.label}</b><small>{tool.description}</small></button>; })}</div>
    <div className="pixverse-secondary-tools">{secondary.map(tool => { const Icon=tool.icon; return <button key={tool.id} onClick={() => onSelectTool(tool.id)}><Icon size={17}/><span>{tool.label}</span></button>; })}</div>
    <div className="pixverse-category-head"><h3>Explore categories</h3><span>Explore visual styles for each category</span></div>
    <div className="pixverse-category-grid">{categories.map(item => <button className={`pixverse-category-card art-${item.art}`} key={item.name} onClick={() => onOpenCategory(item.name)} aria-label={`Create in ${item.name}`}>
      <span className="category-artwork" aria-hidden="true"><i/><i/><i/></span>
      <span className="category-card-copy"><b>{item.name}</b><small>{item.note}</small><em>Create video <span aria-hidden>→</span></em></span>
    </button>)}</div>
    <nav className="mobile-bottom-nav" aria-label="Mobile navigation"><button className="active" onClick={() => onSelectTool('home')}><Sparkles size={19}/><span>Create</span></button><button onClick={() => onSelectTool('projects')}><Film size={19}/><span>Projects</span></button><button className="mobile-create" onClick={() => onSelectTool('text-to-video')}><Sparkles size={22}/></button><button onClick={() => onSelectTool('video-editor')}><Scissors size={19}/><span>Editor</span></button><button onClick={onProfile}><UserRound size={19}/><span>Profile</span></button></nav>
  </section>;
}
