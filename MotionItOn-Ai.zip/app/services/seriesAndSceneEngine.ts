export interface SceneItem {
  id: string; sceneNumber: number; title: string; visualPrompt: string;
  narrationText: string; durationSeconds: number; characterIds?: string[];
  transitionType?: "cut" | "fade" | "dissolve" | "slide"; notes?: string;
}
export interface EpisodeDetail { id: string; episodeNumber: number; title: string; synopsis: string; scenes: SceneItem[] }
export interface ScriptPlan { title: string; synopsis: string; episodes: EpisodeDetail[] }
const makeId=(p:string)=>`${p}_${globalThis.crypto?.randomUUID?.()??`${Date.now()}_${Math.random().toString(36).slice(2)}`}`;
const valid=(i:number,n:number)=>Number.isInteger(i)&&i>=0&&i<n;
const renumberScenes=(a:SceneItem[])=>a.map((s,i)=>({...s,sceneNumber:i+1}));
const renumberEpisodes=(a:EpisodeDetail[])=>a.map((e,i)=>({...e,episodeNumber:i+1,scenes:renumberScenes(e.scenes)}));
function move<T>(a:T[],f:number,t:number){if(!valid(f,a.length)||!valid(t,a.length))throw new RangeError('Invalid reorder index.');const b=[...a],v=b.splice(f,1)[0];b.splice(t,0,v);return b}
export class SeriesManager {
 static createEpisode(title:string,n=1):EpisodeDetail{if(!Number.isInteger(n)||n<1)throw Error('Episode number must be positive.');return{id:makeId('ep'),episodeNumber:n,title:title.trim()||`Episode ${n}`,synopsis:'',scenes:[]}}
 static updateEpisode(a:EpisodeDetail[],id:string,c:Partial<Pick<EpisodeDetail,'title'|'synopsis'>>){if(c.title!==undefined&&!c.title.trim())throw Error('Episode title is required.');if(c.synopsis!==undefined&&c.synopsis.length>10000)throw Error('Episode synopsis is too long.');return a.map(e=>e.id===id?{...e,...c,title:c.title===undefined?e.title:c.title.trim()}:e)}
 static deleteEpisode(a:EpisodeDetail[],id:string){return renumberEpisodes(a.filter(e=>e.id!==id))}
 static reorderEpisodes(a:EpisodeDetail[],f:number,t:number){return renumberEpisodes(move(a,f,t))}
 static createScene(title='New Scene'):SceneItem{return{id:makeId('scene'),sceneNumber:1,title:title.trim()||'New Scene',visualPrompt:'',narrationText:'',durationSeconds:10,transitionType:'cut'}}
 static updateScene(a:SceneItem[],id:string,c:Partial<Omit<SceneItem,'id'|'sceneNumber'>>){return a.map(s=>{if(s.id!==id)return s;const n={...s,...c};if(!n.title.trim())throw Error('Scene title is required.');if(!Number.isFinite(n.durationSeconds)||n.durationSeconds<=0||n.durationSeconds>3600)throw Error('Scene duration must be between 1 and 3,600 seconds.');if(n.visualPrompt.length>20000||n.narrationText.length>20000)throw Error('Scene text exceeds the 20,000-character limit.');if(n.characterIds&&(!Array.isArray(n.characterIds)||n.characterIds.some(x=>typeof x!=='string')))throw Error('Scene character assignments are invalid.');if(n.transitionType&&!['cut','fade','dissolve','slide'].includes(n.transitionType))throw Error('Unsupported scene transition.');return n})}
 static duplicateScene(s:SceneItem):SceneItem{return{...s,id:makeId('scene'),title:`${s.title} (Copy)`}}
 static deleteScene(a:SceneItem[],id:string){return renumberScenes(a.filter(s=>s.id!==id))}
 static reorderScenes(a:SceneItem[],f:number,t:number){return renumberScenes(move(a,f,t))}
 static calculateTotalDuration(scenes:SceneItem[]){return scenes.reduce((sum,s)=>sum+s.durationSeconds,0)}
 static allocateSceneDurations<T extends {durationSeconds?:number}>(items:T[],totalSeconds:number):T[]{if(!Number.isFinite(totalSeconds)||totalSeconds<=0||!items.length)throw Error('A positive target duration and at least one scene are required.');const weights=items.map(x=>Number.isFinite(x.durationSeconds)&&Number(x.durationSeconds)>0?Number(x.durationSeconds):1);const sum=weights.reduce((a,b)=>a+b,0);let used=0;return items.map((item,i)=>{const durationSeconds=i===items.length-1?Math.max(1,Math.round(totalSeconds)-used):Math.max(1,Math.round(totalSeconds*weights[i]/sum));used+=durationSeconds;return{...item,durationSeconds}})}
 static validateScript(episodes:EpisodeDetail[]){const errors:string[]=[];if(!episodes.length)errors.push('Add at least one episode.');for(const [ei,e] of episodes.entries()){if(!e.title.trim())errors.push(`Episode ${ei+1} needs a title.`);if(!e.scenes.length)errors.push(`Episode ${ei+1} needs at least one scene.`);for(const [si,s] of e.scenes.entries()){if(!s.title.trim())errors.push(`Episode ${ei+1}, scene ${si+1} needs a title.`);if(!Number.isFinite(s.durationSeconds)||s.durationSeconds<=0||s.durationSeconds>3600)errors.push(`Episode ${ei+1}, scene ${si+1} has an invalid duration.`)}}return{valid:errors.length===0,errors}}
 static buildScript(title:string,synopsis:string,episodes:EpisodeDetail[]):ScriptPlan{if(title.trim().length>200||synopsis.length>10000)throw Error('Script title or synopsis exceeds its limit.');const check=this.validateScript(episodes);if(!check.valid)throw Error(check.errors.join(' '));return{title:title.trim(),synopsis,episodes:renumberEpisodes(episodes)}}
}
