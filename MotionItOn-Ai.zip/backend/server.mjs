import express from 'express';
import multer from 'multer';
import helmet from 'helmet';
import cors from 'cors';
import Database from 'better-sqlite3';
import { randomUUID, randomBytes, createHash, scrypt as scryptCallback, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { spawn, execFile } from 'node:child_process';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { runLocalVideoGeneration, normalizeGenerateRequest } from './ai-video-engine.mjs';
import { runRemoteVideoGeneration, remoteWorkerHealth } from './remote-worker-client.mjs';
import { buildFfmpegStitchArgs } from './ffmpeg-stitch.mjs';
import { validateProductionScript, compileProductionPrompt } from './chatgpt-script-bridge.mjs';

const app = express();
const execFileAsync = promisify(execFile);
const scrypt = promisify(scryptCallback);
const PORT = Number(process.env.PORT || 8787);
const DATA = path.resolve(process.env.MOTIONITON_DATA_DIR || './motioniton-data');
const UPLOADS = path.join(DATA, 'uploads');
const OUTPUTS = path.join(DATA, 'renders');
const DB_PATH = path.join(DATA, 'jobs.sqlite');
const MAX_FILE = Math.max(1, Number(process.env.MAX_UPLOAD_BYTES || 300 * 1024 * 1024));
const API_KEY = process.env.MOTIONITON_API_KEY || '';
const MAX_CLIPS = Math.min(20, Math.max(1, Number(process.env.MAX_CLIPS || 20)));
const MAX_AI_GENERATIONS_PER_DAY = Math.min(100, Math.max(1, Number(process.env.MAX_AI_GENERATIONS_PER_DAY || 5)));
const allowed = (process.env.ALLOWED_ORIGINS || 'http://localhost:3000,http://localhost:3001,capacitor://localhost').split(',').map(x => x.trim()).filter(Boolean);
await fs.mkdir(UPLOADS, { recursive: true });
await fs.mkdir(OUTPUTS, { recursive: true });
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('busy_timeout = 5000');
db.pragma('foreign_keys = ON');
db.exec(`CREATE TABLE IF NOT EXISTS ai_video_jobs (
  id TEXT PRIMARY KEY, status TEXT NOT NULL, progress INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, finished_at TEXT,
  prompt TEXT NOT NULL, model TEXT NOT NULL, ratio TEXT NOT NULL, duration INTEGER NOT NULL,
  provider_task_id TEXT NOT NULL, output_path TEXT, error TEXT
);
CREATE TABLE IF NOT EXISTS render_jobs (
  id TEXT PRIMARY KEY, status TEXT NOT NULL, progress INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, finished_at TEXT,
  files_json TEXT NOT NULL, options_json TEXT NOT NULL, output_path TEXT, error TEXT
)`);
function ensureColumn(table, column, definition) {
  const columns = db.prepare(`PRAGMA table_info(${table})`).all();
  if (!columns.some(item => item.name === column)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
}
ensureColumn('ai_video_jobs', 'user_id', 'TEXT');
ensureColumn('ai_video_jobs', 'production_json', 'TEXT');
ensureColumn('ai_video_jobs', 'idempotency_key', 'TEXT');
ensureColumn('ai_video_jobs', 'category', "TEXT NOT NULL DEFAULT 'General'");
ensureColumn('ai_video_jobs', 'quality', "TEXT NOT NULL DEFAULT 'high'");
ensureColumn('ai_video_jobs', 'style', "TEXT NOT NULL DEFAULT 'general'");
ensureColumn('ai_video_jobs', 'worker_id', 'TEXT');
ensureColumn('ai_video_jobs', 'characters_json', "TEXT NOT NULL DEFAULT '[]'");
ensureColumn('ai_video_jobs', 'storage_object_path', 'TEXT');
ensureColumn('ai_video_jobs', 'storage_status', "TEXT NOT NULL DEFAULT 'local-only'");
ensureColumn('ai_video_jobs', 'storage_error', 'TEXT');
ensureColumn('render_jobs', 'user_id', 'TEXT');
const aiRows = db.prepare('SELECT * FROM ai_video_jobs ORDER BY created_at DESC').all();
const aiVideoJobs = aiRows.map(row => ({
  id: row.id, userId: row.user_id || null, status: row.status, progress: row.progress, createdAt: row.created_at,
  updatedAt: row.updated_at, finishedAt: row.finished_at, prompt: row.prompt,
  model: row.model, ratio: row.ratio, duration: row.duration,
  providerTaskId: row.provider_task_id, output: row.output_path, error: row.error, production: row.production_json ? JSON.parse(row.production_json) : null, requiresRemote: Boolean(row.production_json), idempotencyKey: row.idempotency_key || null, category: row.category || 'General', quality: row.quality || 'high', style: row.style || 'general', workerId: row.worker_id || undefined, characters: row.characters_json ? JSON.parse(row.characters_json) : [], storageObjectPath: row.storage_object_path || null, storageStatus: row.storage_status || 'local-only', storageError: row.storage_error || null
}));
for (const job of aiVideoJobs.filter(item => ['running', 'downloading'].includes(item.status))) { job.status = 'queued'; job.progress = 0; job.error = null; job.finishedAt = null; }
const upsertAiVideoJob = db.prepare(`INSERT INTO ai_video_jobs
(id,user_id,status,progress,created_at,updated_at,finished_at,prompt,model,ratio,duration,provider_task_id,output_path,error,production_json,idempotency_key,category,quality,style,worker_id,characters_json,storage_object_path,storage_status,storage_error)
VALUES (@id,@userId,@status,@progress,@createdAt,@updatedAt,@finishedAt,@prompt,@model,@ratio,@duration,@providerTaskId,@output,@error,@productionJson,@idempotencyKey,@category,@quality,@style,@workerId,@charactersJson,@storageObjectPath,@storageStatus,@storageError)
ON CONFLICT(id) DO UPDATE SET status=excluded.status,progress=excluded.progress,updated_at=excluded.updated_at,
finished_at=excluded.finished_at,output_path=excluded.output_path,error=excluded.error,user_id=excluded.user_id,production_json=excluded.production_json,idempotency_key=excluded.idempotency_key,category=excluded.category,quality=excluded.quality,style=excluded.style,worker_id=excluded.worker_id,characters_json=excluded.characters_json,storage_object_path=excluded.storage_object_path,storage_status=excluded.storage_status,storage_error=excluded.storage_error`);
function persistAiVideoJob(job) {
  job.updatedAt = new Date().toISOString();
  upsertAiVideoJob.run({ id: job.id, userId: job.userId || null, status: job.status, progress: job.progress, createdAt: job.createdAt,
    updatedAt: job.updatedAt, finishedAt: job.finishedAt || null, prompt: job.prompt, model: job.model,
    ratio: job.ratio, duration: job.duration, providerTaskId: job.providerTaskId,
    output: job.output || null, error: job.error || null, productionJson: job.production ? JSON.stringify(job.production) : null, idempotencyKey: job.idempotencyKey || null, category: job.category || 'General', quality: job.quality || 'high', style: job.style || job.production?.style || 'general', workerId: job.workerId || null, charactersJson: JSON.stringify(job.characters || job.production?.characters || []), storageObjectPath: job.storageObjectPath || null, storageStatus: job.storageStatus || 'local-only', storageError: job.storageError || null });
}
const publicAiVideoJob = job => ({ id: job.id, status: job.status, progress: job.progress,
  title: job.production?.title || null, prompt: job.prompt, model: job.model, ratio: job.ratio, duration: job.duration,
  error: job.error || null, createdAt: job.createdAt, finishedAt: job.finishedAt || null,
  downloadUrl: job.status === 'completed' ? `/api/ai/jobs/${job.id}/download` : null,
  production: job.production || null, style: job.style || job.production?.style || null, category: job.category || 'General', storageStatus: job.storageStatus || 'local-only' });

const rows = db.prepare('SELECT * FROM render_jobs ORDER BY created_at DESC').all();
let jobs = rows.map(row => ({
  id: row.id, userId: row.user_id || null, status: row.status, progress: row.progress, createdAt: row.created_at,
  updatedAt: row.updated_at, finishedAt: row.finished_at, files: JSON.parse(row.files_json),
  options: JSON.parse(row.options_json), output: row.output_path, error: row.error
}));
// A running FFmpeg child cannot survive a process restart. Mark it failed instead of reporting false progress.
for (const job of jobs.filter(j => j.status === 'running')) {
  job.status = 'failed'; job.error = 'Backend restarted while this render was running. Submit the render again.';
  job.updatedAt = new Date().toISOString();
}
const upsert = db.prepare(`INSERT INTO render_jobs
(id,user_id,status,progress,created_at,updated_at,finished_at,files_json,options_json,output_path,error)
VALUES (@id,@userId,@status,@progress,@createdAt,@updatedAt,@finishedAt,@filesJson,@optionsJson,@output,@error)
ON CONFLICT(id) DO UPDATE SET status=excluded.status, progress=excluded.progress, updated_at=excluded.updated_at,
finished_at=excluded.finished_at, files_json=excluded.files_json, options_json=excluded.options_json,
output_path=excluded.output_path, error=excluded.error,user_id=excluded.user_id`);
function persist(job) {
  job.updatedAt = new Date().toISOString();
  upsert.run({ id: job.id, userId: job.userId || null, status: job.status, progress: job.progress, createdAt: job.createdAt,
    updatedAt: job.updatedAt, finishedAt: job.finishedAt || null, filesJson: JSON.stringify(job.files),
    optionsJson: JSON.stringify(job.options), output: job.output || null, error: job.error || null });
}
for (const job of jobs.filter(j => j.status === 'failed' && j.error?.startsWith('Backend restarted'))) persist(job);


app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' }, contentSecurityPolicy: false }));
app.use(cors({ origin(origin, cb) {
  if (!origin || allowed.includes(origin)) return cb(null, true);
  return cb(new Error(`Origin not allowed: ${origin}`));
} }));
app.use(express.json({ limit: '1mb' }));
// Account authentication: password hashes use scrypt and bearer sessions are stored hashed.
db.exec(`CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, display_name TEXT NOT NULL,
 password_hash TEXT NOT NULL, password_salt TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS user_sessions (
 token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 created_at TEXT NOT NULL, expires_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS user_projects (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, payload_json TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_user_projects_owner ON user_projects(user_id);
CREATE INDEX IF NOT EXISTS idx_render_jobs_owner ON render_jobs(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_jobs_owner ON ai_video_jobs(user_id);`);
const hashToken = value => createHash('sha256').update(value).digest('hex');
const authLimiter = new Map();
function authRateLimit(req, res, next) {
 const key = `${req.ip}:${req.path}`; const now = Date.now(); const recent = (authLimiter.get(key) || []).filter(t => now - t < 15 * 60 * 1000); for (const [k,v] of authLimiter) if (!v.length || now-v[v.length-1]>15*60*1000) authLimiter.delete(k); if (authLimiter.size>10000) authLimiter.clear();
 if (recent.length >= 12) return res.status(429).json({ error: 'Too many attempts. Try again in 15 minutes.' });
 recent.push(now); authLimiter.set(key, recent); next();
}
function bearer(req) { return (req.get('authorization') || '').replace(/^Bearer\s+/i, '').trim(); }
function findSession(req) {
 const token = bearer(req); if (!token) return null;
 return db.prepare(`SELECT users.id, users.email, users.display_name AS displayName FROM user_sessions JOIN users ON users.id=user_sessions.user_id WHERE token_hash=? AND expires_at>?`).get(hashToken(token), new Date().toISOString()) || null;
}
async function requireUser(req,res,next) {
 const localUser=findSession(req);
 if(localUser){ req.user=localUser; return next(); }
 const token=bearer(req);
 const supabaseUrl=String(process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL || '').replace(/\/+$/,'');
 const anonKey=process.env.SUPABASE_ANON_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';
 if(token && supabaseUrl && anonKey){
  try {
   const response=await fetch(`${supabaseUrl}/auth/v1/user`,{headers:{apikey:anonKey,Authorization:`Bearer ${token}`},signal:AbortSignal.timeout(8000)});
   if(response.ok){ const account=await response.json(); if(account?.id){
     const salt=randomBytes(16).toString('hex'); const passwordHash=randomBytes(64).toString('hex');
     const syntheticEmail=`supabase-${account.id}@integration.invalid`.slice(0,254);
     db.prepare('INSERT OR IGNORE INTO users(id,email,display_name,password_hash,password_salt,created_at) VALUES(?,?,?,?,?,?)')
       .run(account.id,syntheticEmail,String(account.user_metadata?.display_name||account.email||'Creator').slice(0,70),passwordHash,salt,new Date().toISOString());
     req.user={id:account.id,email:account.email||'',displayName:account.user_metadata?.display_name||account.email||'Creator'}; return next();
    } }
  } catch(error){ console.error('Supabase token validation failed:',String(error?.message||error)); }
 }
 return res.status(401).json({error:'Sign in required. Please sign in again.'});
}
function requireEngineKey(req,res,next) { const supplied=req.get('x-api-key') || ''; const expected=Buffer.from(API_KEY); const actual=Buffer.from(supplied); if(!API_KEY || actual.length!==expected.length || !timingSafeEqual(actual,expected)) return res.status(401).json({error:'Valid engine API key required in X-API-Key.'}); next(); }
function issueSession(user) {
 const token = randomBytes(32).toString('base64url'); const now = new Date(); const expires = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
 db.prepare('INSERT INTO user_sessions(token_hash,user_id,created_at,expires_at) VALUES(?,?,?,?)').run(hashToken(token), user.id, now.toISOString(), expires.toISOString());
 return { token, user: { id:user.id, email:user.email, displayName:user.display_name } };
}
app.post('/api/auth/register', authRateLimit, async (req,res,next) => {
 try {
  const email=String(req.body?.email||'').trim().toLowerCase(); const displayName=String(req.body?.displayName||'').trim(); const password=String(req.body?.password||'');
  if (email.length>254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({error:'Enter a valid email address.'});
  if (displayName.length < 2 || displayName.length > 70) return res.status(400).json({error:'Display name must be 2–70 characters.'});
  if (password.length < 10 || !/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) return res.status(400).json({error:'Use at least 10 characters, including letters and numbers.'});
  if (db.prepare('SELECT id FROM users WHERE email=?').get(email)) return res.status(409).json({error:'An account with this email already exists.'});
  const salt=randomBytes(16).toString('hex'); const passwordHash=(await scrypt(password,salt,64)).toString('hex');
  const user={id:randomUUID(),email,display_name:displayName,password_hash:passwordHash,password_salt:salt,created_at:new Date().toISOString()};
  db.prepare('INSERT INTO users(id,email,display_name,password_hash,password_salt,created_at) VALUES(@id,@email,@display_name,@password_hash,@password_salt,@created_at)').run(user);
  return res.status(201).json(issueSession(user));
 } catch(error){ if(String(error.message).includes('UNIQUE')) return res.status(409).json({error:'An account with this email already exists.'}); return next(error); }
});
app.post('/api/auth/login', authRateLimit, async (req,res,next) => {
 try {
  const email=String(req.body?.email||'').trim().toLowerCase(); const password=String(req.body?.password||'');
  const user=db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if(!user) return res.status(401).json({error:'Email or password is incorrect.'});
  const candidate=await scrypt(password,user.password_salt,64); const stored=Buffer.from(user.password_hash,'hex');
  if(candidate.length!==stored.length || !timingSafeEqual(candidate,stored)) return res.status(401).json({error:'Email or password is incorrect.'});
  return res.json(issueSession(user));
 } catch(error){return next(error);}
});
app.get('/api/auth/me',requireUser,(req,res)=>res.json({user:req.user}));
app.post('/api/auth/logout',(req,res)=>{const token=bearer(req);if(token)db.prepare('DELETE FROM user_sessions WHERE token_hash=?').run(hashToken(token));return res.json({ok:true});});
app.patch('/api/auth/profile', requireUser, (req,res)=>{ const name=String(req.body?.displayName||'').trim(); if(name.length<2||name.length>70) return res.status(400).json({error:'Display name must be 2–70 characters.'}); db.prepare('UPDATE users SET display_name=? WHERE id=?').run(name,req.user.id); return res.json({user:{...req.user,displayName:name}}); });
app.post('/api/auth/change-password', requireUser, async (req,res,next)=>{ try { const current=String(req.body?.currentPassword||''); const nextPassword=String(req.body?.newPassword||''); const user=db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id); const candidate=await scrypt(current,user.password_salt,64); const stored=Buffer.from(user.password_hash,'hex'); if(candidate.length!==stored.length||!timingSafeEqual(candidate,stored)) return res.status(401).json({error:'Current password is incorrect.'}); if(nextPassword.length<10||!/[A-Za-z]/.test(nextPassword)||!/[0-9]/.test(nextPassword)) return res.status(400).json({error:'Use at least 10 characters, including letters and numbers.'}); const salt=randomBytes(16).toString('hex'); const passwordHash=(await scrypt(nextPassword,salt,64)).toString('hex'); db.prepare('UPDATE users SET password_hash=?,password_salt=? WHERE id=?').run(passwordHash,salt,req.user.id); db.prepare('DELETE FROM user_sessions WHERE user_id=?').run(req.user.id); const fresh=db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id); return res.json(issueSession(fresh)); } catch(error){return next(error);} });
app.get('/api/projects', requireUser, (req,res)=>{ const rows=db.prepare('SELECT id,payload_json,updated_at FROM user_projects WHERE user_id=? ORDER BY updated_at DESC').all(req.user.id); return res.json({projects:rows.map(row=>({...JSON.parse(row.payload_json),id:row.id,updatedAt:row.updated_at}))}); });
app.post('/api/projects/sync', requireUser, (req,res)=>{ const list=req.body?.projects; if(!Array.isArray(list)||list.length>500) return res.status(400).json({error:'Send a projects array containing no more than 500 projects.'}); const now=new Date().toISOString(); const upsertProject=db.prepare('INSERT INTO user_projects(id,user_id,payload_json,updated_at) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET payload_json=excluded.payload_json,updated_at=excluded.updated_at WHERE user_projects.user_id=excluded.user_id'); const ids=[]; const tx=db.transaction(()=>{ for(const item of list){ if(!item||typeof item!=='object'||Array.isArray(item)) continue; const id=String(item.id||''); if(!/^[a-zA-Z0-9_-]{1,100}$/.test(id)) continue; const json=JSON.stringify(item); if(json.length>500000) continue; const existing=db.prepare('SELECT user_id FROM user_projects WHERE id=?').get(id); if(existing&&existing.user_id!==req.user.id) continue; upsertProject.run(id,req.user.id,json,now); ids.push(id); } /* Sync is additive/upsert-only. Deleting omitted projects here caused data loss when a single project was saved. */ }); tx(); return res.json({ok:true,saved:ids.length,updatedAt:now}); });
app.put('/api/projects/:id', requireUser, (req,res)=>{ const id=String(req.params.id||''); if(!/^[a-zA-Z0-9_-]{1,100}$/.test(id)) return res.status(400).json({error:'Invalid project ID.'}); const payload=req.body?.project; if(!payload||typeof payload!=='object'||Array.isArray(payload)) return res.status(400).json({error:'Project object required.'}); const json=JSON.stringify(payload); if(json.length>500000) return res.status(413).json({error:'Project is too large.'}); const now=new Date().toISOString(); const existing=db.prepare('SELECT user_id FROM user_projects WHERE id=?').get(id); if(existing&&existing.user_id!==req.user.id) return res.status(409).json({error:'Project ID belongs to another account.'}); db.prepare('INSERT INTO user_projects(id,user_id,payload_json,updated_at) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET payload_json=excluded.payload_json,updated_at=excluded.updated_at WHERE user_projects.user_id=excluded.user_id').run(id,req.user.id,json,now); return res.json({ok:true,id,updatedAt:now}); });
app.delete('/api/projects/:id', requireUser, (req,res)=>{ const result=db.prepare('DELETE FROM user_projects WHERE id=? AND user_id=?').run(req.params.id,req.user.id); return result.changes?res.json({ok:true}):res.status(404).json({error:'Project not found.'}); });
app.use((req,res,next)=>{
  if(req.path==='/health'||req.path==='/api/health'||req.path.startsWith('/api/auth/')||req.path.startsWith('/api/integrations/chatgpt/')) return next();
  if(req.path.startsWith('/api/')) return requireUser(req,res,next);
  return next();
});
const upload = multer({ dest: UPLOADS, limits: { fileSize: MAX_FILE, files: MAX_CLIPS }, fileFilter(_req, file, cb) {
  if (!['video/mp4','video/webm','video/quicktime','video/x-matroska','video/mpeg'].includes(file.mimetype)) return cb(new Error('Unsupported video format. Upload MP4, WebM, MOV, MKV or MPEG video.'));
  cb(null, true);
} });
const run = args => new Promise((resolve, reject) => {
  const child = spawn(process.env.FFMPEG_PATH || 'ffmpeg', args, { stdio: ['ignore', 'ignore', 'pipe'] });
  let err = '';
  child.stderr.on('data', data => { err = (err + data.toString()).slice(-12000); });
  child.on('error', error => reject(new Error(`Unable to start FFmpeg. Install FFmpeg and ensure it is on PATH. ${error.message}`)));
  child.on('close', code => code === 0 ? resolve() : reject(new Error(`FFmpeg exited ${code}: ${err.slice(-3000)}`)));
});
async function probeDuration(filePath) {
  const { stdout } = await execFileAsync(process.env.FFPROBE_PATH || 'ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', filePath], { timeout: 15000, maxBuffer: 1024 * 1024 });
  const duration = Number(stdout.trim()); if (!Number.isFinite(duration) || duration <= 0) throw new Error('Could not determine normalized clip duration.'); return duration;
}
async function hasAudioStream(filePath) {
  const { stdout } = await execFileAsync(process.env.FFPROBE_PATH || 'ffprobe', ['-v', 'error', '-select_streams', 'a:0', '-show_entries', 'stream=index', '-of', 'csv=p=0', filePath], { timeout: 15000, maxBuffer: 1024 * 1024 });
  return Boolean(stdout.trim());
}
const publicJob = job => ({ id: job.id, status: job.status, progress: job.progress, error: job.error || null,
  createdAt: job.createdAt, finishedAt: job.finishedAt || null,
  downloadUrl: job.status === 'completed' ? `/api/jobs/${job.id}/download` : null });
const queue = jobs.filter(j => j.status === 'queued').map(j => j.id);
let busy = false;
async function worker() {
  if (busy || !queue.length) return;
  busy = true;
  const id = queue.shift();
  const job = jobs.find(item => item.id === id);
  if (!job) { busy = false; return setImmediate(worker); }
  job.status = 'running'; job.progress = 1; persist(job);
  const intermediates = [];
  try {
    const outputs = [];
    for (let i = 0; i < job.files.length; i++) {
      const file = job.files[i];
      const output = path.join(OUTPUTS, `${job.id}-${i}.mp4`); intermediates.push(output);
      const start = Math.max(0, Number(file.start) || 0);
      const end = Number(file.end);
      const args = ['-hide_banner', '-loglevel', 'error', '-y'];
      if (start > 0) args.push('-ss', String(start));
      if (Number.isFinite(end) && end > start) args.push('-t', String(end - start));
      args.push('-i', file.path);
      const resolution = job.options.resolution === '720p' ? '1280:720' : '1920:1080';
      const size = job.options.orientation === 'Vertical 9:16' ? '720:1280' : job.options.orientation === 'Square 1:1' ? '720:720' : resolution;
      const fps = Math.min(60, Math.max(1, Number.parseInt(job.options.fps, 10) || 30));
      const filters = `scale=${size}:force_original_aspect_ratio=decrease,pad=${size}:(ow-iw)/2:(oh-ih)/2,setsar=1`;
      const audioExists = await hasAudioStream(file.path);
      if (!audioExists) {
        const clipDuration = Number.isFinite(end) && end > start ? end - start : undefined;
        args.push('-f', 'lavfi', ...(clipDuration ? ['-t', String(clipDuration)] : []), '-i', 'anullsrc=channel_layout=stereo:sample_rate=48000');
      }
      args.push('-map', '0:v:0', '-map', audioExists ? '0:a:0?' : '1:a:0', '-vf', filters, '-r', String(fps), '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23', '-c:a', 'aac', '-b:a', '128k', '-ar', '48000', '-ac', '2', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', '-shortest', output);
      await run(args); outputs.push(output);
      job.progress = Math.min(80, Math.round(5 + 70 * (i + 1) / job.files.length)); persist(job);
    }
    const final = path.join(OUTPUTS, `${job.id}.mp4`);
    const stitchClips = await Promise.all(outputs.map(async (file, index) => ({ path: file, durationSeconds: await probeDuration(file), hasAudio: true, transition: index === 0 ? 'cut' : (job.options.transitions[index - 1] || 'cut') })));
    const dimensions = job.options.orientation === 'Vertical 9:16' ? { width: 720, height: 1280 } : job.options.orientation === 'Square 1:1' ? { width: 720, height: 720 } : job.options.resolution === '720p' ? { width: 1280, height: 720 } : { width: 1920, height: 1080 };
    const stitchArgs = buildFfmpegStitchArgs(stitchClips, final, { ...dimensions, fps: Math.min(60, Math.max(1, Number.parseInt(job.options.fps, 10) || 30)), transitionSeconds: job.options.transitionSeconds });
    job.progress = 90; persist(job); await run(stitchArgs);
    job.output = final; job.status = 'completed'; job.progress = 100; job.finishedAt = new Date().toISOString(); job.error = null;
  } catch (error) {
    job.status = 'failed'; job.error = String(error?.message || error).slice(0, 3000);
  } finally {
    for (const file of job.files) await fs.rm(file.path, { force: true }).catch(() => {});
    for (const file of intermediates) await fs.rm(file, { force: true }).catch(() => {});
    persist(job); busy = false; setImmediate(worker);
  }
}
const aiQueue = aiVideoJobs.filter(job => job.status === 'queued');
let aiBusy = false;
async function runAiQueue() {
  if (aiBusy || !aiQueue.length) return;
  aiBusy = true;
  const job = aiQueue.shift();
  let deferred = false;
  const productionTempFiles = [];
  try {
    const generationMode = String(process.env.MOTIONITON_GENERATION_MODE || 'remote').toLowerCase();
    const remoteRequired = generationMode !== 'local';
    if (remoteRequired && !process.env.MOTIONITON_REMOTE_WORKER_URL) {
      aiQueue.unshift(job); deferred = true; job.status = 'queued'; job.error = null;
      job.storageError = 'Waiting for the MotionItOn RunPod GPU worker connection.'; persistAiVideoJob(job);
      setTimeout(runAiQueue, 60_000).unref?.(); return;
    }
    if (remoteRequired) {
      try { await remoteWorkerHealth(); } catch {
        aiQueue.unshift(job); deferred = true; job.status = 'queued'; job.error = null;
        job.storageError = 'Waiting for the MotionItOn RunPod GPU worker to become healthy.'; persistAiVideoJob(job);
        setTimeout(runAiQueue, 30_000).unref?.(); return;
      }
    }
    job.status = 'running'; job.progress = 1; job.error = null; persistAiVideoJob(job);
    const outputPath = path.join(OUTPUTS, `ai-${job.id}.mp4`);
    await fs.rm(outputPath, { force: true }).catch(() => {});
    const generationRunner = remoteRequired ? runRemoteVideoGeneration : runLocalVideoGeneration;
    let workerProfile;
    if (remoteRequired && job.workerId) {
      const { stdout } = await execFileAsync(process.env.PYTHON_BIN || 'python3', [path.resolve('engine/manage_workers.py'), 'list'], { timeout: 15000, maxBuffer: 1024 * 1024, env: process.env });
      workerProfile = JSON.parse(stdout.trim()).find(item => item.id === job.workerId);
      if (!workerProfile || !workerProfile.enabled) throw new Error('Selected AI worker is unavailable or disabled.');
    }
    if (job.production) {
      const clipPaths = [];
      const clips = [];
      for (let index = 0; index < job.production.scenes.length; index++) {
        const scene = job.production.scenes[index];
        const clipPath = path.join(OUTPUTS, `ai-${job.id}-scene-${index + 1}.mp4`);
        clipPaths.push(clipPath); productionTempFiles.push(clipPath);
        await generationRunner({ prompt: compileProductionPrompt(job.production, scene, index), ratio: job.ratio, duration: scene.durationSeconds,
          quality: job.quality, style: job.style, model: job.model, workerId: job.workerId, workerProfile, characters: job.production.characters, outputPath: clipPath,
          onProgress: progress => { job.progress = Math.min(85, Math.round(((index + (Number(progress) || 0) / 100) / job.production.scenes.length) * 85)); persistAiVideoJob(job); } });
        const stat = await fs.stat(clipPath); if (!stat.isFile() || stat.size < 1024) throw new Error(`Scene ${index + 1} did not produce a valid MP4.`);
        let audioPresent = await hasAudioStream(clipPath);
        if (!audioPresent) {
          const withAudio = path.join(OUTPUTS, `ai-${job.id}-scene-${index + 1}-audio.mp4`);
          productionTempFiles.push(withAudio);
          await run(['-hide_banner','-loglevel','error','-y','-i',clipPath,'-f','lavfi','-i','anullsrc=channel_layout=stereo:sample_rate=48000','-map','0:v:0','-map','1:a:0','-t',String(scene.durationSeconds),'-c:v','copy','-c:a','aac','-b:a','128k','-shortest',withAudio]);
          await fs.rename(withAudio, clipPath);
          audioPresent = await hasAudioStream(clipPath);
        }
        clips.push({ path: clipPath, durationSeconds: await probeDuration(clipPath), hasAudio: audioPresent, transition: index === 0 ? 'cut' : scene.transition });
      }
      job.progress = 90; persistAiVideoJob(job);
      const dimensions = job.ratio === '720:1280' ? { width: 720, height: 1280 } : { width: 1280, height: 720 };
      await run(buildFfmpegStitchArgs(clips, outputPath, { ...dimensions, fps: 24, transitionSeconds: 0.6 }));
      for (const clipPath of clipPaths) await fs.rm(clipPath, { force: true }).catch(() => {});
    } else {
      await generationRunner({ prompt: job.prompt, ratio: job.ratio, duration: job.duration, quality: job.quality, style: job.style, model: job.model, workerId: job.workerId, workerProfile, characters: job.characters, outputPath,
        onProgress: progress => { job.progress = typeof progress === 'number' ? progress : Number(progress); persistAiVideoJob(job); } });
    }
    const stat = await fs.stat(outputPath);
    if (!stat.isFile() || stat.size < 1024) throw new Error('The local model did not produce a valid MP4 file.');
    job.output = outputPath; job.status = 'completed'; job.progress = 100;
    job.finishedAt = new Date().toISOString(); job.error = null;
    // The remote worker is compute-only. The completed MP4 is downloaded into
    // the MotionItOn backend OUTPUTS directory and remains there on its persistent
    // backend data volume. No separate object-storage provider is required.
    job.storageStatus = 'backend-persistent';
    job.storageError = null;
    // Every successfully generated video is saved to Projects, never Workplan.
    if (job.userId) {
      const category = job.category || (job.production ? ({ drama:'Drama series', nature:'Nature', cartoons:'Cartoons', cooking:'Cooking', documentary:'Documentary' })[job.production.style] : null) || 'General';
      const projectId = `ai-${job.id}`;
      const now = new Date().toISOString();
      const project = {
        id: projectId, title: job.production?.title || job.prompt.slice(0, 80) || 'AI video', category,
        format: 'AI video', duration: `${job.duration} seconds`,
        orientation: job.ratio === '720:1280' ? 'Vertical 9:16' : 'Landscape 16:9',
        createdAt: now, updatedAt: now, status: 'Completed', episodeCount: 1,
        generatedVideoUrl: `/api/ai/jobs/${job.id}/download`, aiJobId: job.id,
        storyPackage: job.production?.scenes?.map((scene,index)=>`Scene ${index+1}: ${scene.prompt}`).join('\n\n') || job.prompt
      };
      const payload = JSON.stringify(project);
      db.prepare('INSERT INTO user_projects(id,user_id,payload_json,updated_at) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET payload_json=excluded.payload_json,updated_at=excluded.updated_at WHERE user_projects.user_id=excluded.user_id').run(projectId, job.userId, payload, now);
    }
  } catch (error) {
    job.status = 'failed'; job.error = String(error?.message || error).slice(0, 3000);
    job.finishedAt = new Date().toISOString();
  } finally {
    for (const tempFile of productionTempFiles) await fs.rm(tempFile, { force: true }).catch(() => {});
    persistAiVideoJob(job); aiBusy = false; if (!deferred) setImmediate(runAiQueue);
  }
}

app.get(['/health', '/api/health'], (_req, res) => res.json({ ok: true, service: 'MotionItOn renderer', ffmpeg: process.env.FFMPEG_PATH || 'ffmpeg on PATH', storage: DATA, generationMode: String(process.env.MOTIONITON_GENERATION_MODE || 'remote').toLowerCase(), remoteWorkerConfigured: Boolean(process.env.MOTIONITON_REMOTE_WORKER_URL && process.env.MOTIONITON_WORKER_TOKEN), backendPersistentStorage: true, supabaseAuthConfigured: Boolean((process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL) && (process.env.SUPABASE_ANON_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)) }));
app.get('/api/ai/remote-worker-health', requireEngineKey, async (_req, res) => {
  if (!process.env.MOTIONITON_REMOTE_WORKER_URL) return res.status(503).json({ ok: false, configured: false, error: 'Remote GPU worker is not configured.' });
  try { return res.json({ ok: true, configured: true, worker: await remoteWorkerHealth() }); }
  catch (error) { return res.status(503).json({ ok: false, configured: true, error: String(error?.message || error).slice(0, 500) }); }
});
app.get('/api/jobs', (req, res) => res.json({ jobs: jobs.filter(job=>job.userId===req.user.id).slice(0, 100).map(publicJob) }));
app.post('/api/render', upload.array('clips', MAX_CLIPS), async (req, res) => {
  const files = req.files || [];
  if (!files.length) return res.status(400).json({ error: 'Upload at least one video clip using the clips field.' });
  let trims;
  try { trims = JSON.parse(req.body.trims || '[]'); if (!Array.isArray(trims)) throw new Error(); }
  catch { for (const file of files) await fs.rm(file.path, { force: true }); return res.status(400).json({ error: 'trims must be a JSON array.' }); }
  if (trims.length && trims.length !== files.length) { for (const file of files) await fs.rm(file.path, { force: true }); return res.status(400).json({ error: 'Provide one trim entry per clip, or omit trims.' }); }
  if (trims.some(t => !t || typeof t !== 'object' || !Number.isFinite(Number(t.start ?? 0)) || Number(t.start ?? 0) < 0 || (t.end !== undefined && (!Number.isFinite(Number(t.end)) || Number(t.end) <= Number(t.start ?? 0))))) { for (const file of files) await fs.rm(file.path, { force: true }); return res.status(400).json({ error: 'Each trim must have a non-negative start and an end greater than its start.' }); }
  let transitions = [];
  try { transitions = req.body.transitions ? JSON.parse(req.body.transitions) : []; if (!Array.isArray(transitions)) throw new Error(); }
  catch { for (const file of files) await fs.rm(file.path, { force: true }); return res.status(400).json({ error: 'transitions must be a JSON array.' }); }
  if (transitions.length && (transitions.length !== Math.max(0, files.length - 1) || transitions.some(value => !['cut', 'fade', 'dissolve', 'slide'].includes(value)))) { for (const file of files) await fs.rm(file.path, { force: true }); return res.status(400).json({ error: 'Provide one supported transition (cut, fade, dissolve or slide) between each pair of clips.' }); }
  const id = randomUUID();
  const job = { id, userId: req.user.id, status: 'queued', progress: 0, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
    files: files.map((file, i) => ({ path: file.path, name: path.basename(file.originalname || `clip-${i + 1}.mp4`), start: Math.max(0, Number(trims[i]?.start) || 0), end: Math.max(0, Number(trims[i]?.end) || 0) })),
    options: { resolution: req.body.resolution === '720p' ? '720p' : '1080p', orientation: ['Vertical 9:16', 'Square 1:1'].includes(req.body.orientation) ? req.body.orientation : 'Landscape 16:9', fps: Math.min(60, Math.max(1, Number.parseInt(req.body.fps, 10) || 30)), transitions: transitions.length ? transitions : Array(Math.max(0, files.length - 1)).fill('cut'), transitionSeconds: Math.min(5, Math.max(0.1, Number(req.body.transitionSeconds) || 0.75)) }, error: null };
  jobs.unshift(job); persist(job); queue.push(id); setImmediate(worker); return res.status(202).json(publicJob(job));
});
app.get('/api/jobs/:id', (req, res) => { const job = jobs.find(item => item.id === req.params.id && item.userId===req.user.id); if (!job) return res.status(404).json({ error: 'Job not found' }); return res.json(publicJob(job)); });
app.get('/api/jobs/:id/download', async (req, res) => {
  const job = jobs.find(item => item.id === req.params.id && item.userId===req.user.id);
  if (!job || job.status !== 'completed' || !job.output) return res.status(404).json({ error: 'Rendered MP4 is not ready' });
  try { await fs.access(job.output); return res.download(job.output, `MotionItOn-${job.id}.mp4`); }
  catch { return res.status(404).json({ error: 'Rendered file is unavailable' }); }
});
app.use('/api/ai', (req,res,next)=>{ if(req.path==='/jobs' || req.path.startsWith('/jobs/') || req.path==='/workplans') return next(); return requireEngineKey(req,res,next); });
app.get('/api/ai/engine', async (_req, res) => {
  const python = process.env.PYTHON_BIN || 'python3';
  try {
    const { stdout } = await execFileAsync(python, [path.resolve('engine/doctor.py')], {
      timeout: 15000, maxBuffer: 1024 * 1024, env: process.env,
    });
    const diagnostics = JSON.parse(stdout.trim());
    return res.json({ engine: 'MotionItOn Local Video Engine', model: diagnostics.model,
      mode: 'self-hosted', providerApiRequired: false, ready: diagnostics.ready,
      requirements: 'Python, FFmpeg, PyTorch, Diffusers and a compatible CUDA GPU.', checks: diagnostics.checks });
  } catch (error) {
    return res.json({ engine: 'MotionItOn Local Video Engine', model: process.env.MOTIONITON_VIDEO_MODEL || 'Wan-AI/Wan2.2-TI2V-5B-Diffusers',
      mode: 'self-hosted', providerApiRequired: false, ready: false,
      requirements: 'Python, FFmpeg, PyTorch, Diffusers and a compatible CUDA GPU.',
      checks: [{ name: 'runtime_diagnostics', ok: false, detail: String(error?.message || error).slice(0, 500) }] });
  }
});
app.get('/api/ai/workers', async (_req, res) => {
  try {
    const python = process.env.PYTHON_BIN || 'python3';
    const { stdout } = await execFileAsync(python, [path.resolve('engine/manage_workers.py'), 'list'], { timeout: 15000, maxBuffer: 1024 * 1024, env: process.env });
    return res.json({ workers: JSON.parse(stdout.trim()), availableModels: [{ id: 'wan-2.2-ti2v-5b', name: 'Wan 2.2 TI2V 5B', implemented: true, enabled: true }, { id: 'ltx-legacy', name: 'LTX-Video (Legacy)', implemented: true, enabled: true }] });
  } catch (error) { return res.status(503).json({ error: `AI worker registry unavailable: ${String(error?.message || error).slice(0, 500)}` }); }
});
app.post('/api/ai/workers', async (req, res) => {
  try {
    const name = String(req.body?.name || '').trim();
    const modelId = String(req.body?.modelId || '');
    if (!name || name.length > 80) return res.status(400).json({ error: 'Worker name must contain 1–80 characters.' });
    if (!['wan-2.2-ti2v-5b', 'ltx-legacy'].includes(modelId)) return res.status(400).json({ error: 'Select a supported model adapter.' });
    const python = process.env.PYTHON_BIN || 'python3';
    const description = String(req.body?.description || '').trim();
    if (!description || description.length > 1200) return res.status(400).json({ error: 'Worker description must contain 1–1200 characters.' });
    const { stdout } = await execFileAsync(python, [path.resolve('engine/manage_workers.py'), 'add', '--name', name, '--model-id', modelId, '--description', description], { timeout: 15000, maxBuffer: 1024 * 1024, env: process.env });
    const worker = JSON.parse(stdout.trim());
    return res.status(201).json({ worker });
  } catch (error) { return res.status(400).json({ error: String(error?.message || error).slice(0, 500) }); }
});
app.patch('/api/ai/workers/:id', async (req, res) => {
  try {
    if (!/^[a-zA-Z0-9_-]{3,80}$/.test(req.params.id)) return res.status(400).json({ error: 'Invalid worker ID.' });
    const args = [path.resolve('engine/manage_workers.py'), 'update', '--id', req.params.id];
    if (typeof req.body?.name === 'string') args.push('--name', req.body.name);
    if (typeof req.body?.enabled === 'boolean') args.push('--enabled', String(req.body.enabled));
    if (args.length === 4) return res.status(400).json({ error: 'Provide a worker name or enabled state.' });
    const { stdout } = await execFileAsync(process.env.PYTHON_BIN || 'python3', args, { timeout: 15000, maxBuffer: 1024 * 1024, env: process.env });
    return res.json({ worker: JSON.parse(stdout.trim()) });
  } catch (error) { return res.status(400).json({ error: String(error?.message || error).slice(0, 500) }); }
});
app.delete('/api/ai/workers/:id', async (req, res) => {
  try {
    if (!/^[a-zA-Z0-9_-]{3,80}$/.test(req.params.id)) return res.status(400).json({ error: 'Invalid worker ID.' });
    const { stdout } = await execFileAsync(process.env.PYTHON_BIN || 'python3', [path.resolve('engine/manage_workers.py'), 'delete', '--id', req.params.id], { timeout: 15000, maxBuffer: 1024 * 1024, env: process.env });
    return res.json(JSON.parse(stdout.trim()));
  } catch (error) { return res.status(400).json({ error: String(error?.message || error).slice(0, 500) }); }
});
app.get('/api/ai/jobs', (req, res) => res.json({ jobs: aiVideoJobs.filter(job=>job.userId===req.user.id).slice(0, 100).map(publicAiVideoJob) }));
app.post('/api/ai/jobs/:id/retry', (req,res) => {
  const job=aiVideoJobs.find(item=>item.id===req.params.id && item.userId===req.user.id);
  if(!job) return res.status(404).json({error:'Production job not found.'});
  if(job.status!=='failed') return res.status(409).json({error:'Only failed jobs can be retried.'});
  job.status='queued'; job.progress=0; job.error=null; job.finishedAt=null; job.output=null;
  aiQueue.push(job); persistAiVideoJob(job); setImmediate(runAiQueue);
  return res.json({ok:true,job:publicAiVideoJob(job)});
});
app.delete('/api/ai/jobs/:id', async (req,res) => {
  const index=aiVideoJobs.findIndex(item=>item.id===req.params.id && item.userId===req.user.id);
  if(index<0) return res.status(404).json({error:'Production job not found.'});
  const job=aiVideoJobs[index];
  if(!['queued','failed'].includes(job.status)) return res.status(409).json({error:'Only queued or failed jobs can be removed. Completed videos remain in Projects.'});
  aiQueue.splice(0,aiQueue.length,...aiQueue.filter(item=>item.id!==job.id));
  aiVideoJobs.splice(index,1); db.prepare('DELETE FROM ai_video_jobs WHERE id=? AND user_id=?').run(job.id,req.user.id);
  return res.json({ok:true});
});
app.post('/api/ai/workplans', (req,res) => {
  let production;
  try { production = validateProductionScript(req.body?.production || req.body); }
  catch(error){ return res.status(400).json({error:error.message}); }
  const category=String(req.body?.category || 'General').trim().slice(0,60) || 'General';
  const id=randomUUID();
  const prompt=production.scenes.map((scene,index)=>`Scene ${index+1}: ${scene.prompt}`).join('\n').slice(0,1000);
  const job={id,userId:req.user.id,status:'queued',progress:0,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),finishedAt:null,
    prompt,model:'motioniton-auto',ratio:production.ratio,duration:production.totalDuration,quality:production.quality,style:production.style,
    characters:production.characters,workerId:req.body?.workerId || undefined,providerTaskId:'',output:null,error:null,production,requiresRemote:true,category};
  aiVideoJobs.unshift(job); persistAiVideoJob(job); aiQueue.push(job); setImmediate(runAiQueue);
  return res.status(202).json({accepted:true,job:publicAiVideoJob(job)});
});
const CHATGPT_TOKEN = process.env.MOTIONITON_CHATGPT_TOKEN || '';
const CHATGPT_OWNER_USER_ID = process.env.MOTIONITON_CHATGPT_OWNER_USER_ID || '';
function requireChatGptBridge(req, res, next) {
  const supplied = bearer(req); const expected = Buffer.from(CHATGPT_TOKEN); const actual = Buffer.from(supplied);
  if (!CHATGPT_TOKEN || actual.length !== expected.length || !timingSafeEqual(actual, expected)) return res.status(401).json({ error: 'A valid MotionItOn ChatGPT integration token is required.' });
  if (!CHATGPT_OWNER_USER_ID || !/^[a-zA-Z0-9_-]{3,100}$/.test(CHATGPT_OWNER_USER_ID)) return res.status(503).json({ error: 'Set MOTIONITON_CHATGPT_OWNER_USER_ID to the owning MotionItOn account ID.' });
  // ChatGPT may submit to a Supabase-authenticated account which has no local password row.
  // Create a non-login shadow owner so SQLite can persist jobs/projects under that account ID.
  if (!db.prepare('SELECT id FROM users WHERE id=?').get(CHATGPT_OWNER_USER_ID)) {
    const salt=randomBytes(16).toString('hex'); const passwordHash=randomBytes(64).toString('hex');
    const syntheticEmail=`chatgpt-${CHATGPT_OWNER_USER_ID}@integration.invalid`;
    db.prepare('INSERT OR IGNORE INTO users(id,email,display_name,password_hash,password_salt,created_at) VALUES(?,?,?,?,?,?)')
      .run(CHATGPT_OWNER_USER_ID,syntheticEmail,'MotionItOn Creator',passwordHash,salt,new Date().toISOString());
  }
  req.integrationUserId = CHATGPT_OWNER_USER_ID; next();
}
app.get('/api/integrations/chatgpt/health', requireChatGptBridge, (_req, res) => res.json({ ok: true, service: 'MotionItOn ChatGPT Script Bridge', queue: aiVideoJobs.filter(j => j.userId === CHATGPT_OWNER_USER_ID && j.production && ['queued','running'].includes(j.status)).length }));
app.post('/api/integrations/chatgpt/scripts', authRateLimit, requireChatGptBridge, (req, res) => {
  let production;
  try { production = validateProductionScript(req.body); } catch (error) { return res.status(400).json({ error: error.message }); }
  const idempotencyKey = String(req.get('Idempotency-Key') || req.body?.idempotencyKey || '').trim();
  if (idempotencyKey && (idempotencyKey.length > 120 || !/^[a-zA-Z0-9._:-]+$/.test(idempotencyKey))) return res.status(400).json({ error: 'Idempotency-Key must be 1–120 safe characters.' });
  if (idempotencyKey) {
    const prior = aiVideoJobs.find(j => j.userId === req.integrationUserId && j.idempotencyKey === idempotencyKey);
    if (prior) return res.status(200).json({ accepted: true, duplicate: true, job: publicAiVideoJob(prior) });
  }
  const utcDayStart = new Date(); utcDayStart.setUTCHours(0, 0, 0, 0);
  const dailyCount = db.prepare('SELECT COUNT(*) AS count FROM ai_video_jobs WHERE user_id=? AND created_at >= ?').get(req.integrationUserId, utcDayStart.toISOString()).count;
  if (dailyCount >= MAX_AI_GENERATIONS_PER_DAY) return res.status(429).json({ error: `Daily production limit reached (${MAX_AI_GENERATIONS_PER_DAY} jobs).` });
  const pendingCount = aiVideoJobs.filter(j => j.userId === req.integrationUserId && j.production && ['queued','running'].includes(j.status)).length;
  if (pendingCount >= 100) return res.status(429).json({ error: 'The production queue is full (100 active scripts). Wait for existing jobs to complete.' });
  const id = randomUUID();
  const prompt = production.scenes.map((scene, i) => `Scene ${i + 1}: ${scene.prompt}`).join('\n').slice(0, 1000);
  const job = { id, userId: req.integrationUserId, idempotencyKey: idempotencyKey || null, status: 'queued', progress: 0,
    createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), finishedAt: null, prompt, model: 'motioniton-auto',
    ratio: production.ratio, duration: production.totalDuration, quality: production.quality, style: production.style,
    characters: production.characters, workerId: undefined, providerTaskId: '', output: null, error: null, production, requiresRemote: true, category: String(req.body?.category || ({drama:'Drama series',nature:'Nature',cartoons:'Cartoons',cooking:'Cooking',documentary:'Documentary'})[production.style] || 'General') };
  aiVideoJobs.unshift(job); persistAiVideoJob(job); aiQueue.push(job); setImmediate(runAiQueue);
  return res.status(202).json({ accepted: true, duplicate: false, job: publicAiVideoJob(job) });
});
app.get('/api/integrations/chatgpt/jobs/:id', requireChatGptBridge, (req, res) => {
  const job = aiVideoJobs.find(j => j.id === req.params.id && j.userId === req.integrationUserId && j.production);
  if (!job) return res.status(404).json({ error: 'Production job not found.' });
  return res.json({ job: publicAiVideoJob(job) });
});

app.post('/api/ai/generate', async (req, res, next) => {
  try {
    const utcDayStart = new Date(); utcDayStart.setUTCHours(0, 0, 0, 0);
    const usedToday = db.prepare('SELECT COUNT(*) AS count FROM ai_video_jobs WHERE user_id=? AND created_at >= ?').get(req.user.id,utcDayStart.toISOString()).count;
    if (usedToday >= MAX_AI_GENERATIONS_PER_DAY) return res.status(429).json({ error: `Local generation limit reached (${MAX_AI_GENERATIONS_PER_DAY} jobs today). Configure MAX_AI_GENERATIONS_PER_DAY on your own engine if needed.` });
    const options = normalizeGenerateRequest(req.body);
    const category = String(req.body?.category || 'General').trim().slice(0,60) || 'General';
    const job = { id: randomUUID(), userId:req.user.id, category, status: 'queued', progress: 0, createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(), finishedAt: null, ...options,
      providerTaskId: 'local-engine', output: null, error: null };
    aiVideoJobs.unshift(job); persistAiVideoJob(job); aiQueue.push(job); setImmediate(runAiQueue);
    return res.status(202).json(publicAiVideoJob(job));
  } catch (error) { return next(error); }
});
app.get('/api/ai/jobs/:id', (req, res) => {
  const job = aiVideoJobs.find(item => item.id === req.params.id && item.userId===req.user.id);
  if (!job) return res.status(404).json({ error: 'AI video job not found.' });
  return res.json(publicAiVideoJob(job));
});
app.patch('/api/ai/jobs/:id/production', (req, res) => {
  const job = aiVideoJobs.find(item => item.id === req.params.id && item.userId === req.user.id && item.production);
  if (!job) return res.status(404).json({ error: 'Queued production workplan not found.' });
  if (job.status !== 'queued') return res.status(409).json({ error: 'A workplan can only be edited while it is queued and waiting for execution.' });
  let production;
  try { production = validateProductionScript(req.body); } catch (error) { return res.status(400).json({ error: error.message }); }
  job.production = production;
  job.prompt = production.scenes.map((scene, index) => `Scene ${index + 1}: ${scene.prompt}`).join('\n').slice(0, 1000);
  job.ratio = production.ratio;
  job.duration = production.totalDuration;
  job.quality = production.quality;
  job.style = production.style;
  job.characters = production.characters;
  job.updatedAt = new Date().toISOString();
  persistAiVideoJob(job);
  return res.json({ saved: true, job: publicAiVideoJob(job) });
});
app.get('/api/ai/jobs/:id/download', async (req, res) => {
  const job = aiVideoJobs.find(item => item.id === req.params.id && item.userId===req.user.id);
  if (!job || job.status !== 'completed' || !job.output) return res.status(404).json({ error: 'Generated MP4 is not ready.' });
  try { await fs.access(job.output); return res.download(job.output, `MotionItOn-AI-${job.id}.mp4`); }
  catch { return res.status(404).json({ error: 'Generated MP4 is unavailable on MotionItOn backend storage. Check that the backend persistent volume is mounted and retained.' }); }
});

app.use((err, req, res, _next) => {
  if (res.headersSent) return;
  const multerError = err instanceof multer.MulterError;
  const originError = String(err.message || '').startsWith('Origin not allowed');
  const status = multerError ? (err.code === 'LIMIT_FILE_SIZE' ? 413 : 400) : (originError ? 403 : (Number.isInteger(err.statusCode) && err.statusCode >= 400 && err.statusCode < 500 ? err.statusCode : 500));
  const safeClientMessage = status < 500 ? (err.message || 'Request rejected.') : 'The server could not complete the request. Check backend logs for details.';
  if (status >= 500) console.error(`[${new Date().toISOString()}] ${req.method} ${req.path}:`, err);
  return res.status(status).json({ error: safeClientMessage });
});
const server = app.listen(PORT, '0.0.0.0', () => { console.log(`MotionItOn rendering API listening on ${PORT}`); if (aiQueue.length) setImmediate(runAiQueue); });
function shutdown() { server.close(() => { db.close(); process.exit(0); }); }
process.on('SIGTERM', shutdown); process.on('SIGINT', shutdown);
