# Public media credits

The Drama Spotlight uses remote preview footage hosted by Pexels. These are royalty-free stock scenes used as genre previews; they are **not footage from any existing television series or the Moretti/Billionaire drama productions**.

1. **Luxury mansion with Dubai skyline view** — Peggy Anke, Pexels video 31977028. https://www.pexels.com/video/luxury-mansion-with-dubai-skyline-view-31977028/
2. **A couple on a balcony** — Ron Lach, Pexels video 9500077. https://www.pexels.com/video/a-couple-on-a-balcony-9500077/

Pexels states that its photos and videos may be used for personal and commercial purposes under the Pexels License. Check the current license and the individual asset page before distributing builds. The dashboard plays short 12-second excerpts from these clips. The previews stream from Pexels and therefore require an internet connection; they are not bundled as local MP4 files.

License information: https://www.pexels.com/license/

## Additional category preview footage

- Cooking: Ron Lach, “Woman preparing to cook” — https://www.pexels.com/video/woman-preparing-to-cook-8176159/
- Nature: Sherine, misty mountain aerial preview — https://www.pexels.com/video/aerial-view-of-misty-mountain-landscape-at-dawn-36974946/
- Cartoons: Graham Thorne, abstract 3D geometric animation — https://www.pexels.com/video/abstract-3d-geometric-animation-with-vibrant-colors-34701967/
- Documentary: Taryn Elliott, aerial landscape footage — https://www.pexels.com/video/aerial-shot-of-a-landscape-8820216/

These are category mood previews, not generated content or excerpts from copyrighted films/shows. Video files stream from Pexels and are not bundled in the app archive.

## MotionItOn category preview clips (6 November 2026)
The five bundled preview MP4s in `public/previews/` were selected from video files supplied by the application owner in this conversation and transcoded locally for lightweight, muted, looping category previews. No third-party stock footage is bundled in these five preview files. The Nature preview is landscape/garden footage, not an animal close-up; replace it with a licensed wildlife clip before describing it as an animal showcase.
