'use client';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { ClipboardList, Plus, Trash2, Save, RefreshCw, Pencil, Clock3 } from 'lucide-react';

type ProductionScene = { title: string; prompt: string; durationSeconds: number; transition: string };
type ProductionScript = { title: string; style: string; ratio: string; quality: string; scenes: ProductionScene[]; characters: { name: string; appearance: string; wardrobe?: string }[]; totalDuration: number };
type RemotePlan = { id: string; title: string; status: string; progress: number; createdAt: string; production: ProductionScript | null; prompt: string; duration: number; category: string; error?: string | null };
const BACKEND_KEY = 'motioniton_ai_backend_url';
const styleFor = (category: string) => ({ 'Drama series':'drama', Nature:'nature', Cartoons:'cartoons', Cooking:'cooking', Documentary:'documentary' } as Record<string,string>)[category] || 'general';

export function WorkplanView({ categories, onOpenQueue }: { categories: string[]; onOpenQueue: () => void }) {
  const [remotePlans, setRemotePlans] = useState<RemotePlan[]>([]);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('General');
  const [prompt, setPrompt] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const [editingId, setEditingId] = useState('');
  const [editingScript, setEditingScript] = useState<ProductionScript | null>(null);
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const [backendUrl, setBackendUrl] = useState('');
  const [session, setSession] = useState('');

  useEffect(() => {
    setBackendUrl((localStorage.getItem(BACKEND_KEY) || '').replace(/\/+$/, ''));
    setSession(localStorage.getItem('motioniton_session') || '');
  }, []);
  const refreshRemote = useCallback(async () => {
    if (!backendUrl || !session) return;
    try {
      const response = await fetch(`${backendUrl}/api/ai/jobs`, { headers: { Authorization: `Bearer ${session}` } });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `Could not load workplans (HTTP ${response.status}).`);
      const jobs = (Array.isArray(data.jobs) ? data.jobs : []) as RemotePlan[];
      setRemotePlans(jobs.filter(job => job.production && ['queued','running','downloading','failed'].includes(job.status)));
      setNotice('');
    } catch (error) { setNotice(error instanceof Error ? error.message : String(error)); }
  }, [backendUrl, session]);
  useEffect(() => { if (!backendUrl || !session) return; void refreshRemote(); const timer = window.setInterval(() => void refreshRemote(), 8000); return () => window.clearInterval(timer); }, [backendUrl, session, refreshRemote]);

  async function save() {
    if (!title.trim() || !prompt.trim()) { setNotice('Enter a workplan title and production description.'); return; }
    if (!backendUrl || !session) { setNotice('Connect the MotionItOn backend and sign in before saving a production workplan.'); return; }
    const production: ProductionScript = {
      title: title.trim(), style: styleFor(category), ratio: '1280:720', quality: 'high',
      scenes: [{ title: title.trim(), prompt: prompt.trim(), durationSeconds: 5, transition: 'cut' }],
      characters: [], totalDuration: 5
    };
    setBusy(true); setNotice('');
    try {
      const response = await fetch(`${backendUrl}/api/ai/workplans`, { method: 'POST', headers: { Authorization: `Bearer ${session}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ category, production }) });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `Could not save workplan (HTTP ${response.status}).`);
      setTitle(''); setPrompt(''); setCategory('General'); setShowCreate(false);
      setNotice('Workplan saved to the production queue. It will execute automatically when an AI worker is available.');
      await refreshRemote();
    } catch (error) { setNotice(error instanceof Error ? error.message : String(error)); }
    finally { setBusy(false); }
  }
  function beginEdit(plan: RemotePlan) {
    if (!plan.production || plan.status !== 'queued') return;
    setEditingId(plan.id); setEditingScript(JSON.parse(JSON.stringify(plan.production)) as ProductionScript); setNotice('');
  }
  async function saveRemoteEdit() {
    if (!editingId || !editingScript || !backendUrl || !session) return;
    setBusy(true); setNotice('');
    try {
      const response = await fetch(`${backendUrl}/api/ai/jobs/${encodeURIComponent(editingId)}/production`, { method: 'PATCH', headers: { Authorization: `Bearer ${session}`, 'Content-Type': 'application/json' }, body: JSON.stringify(editingScript) });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `Could not save script (HTTP ${response.status}).`);
      setEditingId(''); setEditingScript(null); setNotice('Script updated. The queued production will use the revised script.');
      await refreshRemote();
    } catch (error) { setNotice(error instanceof Error ? error.message : String(error)); }
    finally { setBusy(false); }
  }
  async function retry(planId: string) {
    if (!backendUrl || !session) return;
    setBusy(true); setNotice('');
    try {
      const response=await fetch(`${backendUrl}/api/ai/jobs/${encodeURIComponent(planId)}/retry`,{method:'POST',headers:{Authorization:`Bearer ${session}`}});
      const data=await response.json().catch(()=>({}));
      if(!response.ok) throw new Error(data.error || `Retry failed (HTTP ${response.status}).`);
      setNotice('Workplan returned to the queue and will execute when a worker is available.'); await refreshRemote();
    } catch(error) { setNotice(error instanceof Error ? error.message : String(error)); }
    finally { setBusy(false); }
  }
  const queuedCount = useMemo(() => remotePlans.filter(p => p.status === 'queued').length, [remotePlans]);
  return <section className="projects-section workplan-page">
    <div className="section-heading project-heading"><div><h2>Workplan</h2><p>Scripts and production plans waiting for execution.</p></div><div className="project-heading-actions"><button className="download-project-button" onClick={onOpenQueue}>Generation queue</button><button className="text-button" onClick={() => setShowCreate(v => !v)}><Plus size={16}/> New workplan</button></div></div>
    {notice && <div className="notice" role="status"><span>{notice}</span><button onClick={() => setNotice('')} aria-label="Dismiss notice">×</button></div>}
    {showCreate && <article className="panel-card workplan-create"><h3>Create workplan</h3><label className="settings-field">Workplan title<input value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. The first episode" /></label><label className="settings-field">Production category<select value={category} onChange={e => setCategory(e.target.value)}>{categories.map(c => <option key={c} value={c}>{c}</option>)}</select></label><label className="settings-field">Story, script or production description<textarea rows={8} value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Write or paste the script to be produced…" /></label><div className="modal-actions"><button className="secondary-button" onClick={() => setShowCreate(false)}>Cancel</button><button className="primary-button" disabled={busy || !title.trim() || !prompt.trim()} onClick={() => void save()}>{busy ? 'Saving…' : 'Save workplan'}</button></div></article>}
    <div className="project-toolbar"><div className="workplan-queue-summary"><ClipboardList size={19}/><b>{queuedCount} queued or waiting for execution</b></div><button className="secondary-button" onClick={() => void refreshRemote()}><RefreshCw size={15}/> Refresh</button></div>
    {remotePlans.map(plan => <article className="panel-card queue-row" key={plan.id}><div className="workplan-row-main"><b>{plan.title || 'Production script'}</b><p>{plan.category || plan.production?.style || 'General'} · {plan.duration}s · {new Date(plan.createdAt).toLocaleString()}</p><span>{plan.status === 'queued' ? 'Queued — waiting for an available AI worker' : plan.status === 'failed' ? `Failed — ${plan.error || 'check production logs'}` : `Production ${plan.status} · ${plan.progress}%`}</span>{editingId === plan.id && editingScript ? <div className="workplan-script-editor"><label className="settings-field">Script title<input value={editingScript.title} onChange={e => setEditingScript(v => v ? { ...v, title: e.target.value } : v)}/></label><label className="settings-field">Visual style<select value={editingScript.style} onChange={e => setEditingScript(v => v ? { ...v, style: e.target.value } : v)}>{['realistic','cinematic','cartoons','cooking','nature','documentary','drama','general'].map(v => <option key={v}>{v}</option>)}</select></label>{editingScript.scenes.map((scene, index) => <label className="settings-field" key={index}>Scene {index + 1}<textarea rows={4} value={scene.prompt} onChange={e => setEditingScript(v => v ? { ...v, scenes: v.scenes.map((item, i) => i === index ? { ...item, prompt: e.target.value } : item) } : v)}/></label>)}<div className="modal-actions"><button className="secondary-button" onClick={() => { setEditingId(''); setEditingScript(null); }}>Cancel</button><button className="primary-button" disabled={busy} onClick={() => void saveRemoteEdit()}><Save size={15}/>{busy ? 'Saving…' : 'Save script changes'}</button></div></div> : <p className="workplan-prompt-preview">{plan.production?.scenes?.map(scene => scene.prompt).join(' · ') || plan.prompt}</p>}</div><div className="queue-actions">{plan.status === 'queued' && <button className="secondary-button" onClick={() => beginEdit(plan)}><Pencil size={15}/> Edit script</button>}{plan.status === 'failed' && <button className="secondary-button" disabled={busy} onClick={() => void retry(plan.id)}>Retry production</button>}<span className="queue-status"><Clock3 size={14}/> {plan.status}</span></div></article>)}
    {remotePlans.length === 0 && <div className="queue-empty"><ClipboardList size={28}/><h3>No workplans waiting</h3><p>Scripts submitted from ChatGPT and saved production plans will appear here while waiting for an available GPU worker.</p></div>}
  </section>;
}
