"""Shared adapter contracts for video generation backends."""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

ProgressCallback = Optional[Callable[[int, str], None]]

@dataclass
class GenerationRequest:
    prompt: str
    output_path: Path
    duration: int = 5
    width: int = 768
    height: int = 432
    fps: int = 24
    steps: int = 30
    negative_prompt: str = ""
    input_image: Optional[Path] = None
    seed: Optional[int] = None
    style: str = "general"

class VideoGenerationAdapter(ABC):
    @abstractmethod
    def load(self, device: str = "cuda") -> None: ...

    @abstractmethod
    def generate(self, request: GenerationRequest, progress: ProgressCallback = None) -> Path: ...

    @abstractmethod
    def unload(self) -> None: ...
