# MotionItOn-Ai — Pre-GPU readiness checklist

## Completed without installing additional dependencies in this phase
- [x] Account registration and sign-in endpoints use scrypt password hashing.
- [x] Bearer session tokens are stored as SHA-256 hashes and expire after 30 days.
- [x] Authenticated profile update endpoint.
- [x] Authenticated password change endpoint; revokes other sessions and issues a new session.
- [x] Per-account project API: list, save, delete and batch sync.
- [x] Project data stored with user ownership in SQLite.
- [x] Local project cache separated by account ID.
- [x] Render jobs record their owner; list, status and download are account-scoped.
- [x] AI jobs record their owner; list, status and download are account-scoped.
- [x] Daily AI generation limit is counted per account.
- [x] App session token and engine API key are sent separately.
- [x] Engine key is required for AI engine diagnostics and generation.
- [x] API routes require a valid account session; public routes are limited to health and authentication endpoints that validate themselves.
- [x] `.env.example` added for server configuration.
- [x] Backend JavaScript syntax check passed.
- [x] Existing backend unit tests passed (7/7).
- [x] ZIP archive integrity check passed.

## Still requires external services, credentials, platform approval or installed dependencies
- [ ] Email verification delivery (requires SMTP or transactional email provider credentials).
- [ ] Forgot-password email delivery (requires email provider and secure delivery setup).
- [ ] Social platform OAuth and direct publishing (requires developer app credentials, scopes and platform approval).
- [ ] Cloud object storage (requires provider account, bucket and credentials).
- [ ] Install Node dependencies and run the production Next.js build.
- [ ] Install Android toolchain/dependencies and build the APK.
- [ ] Install Python/PyTorch/Diffusers/FFmpeg model dependencies and validate the LTX worker.
- [ ] Configure RunPod endpoint, GPU credentials and run a real generation job.
- [ ] Physical Android phone test across narrow and tall screens.
- [ ] Production security review, HTTPS, rate limiting at proxy level, backups and deployment hardening.

## Important deployment notes
- Keep `MOTIONITON_API_KEY` private and send it only as `X-API-Key` to the engine endpoints.
- User bearer sessions are separate from the engine API key.
- Set `ALLOWED_ORIGINS` to the exact production web origin(s); do not use `*` with credentials.
- Mount `MOTIONITON_DATA_DIR` to persistent storage. It contains the SQLite database, uploads and rendered videos.
- Older jobs created before account ownership was added have no owner and are intentionally not exposed to any account.
- Project sync replaces the signed-in user's cloud project list with the current device list. Do not use it on a device until its account-specific local projects have loaded.
- Email verification and password reset are deliberately not simulated. They need a real email delivery service.
