import unittest
from engine.production_planner import validate_character_bible, compile_character_bible, build_scene_prompt, build_production_manifest

class ProductionPlannerTests(unittest.TestCase):
    def test_character_bible_preserves_identity_and_wardrobe(self):
        bible = compile_character_bible([{"name": "Tariro", "appearance": "Short dark hair, brown eyes", "wardrobe": "Blue jacket"}])
        self.assertIn("Tariro", bible); self.assertIn("Blue jacket", bible); self.assertIn("Do not change character identity", bible)

    def test_duplicate_characters_rejected_case_insensitively(self):
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            validate_character_bible([{"name": "Hope", "appearance": "A"}, {"name": "hope", "appearance": "B"}])

    def test_scene_prompt_adds_style_and_continuity_guidance(self):
        prompt = build_scene_prompt("A woman enters a kitchen", 2, 4, "cooking", "Tariro: blue jacket", "1280:720")
        self.assertIn("Production scene 2 of 4", prompt); self.assertIn("same world", prompt); self.assertIn("blue jacket", prompt)

    def test_production_manifest_allocates_requested_duration(self):
        manifest = build_production_manifest("Pilot", "A river journey", 23, characters=[{"name": "Tariro", "appearance": "Short dark hair"}])
        self.assertEqual([s["durationSeconds"] for s in manifest["scenes"]], [10, 10, 3])
        self.assertEqual(sum(s["durationSeconds"] for s in manifest["scenes"]), 23)

    def test_invalid_duration_and_scene_order_rejected(self):
        with self.assertRaises(ValueError): build_production_manifest("x", "y", 301)
        with self.assertRaises(ValueError): build_scene_prompt("x", 3, 2)

if __name__ == "__main__": unittest.main()
