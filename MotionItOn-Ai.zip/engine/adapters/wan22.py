"""Wan 2.2 TI2V-5B Diffusers adapter.

Uses the official Wan-AI Diffusers checkpoint. This adapter is implemented for
real inference, but a successful model load and generated MP4 still require a
compatible CUDA GPU and a full GPU smoke test on the target worker.
"""
from __future__ import annotations
import gc
import inspect
import os
from pathlib import Path

import torch
from PIL import Image
from diffusers import AutoencoderKLWan, WanPipeline
from diffusers.utils import export_to_video

from .base import GenerationRequest, VideoGenerationAdapter

DEFAULT_MODEL = "Wan-AI/Wan2.2-TI2V-5B-Diffusers"


class Wan22Adapter(VideoGenerationAdapter):
    def __init__(self):
        self.pipe = None
        self.model_id = os.environ.get("MOTIONITON_WAN_MODEL", DEFAULT_MODEL)

    def load(self, device: str = "cuda") -> None:
        if device != "cuda" or not torch.cuda.is_available():
            raise RuntimeError("Wan 2.2 requires a CUDA-compatible NVIDIA GPU.")
        total_gb = torch.cuda.get_device_properties(0).total_memory / (1024 ** 3)
        free_gb = torch.cuda.mem_get_info()[0] / (1024 ** 3)
        # The registry performs the same conservative total-VRAM check. Recheck
        # free VRAM immediately before loading because other processes may use it.
        if total_gb < 24 or free_gb < 20:
            raise RuntimeError(
                f"Wan 2.2 TI2V-5B is configured for the official 24 GB offload profile; "
                f"detected {total_gb:.1f} GB total and {free_gb:.1f} GB free. "
                "Close other GPU workloads and retry."
            )
        dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        local_only = os.environ.get("MOTIONITON_LOCAL_FILES_ONLY", "false").lower() == "true"
        # Wan's official Diffusers recipe keeps the VAE in float32 while the
        # transformer/text encoder use the GPU-supported reduced precision.
        vae = AutoencoderKLWan.from_pretrained(
            self.model_id,
            subfolder="vae",
            torch_dtype=torch.float32,
            local_files_only=local_only,
        )
        self.pipe = WanPipeline.from_pretrained(
            self.model_id,
            vae=vae,
            torch_dtype=dtype,
            local_files_only=local_only,
        )
        # The official 24 GB TI2V-5B recipe relies on CPU offloading and T5 on CPU.
        # Keep offloading enabled by default for RTX 3090-class cards.
        offload = os.environ.get("MOTIONITON_WAN_CPU_OFFLOAD", "true").lower() == "true"
        if offload:
            if not hasattr(self.pipe, "enable_model_cpu_offload"):
                raise RuntimeError("Installed Diffusers pipeline does not support model CPU offload.")
            self.pipe.enable_model_cpu_offload()
        else:
            self.pipe.to("cuda")
        # Reduce VAE decode peaks where supported by this Diffusers version.
        if hasattr(self.pipe, "enable_vae_tiling"):
            self.pipe.enable_vae_tiling()
        if hasattr(self.pipe, "enable_vae_slicing"):
            self.pipe.enable_vae_slicing()

    def generate(self, request: GenerationRequest, progress=None) -> Path:
        if self.pipe is None:
            raise RuntimeError("Wan 2.2 adapter has not been loaded.")
        if request.duration < 1 or request.duration > 5:
            raise ValueError("Wan 2.2 TI2V-5B adapter accepts scene chunks of 1–5 seconds; longer productions are split by the worker.")
        if request.width < 256 or request.height < 256 or request.width % 16 or request.height % 16:
            raise ValueError("Wan 2.2 width and height must be at least 256 and divisible by 16.")
        num_frames = request.duration * request.fps + 1
        if num_frames % 4 != 1:
            num_frames += (1 - num_frames) % 4

        call = self.pipe.__call__
        parameters = inspect.signature(call).parameters
        kwargs = {
            "prompt": request.prompt,
            "negative_prompt": request.negative_prompt or "blurry, low quality, flicker, jitter, watermark, distorted anatomy",
            "height": request.height,
            "width": request.width,
            "num_frames": num_frames,
            "num_inference_steps": request.steps,
            "guidance_scale": float(os.environ.get("MOTIONITON_WAN_GUIDANCE_SCALE", "5.0")),
        }
        if request.input_image is not None:
            if "image" not in parameters:
                raise RuntimeError("The installed Wan TI2V Diffusers pipeline does not expose image conditioning; update Diffusers before image-to-video use.")
            with Image.open(request.input_image) as source:
                kwargs["image"] = source.convert("RGB").resize((request.width, request.height))

        if request.seed is not None and "generator" in parameters:
            kwargs["generator"] = torch.Generator(device="cuda").manual_seed(int(request.seed))

        if progress and "callback_on_step_end" in parameters:
            def callback(_pipe, step, _timestep, callback_kwargs):
                progress(min(94, 5 + int(88 * (step + 1) / max(1, request.steps))), "Generating Wan 2.2 video frames.")
                return callback_kwargs
            kwargs["callback_on_step_end"] = callback

        with torch.inference_mode():
            result = self.pipe(**kwargs)
        frames = getattr(result, "frames", None)
        if not frames or not frames[0]:
            raise RuntimeError("Wan 2.2 returned no video frames.")
        request.output_path.parent.mkdir(parents=True, exist_ok=True)
        export_to_video(frames[0], str(request.output_path), fps=request.fps)
        del result
        return request.output_path

    def unload(self):
        if self.pipe is not None:
            del self.pipe
            self.pipe = None
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
