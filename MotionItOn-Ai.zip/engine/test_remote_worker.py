import unittest
import json
import os
import sys
import tempfile
import threading
import time
from pathlib import Path
from urllib.request import Request, urlopen
from http.server import ThreadingHTTPServer
import engine.remote_worker as remote_worker
from engine.remote_worker import validate

class RemoteWorkerValidationTests(unittest.TestCase):
    def test_valid_job_payload(self):
        result = validate({"prompt": "A cinematic river scene", "duration": 10, "characters": [{"name": "Tariro", "appearance": "Short dark hair"}]})
        self.assertEqual(result["duration"], 10); self.assertEqual(result["characters"][0]["name"], "Tariro")

    def test_rejects_invalid_duration(self):
        with self.assertRaisesRegex(ValueError, "2–300"):
            validate({"prompt": "Scene", "duration": 301})

    def test_rejects_duplicate_character_names(self):
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            validate({"prompt": "Scene", "characters": [{"name": "Tariro", "appearance": "A"}, {"name": "tariro", "appearance": "B"}]})

    def test_selected_worker_profile_is_validated_for_remote_execution(self):
        result = validate({"prompt": "Scene", "workerId": "worker-123", "workerProfile": {"id": "worker-123", "name": "Cartoon Worker", "model_id": "wan-2.2-ti2v-5b"}})
        self.assertEqual(result["workerProfile"]["name"], "Cartoon Worker")

    def test_rejects_unsupported_model_mode(self):
        with self.assertRaisesRegex(ValueError, "model selection"):
            validate({"prompt": "Scene", "model": "unknown"})


    def test_authenticated_http_worker_accepts_and_completes_a_mock_job(self):
        with tempfile.TemporaryDirectory(prefix="motioniton-worker-test-") as directory:
            root = Path(directory)
            fake_generator = root / "fake_generator.py"
            fake_generator.write_text("import argparse, json, pathlib\np=argparse.ArgumentParser(); p.add_argument('--output'); p.add_argument('--prompt'); p.add_argument('--ratio'); p.add_argument('--duration'); p.add_argument('--quality'); p.add_argument('--style'); p.add_argument('--model'); p.add_argument('--worker-id'); p.add_argument('--character-bible'); a,_=p.parse_known_args(); pathlib.Path(a.output).write_bytes(b'x'*2048); print(json.dumps({'type':'progress','progress':100,'message':'mock done'}), flush=True)\n", encoding="utf-8")
            old = (remote_worker.ROOT, remote_worker.TOKEN, remote_worker.PYTHON, remote_worker.GENERATOR)
            remote_worker.ROOT, remote_worker.TOKEN, remote_worker.PYTHON, remote_worker.GENERATOR = root / "jobs", "t" * 48, sys.executable, fake_generator
            remote_worker.ROOT.mkdir()
            server = ThreadingHTTPServer(("127.0.0.1", 0), remote_worker.Handler)
            thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
            base = f"http://127.0.0.1:{server.server_address[1]}"
            headers = {"Authorization": f"Bearer {'t' * 48}", "Content-Type": "application/json"}
            try:
                unauth = Request(base + "/jobs", data=b'{"prompt":"x"}', headers={"Content-Type": "application/json"}, method="POST")
                with self.assertRaises(Exception): urlopen(unauth)
                request = Request(base + "/jobs", data=json.dumps({"prompt": "Test clip", "duration": 2}).encode(), headers=headers, method="POST")
                with urlopen(request, timeout=5) as response: job_id = json.loads(response.read())["id"]
                status = None
                for _ in range(50):
                    with urlopen(Request(base + f"/jobs/{job_id}", headers={"Authorization": f"Bearer {'t' * 48}"}), timeout=5) as response: status = json.loads(response.read())
                    if status["status"] in ("completed", "failed"): break
                    time.sleep(.05)
                self.assertEqual(status["status"], "completed", status)
                with urlopen(Request(base + f"/jobs/{job_id}/download", headers={"Authorization": f"Bearer {'t' * 48}"}), timeout=5) as response: self.assertEqual(len(response.read()), 2048)
            finally:
                server.shutdown(); server.server_close(); thread.join(timeout=2)
                remote_worker.ROOT, remote_worker.TOKEN, remote_worker.PYTHON, remote_worker.GENERATOR = old

if __name__ == "__main__": unittest.main()
