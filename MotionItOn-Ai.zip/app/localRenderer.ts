"use client";

import type { FFmpeg as FFmpegType } from "@ffmpeg/ffmpeg";

let engine: FFmpegType | null = null;
let loading: Promise<FFmpegType> | null = null;

async function getEngine(onProgress?: (percent: number) => void): Promise<FFmpegType> {
  if (engine) return engine;
  if (loading) return loading;
  loading = (async () => {
    const [{ FFmpeg }, { toBlobURL }] = await Promise.all([import("@ffmpeg/ffmpeg"), import("@ffmpeg/util")]);
    const instance = new FFmpeg();
    instance.on("progress", ({ progress }) => onProgress?.(Math.max(0, Math.min(99, Math.round(progress * 100)))));
    // The FFmpeg WASM core is fetched once from a CDN. After loading, media processing runs locally.
    const base = "https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd";
    await instance.load({
      coreURL: await toBlobURL(`${base}/ffmpeg-core.js`, "text/javascript"),
      wasmURL: await toBlobURL(`${base}/ffmpeg-core.wasm`, "application/wasm"),
    });
    engine = instance;
    return instance;
  })();
  try { return await loading; } catch (error) { loading = null; throw error; }
}

export type LocalRenderClip = { name: string; url: string; start: number; end: number; duration: number };
export type LocalRenderOptions = {
  clips: LocalRenderClip[];
  resolution: string;
  orientation: string;
  fps: string;
  audioMode: string;
  onProgress?: (percent: number, message: string) => void;
};

function outputSize(resolution: string, orientation: string): [number, number] {
  let w = resolution === "720p" ? 1280 : resolution === "1440p" ? 2560 : resolution === "4K" ? 3840 : 1920;
  let h = resolution === "720p" ? 720 : resolution === "1440p" ? 1440 : resolution === "4K" ? 2160 : 1080;
  if (resolution === "Match source") { w = 1920; h = 1080; }
  if (orientation === "Vertical 9:16") [w, h] = [Math.min(w, h), Math.max(w, h)];
  if (orientation === "Landscape 16:9") [w, h] = [Math.max(w, h), Math.min(w, h)];
  if (orientation === "Square 1:1") [w, h] = [Math.min(w, h), Math.min(w, h)];
  if (orientation === "Portrait 4:5") [w, h] = [Math.round(Math.min(w, h) * 4 / 5), Math.min(w, h)];
  return [w, h];
}

export async function renderVideoLocally(options: LocalRenderOptions): Promise<Blob> {
  const { fetchFile } = await import("@ffmpeg/util");
  if (!options.clips.length) throw new Error("Import at least one video clip first.");
  const valid = options.clips.filter(c => (c.end || c.duration) > c.start);
  if (!valid.length) throw new Error("Each clip must have a trim end after its trim start.");
  const ffmpeg = await getEngine(p => options.onProgress?.(p, `Rendering locally: ${p}%`));
  const names: string[] = [];
  const [width, height] = outputSize(options.resolution, options.orientation);
  const fps = options.fps === "Match source" ? "30" : options.fps.replace(/\s*fps/i, "");
  const args: string[] = [];
  const filters: string[] = [];
  const audioEnabled = options.audioMode === "Keep original audio" && valid.length === 1;

  for (let i = 0; i < valid.length; i++) {
    const clip = valid[i];
    const inputName = `motioniton-input-${i}.mp4`;
    names.push(inputName);
    options.onProgress?.(0, `Loading clip ${i + 1} of ${valid.length}…`);
    await ffmpeg.writeFile(inputName, await fetchFile(clip.url));
    args.push("-ss", String(Math.max(0, clip.start)), "-t", String(Math.max(0.1, (clip.end || clip.duration) - clip.start)), "-i", inputName);
    filters.push(`[${i}:v]scale=${width}:${height}:force_original_aspect_ratio=decrease,pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=${fps},format=yuv420p[v${i}]`);
  }
  const concatInputs = valid.map((_, i) => `[v${i}]`).join("");
  filters.push(`${concatInputs}concat=n=${valid.length}:v=1:a=0[vout]`);
  args.push("-filter_complex", filters.join(";"), "-map", "[vout]");
  if (audioEnabled) args.push("-map", "0:a?");
  else args.push("-an");
  args.push("-c:v", "libx264", "-preset", "ultrafast", "-crf", "23");
  if (audioEnabled) args.push("-c:a", "aac", "-b:a", "128k");
  args.push("-movflags", "+faststart", "motioniton-output.mp4");
  try {
    options.onProgress?.(1, "Starting local FFmpeg render…");
    await ffmpeg.exec(args);
    const result = await ffmpeg.readFile("motioniton-output.mp4");
    const bytes = result instanceof Uint8Array ? result : new Uint8Array(result as unknown as ArrayBuffer);
    options.onProgress?.(100, "MP4 ready for download.");
    return new Blob([bytes.slice().buffer as ArrayBuffer], { type: "video/mp4" });
  } finally {
    for (const name of [...names, "motioniton-output.mp4"]) {
      try { await ffmpeg.deleteFile(name); } catch { /* temporary file may not exist */ }
    }
  }
}
