# MotionItOn-Ai deployment quickstart (RTX 3090 / Wan 2.2)

## Architecture (do not change)

MotionItOn-Ai is the only user-facing application. Its backend authenticates users, owns the persistent queue and SQLite records, sends jobs to the private RunPod GPU worker, downloads completed MP4s, and stores them under `/data/renders`. The app lists and plays those videos through MotionItOn endpoints. RunPod is compute only. The user never needs to retrieve a video from RunPod. Stopping the GPU pod must not remove videos already stored by MotionItOn.

Supabase Storage is not part of this video workflow. Existing Supabase Auth/project-sync may remain enabled if the current account setup uses it. The backend `/data` persistent disk is mandatory. The RunPod `/workspace` volume is only for model weights/cache and temporary worker files.

## A. Build and publish the custom worker image (before starting paid GPU time)

The generic RunPod PyTorch template is not the MotionItOn worker. Build this repository's `Dockerfile.gpu-worker` and push the image to a registry RunPod can pull from. From the project root on a machine with Docker: `docker build -f Dockerfile.gpu-worker -t YOUR_REGISTRY/motioniton-gpu-worker:wan22 .` then `docker push YOUR_REGISTRY/motioniton-gpu-worker:wan22`. Do not put credentials in the image. If the registry is private, configure registry credentials in RunPod.

## B. Deploy the RunPod pod

Use the custom image you just pushed. Select RTX 3090 24 GB, container disk 50 GB, persistent volume 50 GB mounted at `/workspace`, and expose HTTP port `8790`. Set pod secrets/environment: `MOTIONITON_WORKER_TOKEN` (same random secret as backend, at least 32 chars), `MOTIONITON_WORKER_PORT=8790`, `MOTIONITON_REMOTE_DATA=/workspace/jobs`, `HF_HOME=/workspace/.cache/huggingface`, `MOTIONITON_WAN_CPU_OFFLOAD=true`, `MOTIONITON_SELECTED_MODEL=wan-2.2-ti2v-5b`, `MOTIONITON_VIDEO_MODEL=Wan-AI/Wan2.2-TI2V-5B-Diffusers`.

## C. Configure the MotionItOn backend

Deploy `Dockerfile.backend` or the backend service using `compose.backend.yml`. Attach a persistent disk/volume at `/data` (the included Compose file creates a named Docker volume). Set backend environment: `MOTIONITON_GENERATION_MODE=remote`, `MOTIONITON_REMOTE_WORKER_URL=https://POD_ID-8790.proxy.runpod.net`, `MOTIONITON_WORKER_TOKEN` (same secret used in the pod), `MOTIONITON_API_KEY` (separate long random secret), and `MOTIONITON_DATA_DIR=/data`. The frontend's backend URL and engine API key/session settings must point to this deployed MotionItOn backend. Never expose the worker token or backend API key in a `NEXT_PUBLIC_` variable.

## D. Verify before generating

1. `GET https://YOUR_BACKEND/api/health` reports `generationMode: remote`, `remoteWorkerConfigured: true`, and `backendPersistentStorage: true`.
2. Call `GET /api/ai/remote-worker-health` with `X-API-Key: MOTIONITON_API_KEY`; expect `ok: true` and GPU details showing RTX 3090 and approximately 24 GB VRAM.
3. Confirm the backend `/data` mount is writable and survives a backend restart.
4. From MotionItOn-Ai submit one short 2–5 second Wan 2.2 TI2V-5B test. Confirm queued -> running -> completed, MP4 download and project creation.
5. Stop the RunPod pod and confirm the same completed video still plays from MotionItOn-Ai.

## E. Cost controls

Do not start long generations until the short acceptance test passes. Stop the GPU pod after testing. The model cache remains on the separately billed RunPod persistent volume. The backend's `/data` disk must remain attached so generated videos and job records remain available.

## Important limits

This repository contains the worker source and Dockerfile; it does not contain a prebuilt published container image, your registry credentials, RunPod worker URL/token, or your deployed backend URL. Those are deployment-time values and must be supplied by the operator. A source ZIP alone cannot create those external resources.
