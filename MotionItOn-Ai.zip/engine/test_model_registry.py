import unittest
from engine.model_registry import MODEL_REGISTRY, get_model, select_model

class RegistryTests(unittest.TestCase):
    def test_wan_is_the_enabled_default_adapter(self):
        self.assertTrue(MODEL_REGISTRY['wan-2.2-ti2v-5b'].implemented)
        self.assertTrue(MODEL_REGISTRY['wan-2.2-ti2v-5b'].enabled)
        self.assertFalse(MODEL_REGISTRY['ltx-2'].implemented)
        self.assertFalse(MODEL_REGISTRY['hunyuan-video-1.5'].implemented)

    def test_wan_adapter_is_registered(self):
        self.assertEqual(get_model('wan-2.2-ti2v-5b').adapter_class, 'Wan22Adapter')

    def test_unknown_gpu_memory_is_rejected(self):
        with self.assertRaises(RuntimeError):
            select_model(vram_gb=0)

    def test_insufficient_vram_does_not_fallback_to_ltx(self):
        with self.assertRaises(RuntimeError):
            select_model(style='cartoon', vram_gb=23)

    def test_wan_is_selected_for_all_default_styles(self):
        for style in ('realistic', 'cinematic', 'cartoon', 'documentary', 'cooking', 'nature', 'general'):
            self.assertEqual(select_model(style=style, vram_gb=24).model_id, 'wan-2.2-ti2v-5b')

    def test_ltx_remains_explicitly_selectable(self):
        self.assertEqual(select_model(requested_model='ltx-legacy', vram_gb=24).model_id, 'ltx-legacy')

    def test_image_to_video_supported_by_wan(self):
        self.assertEqual(select_model(task='image_to_video', vram_gb=24).model_id, 'wan-2.2-ti2v-5b')

    def test_unsupported_task_is_rejected(self):
        with self.assertRaises(ValueError):
            select_model(task='text_to_audio', vram_gb=24)

if __name__ == '__main__':
    unittest.main()
